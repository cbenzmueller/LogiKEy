(*<*)
theory ID_Examples
  imports ID_Disagreement
begin
(*>*)

section \<open>Examples\<close>

text \<open>A two-argument counterexample to the converse of the agreement hierarchy
(theorem \<open>agreement_hierarchy\<close>): shared conclusion does not imply shared
argument. Both arguments conclude the same formula, but attack each other. This
small example isolates the difference between shared conclusion and shared
argument.\<close>
definition mutual_attack :: "bool Rel" where
  "mutual_attack a b \<longleftrightarrow> a \<noteq> b"

lemma bool_all: "(\<forall>x::bool. P x) \<longleftrightarrow> P False \<and> P True"
  by metis

lemma bool_ex: "(\<exists>x::bool. P x) \<longleftrightarrow> P False \<or> P True"
  by metis

lemma bool_predicate_cases:
  "P = (\<lambda>(_::bool). False) \<or> P = id \<or> P = Not \<or> P = (\<lambda>_. True)"
  by (cases "P False"; cases "P True"; auto simp: fun_eq_iff bool_all)

lemma bool_predicate_all:
  "(\<forall>P::bool \<Rightarrow> bool. Q P) \<longleftrightarrow>
    Q (\<lambda>_. False) \<and> Q id \<and> Q Not \<and> Q (\<lambda>_. True)"
  by (metis (lifting) ext bool_predicate_cases)

lemma mutual_complete:
  "extensions.completeExt (\<lambda>_. True) mutual_attack E \<longleftrightarrow>
    \<not> (E False \<and> E True)"
  unfolding extensions.completeExt_def extensions.admissibleExt_def
    extensions.conflictfreeExt_def defends_rel_def mutual_attack_def
  by (auto simp: bool_all bool_ex)

lemma mutual_preferred:
  "extensions.preferredExt (\<lambda>_. True) mutual_attack E \<longleftrightarrow>
    (E False \<noteq> E True)"
  unfolding extensions.preferredExt_def maximal_rel_def mutual_complete id_def
  by (auto simp: bool_predicate_all bool_all)

lemma shared_conclusion_without_shared_argument:
  "shared_conclusion (\<lambda>_. True) mutual_attack (\<lambda>_. ()) () \<and>
    \<not> shared_argument (\<lambda>_. True) mutual_attack (\<lambda>_. ()) ()"
  unfolding shared_conclusion_def shared_argument_def proximal_explanation_def
  by (auto simp: mutual_preferred bool_predicate_all bool_all bool_ex)

lemma proximal_disagreement_is_not_ordinary_disagreement:
  "proximal_disagreement (\<lambda>_. True) mutual_attack (\<lambda>_. ()) () \<and>
    distal_disagreement (\<lambda>_. True) mutual_attack (\<lambda>_. ()) () \<and>
    \<not> disagrees_that (\<lambda>_. True) mutual_attack (\<lambda>_. ()) ()"
  by (metis agreement_hierarchy distal_disagreement_def ordinary_and_distal_disjoint
      proximal_disagreement_def shared_conclusion_without_shared_argument)

text \<open>The conflict-freeness clause of the Explanation definition is not idle. With
one self-attacking argument the singleton defends itself, so without the clause it
would be a minimal self-defending support, hence an explanation of its own
conclusion; with the clause it is none. Inside preferred extensions the clause is
invisible (\<open>explanation_cf_invariant\<close>).\<close>
lemma self_attacking_explanation_without_cf:
  "explanation_nocf (\<lambda>_. True) (\<lambda>(_::unit) _. True) (\<lambda>_. ()) () (\<lambda>_. True)"
  unfolding explanation_nocf_def minimal_def explanation_support_nocf_def defends_rel_def
    id_def
  by auto

lemma self_attacking_no_explanation:
  "\<not> explanation (\<lambda>_. True) (\<lambda>(_::unit) _. True) (\<lambda>_. ()) () (\<lambda>_. True)"
  unfolding explanation_def minimal_def explanation_support_def
    extensions.conflictfreeExt_def
  by simp

text \<open>A coalition introduces an edge that neither singleton agent can see
(the paper's coalition examples): with a as the sole attacker of b, a survives
in the coalition and b does not.\<close>
definition one_way_attack :: "bool Rel" where
  "one_way_attack a b \<longleftrightarrow> \<not> a \<and> b"

lemma coalition_reveals_cross_edge:
  "\<not> induced_att one_way_attack (\<lambda>x. \<not> x) False True \<and>
   \<not> induced_att one_way_attack (\<lambda>x. x) False True \<and>
   coalition_att one_way_attack (\<lambda>x. \<not> x) (\<lambda>x. x) False True"
  unfolding induced_att_def one_way_attack_def by simp

lemma one_way_preferred:
  "extensions.preferredExt (\<lambda>_. True) one_way_attack E \<longleftrightarrow>
    E False \<and> \<not> E True"
  unfolding extensions.preferredExt_def maximal_rel_def extensions.completeExt_def
    extensions.admissibleExt_def extensions.conflictfreeExt_def defends_rel_def
    one_way_attack_def id_def
  by (auto simp: bool_all bool_ex)

lemma one_way_coalition_keeps_attacker:
  "shared_argument (\<lambda>_. True) one_way_attack id False \<and>
    \<not> credulous_conclusion (\<lambda>_. True) one_way_attack id True"
  unfolding shared_argument_def credulous_conclusion_def proximal_explanation_def
  by (auto simp: one_way_preferred bool_all bool_ex)

text \<open>The six-argument running-example graph (the bioethics and
constitutional-law readings share it). Optional datatype plugins are disabled
to avoid generating admitted Quickcheck support equations.
The conclusion of A1 is represented by True; the other arguments conclude False.
Only equality of conclusions is used, so this is a model of the designated issue,
not a formalization of the internal bioethical or constitutional arguments.\<close>
datatype (plugins only: code) bio_argument = A1 | A2 | A3 | A4 | A5 | A6

definition bio_att :: "bio_argument Rel" where
  "bio_att a b \<longleftrightarrow>
    (a = A2 \<and> b = A1) \<or> (a = A3 \<and> b = A2) \<or>
    (a = A4 \<and> b = A2) \<or> (a = A5 \<and> b = A4) \<or>
    (a = A6 \<and> b = A3) \<or> (a = A5 \<and> b = A6) \<or>
    (a = A6 \<and> b = A5)"

abbreviation bio_con where "bio_con a \<equiv> a = A1"
abbreviation bio_left where "bio_left \<equiv> \<lbrace>A1,A3,A5\<rbrace>"
abbreviation bio_right where "bio_right \<equiv> \<lbrace>A1,A4,A6\<rbrace>"
abbreviation bio_left_agent where "bio_left_agent \<equiv> bio_left \<union> \<lbrace>A2\<rbrace>"
abbreviation bio_right_agent where "bio_right_agent \<equiv> bio_right \<union> \<lbrace>A2\<rbrace>"

lemma bio_all:
  "(\<forall>x::bio_argument. P x) \<longleftrightarrow>
    P A1 \<and> P A2 \<and> P A3 \<and> P A4 \<and> P A5 \<and> P A6"
  by (metis bio_argument.exhaust)

lemma bio_ex:
  "(\<exists>x::bio_argument. P x) \<longleftrightarrow>
    P A1 \<or> P A2 \<or> P A3 \<or> P A4 \<or> P A5 \<or> P A6"
  by (metis bio_argument.exhaust)

lemma bio_agents_wellformed:
  "is_agent (\<lambda>_. True) bio_att bio_left_agent (induced_att bio_att bio_left_agent) \<and>
    is_agent (\<lambda>_. True) bio_att bio_right_agent (induced_att bio_att bio_right_agent)"
  unfolding is_agent_def by simp

lemma bio_coalition_all: "coalition bio_left_agent bio_right_agent = (\<lambda>_. True)"
  by (auto simp: fun_eq_iff bio_all)

lemma bio_agents_share_conclusion:
  "shared_conclusion bio_left_agent bio_att bio_con True"
  "shared_conclusion bio_right_agent bio_att bio_con True"
proof -
  have left: "E A1" if "extensions.preferredExt bio_left_agent bio_att E" for E
  proof -
    have "extensions.completeExt bio_left_agent bio_att E"
      using that unfolding extensions.preferredExt_def maximal_rel_def by blast
    then show ?thesis
      unfolding extensions.completeExt_def extensions.admissibleExt_def
        extensions.conflictfreeExt_def defends_rel_def bio_att_def
      by (auto simp: bio_all bio_ex)
  qed
  have right: "E A1" if "extensions.preferredExt bio_right_agent bio_att E" for E
  proof -
    have "extensions.completeExt bio_right_agent bio_att E"
      using that unfolding extensions.preferredExt_def maximal_rel_def by blast
    then show ?thesis
      unfolding extensions.completeExt_def extensions.admissibleExt_def
        extensions.conflictfreeExt_def defends_rel_def bio_att_def
      by (auto simp: bio_all bio_ex)
  qed
  show "shared_conclusion bio_left_agent bio_att bio_con True"
    using left unfolding shared_conclusion_def proximal_explanation_def
    by (auto simp: bio_ex)
  show "shared_conclusion bio_right_agent bio_att bio_con True"
    using right unfolding shared_conclusion_def proximal_explanation_def
    by (auto simp: bio_ex)
qed

lemma bio_complete:
  "extensions.completeExt (\<lambda>_. True) bio_att E \<longleftrightarrow>
    (E \<approx> (\<lambda>_. False)) \<or> E \<approx> bio_left \<or> E \<approx> bio_right"
  unfolding extensions.completeExt_def extensions.admissibleExt_def
    extensions.conflictfreeExt_def defends_rel_def bio_att_def
  by (auto simp: bio_all bio_ex; blast)

lemma bio_left_preferred: "extensions.preferredExt (\<lambda>_. True) bio_att bio_left"
  unfolding extensions.preferredExt_def maximal_rel_def bio_complete id_def
  by (auto simp: bio_all)

lemma bio_right_preferred: "extensions.preferredExt (\<lambda>_. True) bio_att bio_right"
  unfolding extensions.preferredExt_def maximal_rel_def bio_complete id_def
  by (auto simp: bio_all)

lemma bio_preferred:
  "extensions.preferredExt (\<lambda>_. True) bio_att E \<longleftrightarrow>
    E \<approx> bio_left \<or> E \<approx> bio_right"
proof
  assume pref: "extensions.preferredExt (\<lambda>_. True) bio_att E"
  have comp: "extensions.completeExt (\<lambda>_. True) bio_att E"
    using pref unfolding extensions.preferredExt_def maximal_rel_def by blast
  have left_comp: "extensions.completeExt (\<lambda>_. True) bio_att bio_left"
    using bio_left_preferred unfolding extensions.preferredExt_def maximal_rel_def by blast
  have nonempty: "\<not> E \<approx> (\<lambda>_. False)"
  proof
    assume empty: "E \<approx> (\<lambda>_. False)"
    have sub: "E \<subseteq> bio_left" using empty by blast
    have "bio_left \<approx> E"
      using pref left_comp sub
      unfolding extensions.preferredExt_def maximal_rel_def id_def by blast
    then show False using empty by (auto simp: bio_all)
  qed
  show "E \<approx> bio_left \<or> E \<approx> bio_right"
    using comp nonempty by (auto simp: bio_complete)
next
  assume "E \<approx> bio_left \<or> E \<approx> bio_right"
  then have "E = bio_left \<or> E = bio_right" by (auto simp: fun_eq_iff)
  then show "extensions.preferredExt (\<lambda>_. True) bio_att E"
    using bio_left_preferred bio_right_preferred by auto
qed

lemma bio_shared_argument: "shared_argument (\<lambda>_. True) bio_att bio_con True"
  unfolding shared_argument_def proximal_explanation_def
  by (auto simp: bio_preferred bio_all bio_ex)

lemma bio_no_shared_explanation: "\<not> shared_explanation (\<lambda>_. True) bio_att bio_con True"
proof
  assume strong: "shared_explanation (\<lambda>_. True) bio_att bio_con True"
  obtain E where expl: "explanation (\<lambda>_. True) bio_att bio_con True E"
    and shared: "\<forall>P. extensions.preferredExt (\<lambda>_. True) bio_att P \<longrightarrow> E \<subseteq> P"
    using strong unfolding shared_explanation_def by blast
  have support: "explanation_support (\<lambda>_. True) bio_att bio_con True E"
    by (rule explanation_has_support[OF expl])
  have left: "E \<subseteq> bio_left"
    using shared[rule_format, OF bio_left_preferred] by blast
  have right: "E \<subseteq> bio_right"
    using shared[rule_format, OF bio_right_preferred] by blast
  have member: "E A1"
    using support unfolding explanation_support_def by (auto simp: bio_ex)
  have defended: "defends_rel (\<lambda>_. True) bio_att E A1"
    using support member unfolding explanation_support_def by blast
  have no_defender: "\<not> E A3 \<and> \<not> E A4"
    using left right by (auto simp: bio_all)
  show False using defended no_defender
    unfolding defends_rel_def bio_att_def by (auto simp: bio_all bio_ex)
qed

lemma bio_distal_but_not_proximal:
  "distal_disagreement (\<lambda>_. True) bio_att bio_con True \<and>
    \<not> proximal_disagreement (\<lambda>_. True) bio_att bio_con True"
  by (simp add: bio_no_shared_explanation bio_shared_argument distal_disagreement_def proximal_disagreement_def shared_argument_imp_shared_conclusion)

lemma bio_A1_not_weak_spot: "\<not> weak_spot (\<lambda>_. True) bio_att bio_con True A1"
  by (rule removing_the_only_concluder_is_not_a_weak_spot) simp

lemma bio_potential_and_actual_distal:
  "potential_distal_disagreement bio_left_agent bio_right_agent bio_att bio_con True \<and>
    distal_implicit_disagreement bio_left_agent bio_right_agent bio_att bio_con True"
proof -
  have no_shared:
    "\<not> shared_explanation (coalition bio_left_agent bio_right_agent) bio_att bio_con True"
    by (subst bio_coalition_all, rule bio_no_shared_explanation)
  have distal:
    "distal_disagreement (coalition bio_left_agent bio_right_agent) bio_att bio_con True"
    by (subst bio_coalition_all, rule conjunct1[OF bio_distal_but_not_proximal])
  show ?thesis using bio_agents_share_conclusion no_shared distal
    unfolding potential_distal_disagreement_def by blast
qed

text \<open>The locus of the distal disagreement on the conclusion of A1. The
explanations contained in a preferred extension are exactly the two preferred
extensions themselves: inside \<open>bio_left\<close> a support must contain A1 (the concluder),
A3 (to defend A1 against A2, A4 being absent) and A5 (to defend A3 against A6);
symmetrically for \<open>bio_right\<close>. The locus is therefore the symmetric difference
of the two extensions: A3, A4, A5 and A6.\<close>
lemma bio_left_support_forces:
  assumes "explanation_support (\<lambda>_. True) bio_att bio_con True X"
    and "X \<subseteq> bio_left"
  shows "X = bio_left"
  using assms unfolding explanation_support_def defends_rel_def bio_att_def
  by (auto simp: fun_eq_iff bio_all bio_ex)

lemma bio_right_support_forces:
  assumes "explanation_support (\<lambda>_. True) bio_att bio_con True X"
    and "X \<subseteq> bio_right"
  shows "X = bio_right"
  using assms unfolding explanation_support_def defends_rel_def bio_att_def
  by (auto simp: fun_eq_iff bio_all bio_ex)

lemma bio_left_explanation: "explanation (\<lambda>_. True) bio_att bio_con True bio_left"
proof -
  have supp: "explanation_support (\<lambda>_. True) bio_att bio_con True bio_left"
    unfolding explanation_support_def defends_rel_def extensions.conflictfreeExt_def
      bio_att_def
    by (auto simp: bio_all bio_ex)
  show ?thesis
    unfolding explanation_def minimal_def id_def
    using supp by (auto dest: bio_left_support_forces)
qed

lemma bio_right_explanation: "explanation (\<lambda>_. True) bio_att bio_con True bio_right"
proof -
  have supp: "explanation_support (\<lambda>_. True) bio_att bio_con True bio_right"
    unfolding explanation_support_def defends_rel_def extensions.conflictfreeExt_def
      bio_att_def
    by (auto simp: bio_all bio_ex)
  show ?thesis
    unfolding explanation_def minimal_def id_def
    using supp by (auto dest: bio_right_support_forces)
qed

lemma bio_accepted_explanations:
  "accepted_explanation (\<lambda>_. True) bio_att bio_con True E \<longleftrightarrow>
    E = bio_left \<or> E = bio_right"
proof
  assume "accepted_explanation (\<lambda>_. True) bio_att bio_con True E"
  then obtain P where expl: "explanation (\<lambda>_. True) bio_att bio_con True E"
    and P: "extensions.preferredExt (\<lambda>_. True) bio_att P" and EP: "E \<subseteq> P"
    unfolding accepted_explanation_def by blast
  have supp: "explanation_support (\<lambda>_. True) bio_att bio_con True E"
    by (rule explanation_has_support[OF expl])
  from P consider "P = bio_left" | "P = bio_right"
    by (auto simp: bio_preferred fun_eq_iff)
  then show "E = bio_left \<or> E = bio_right"
  proof cases
    case 1
    with EP have "E \<subseteq> bio_left" by auto
    thus ?thesis using bio_left_support_forces[OF supp] by blast
  next
    case 2
    with EP have "E \<subseteq> bio_right" by auto
    thus ?thesis using bio_right_support_forces[OF supp] by blast
  qed
next
  assume "E = bio_left \<or> E = bio_right"
  thus "accepted_explanation (\<lambda>_. True) bio_att bio_con True E"
    unfolding accepted_explanation_def
    using bio_left_explanation bio_right_explanation bio_left_preferred bio_right_preferred
    by blast
qed

lemma bio_locus:
  "locus (\<lambda>_. True) bio_att bio_con True x \<longleftrightarrow>
    x = A3 \<or> x = A4 \<or> x = A5 \<or> x = A6"
  unfolding locus_def bio_accepted_explanations by (cases x) auto

lemma bio_locus_set:
  "locus (\<lambda>_. True) bio_att bio_con True =
    (\<lambda>x. x = A3 \<or> x = A4 \<or> x = A5 \<or> x = A6)"
  by (auto simp: fun_eq_iff bio_locus)

lemma bio_coalition_locus:
  "locus (coalition bio_left_agent bio_right_agent) bio_att bio_con True =
    (\<lambda>x. x = A3 \<or> x = A4 \<or> x = A5 \<or> x = A6)"
  by (subst bio_coalition_all) (rule bio_locus_set)

text \<open>The paper's weak-spot analysis: removing A3 (or A4) turns the shared
conclusion of A1 into ordinary disagreement. After deleting A3 the preferred
extensions are, restricted to the remaining universe, exactly the patterns
below: one still supports A1, the other does not.\<close>

text \<open>The deleted-argument universes are proper definitions, not abbreviations:
an opaque constant keeps higher-order rewriting with the characterization
lemmas first-order, so the preferred-extension proofs stay one-liners. The
membership lemma lets applied occurrences still compute.\<close>

definition bio_minus :: "bio_argument \<Rightarrow> bio_argument Set" where
  "bio_minus a = remove_argument (\<lambda>_. True) a"

lemma bio_minus_mem [simp]: "bio_minus a x \<longleftrightarrow> x \<noteq> a"
  unfolding bio_minus_def by simp

lemma bio_minus3_complete:
  "extensions.completeExt (bio_minus A3) bio_att E \<longleftrightarrow>
     (\<not> E A1 \<and> \<not> E A2 \<and> \<not> E A4 \<and> \<not> E A5 \<and> \<not> E A6) \<or>
     (\<not> E A1 \<and> E A2 \<and> \<not> E A4 \<and> E A5 \<and> \<not> E A6) \<or>
     (E A1 \<and> \<not> E A2 \<and> E A4 \<and> \<not> E A5 \<and> E A6)"
  unfolding extensions.completeExt_def extensions.admissibleExt_def
    extensions.conflictfreeExt_def defends_rel_def bio_att_def
  by (auto simp: bio_all bio_ex; blast)

lemma bio_minus3_left_preferred:
  "extensions.preferredExt (bio_minus A3) bio_att \<lbrace>A2,A5\<rbrace>"
  unfolding extensions.preferredExt_def maximal_rel_def id_def
  by (auto simp: bio_minus3_complete bio_all)

lemma bio_minus3_right_preferred:
  "extensions.preferredExt (bio_minus A3) bio_att \<lbrace>A1,A4,A6\<rbrace>"
  unfolding extensions.preferredExt_def maximal_rel_def id_def
  by (auto simp: bio_minus3_complete bio_all)

lemma bio_A3_weak_spot: "weak_spot (\<lambda>_. True) bio_att bio_con True A3"
proof -
  have shared: "shared_conclusion (\<lambda>_. True) bio_att bio_con True"
    by (rule shared_argument_imp_shared_conclusion[OF bio_shared_argument])
  have cred: "credulous_conclusion (bio_minus A3) bio_att bio_con True"
    unfolding credulous_conclusion_def proximal_explanation_def
    using bio_minus3_right_preferred by fastforce
  have nshared: "\<not> shared_conclusion (bio_minus A3) bio_att bio_con True"
    unfolding shared_conclusion_def proximal_explanation_def
    using bio_minus3_left_preferred by (auto simp: bio_ex)
  show ?thesis
    unfolding weak_spot_def disagrees_that_def bio_minus_def[symmetric]
    using shared cred nshared by simp
qed

lemma bio_minus4_complete:
  "extensions.completeExt (bio_minus A4) bio_att E \<longleftrightarrow>
     (\<not> E A1 \<and> \<not> E A2 \<and> \<not> E A3 \<and> \<not> E A5 \<and> \<not> E A6) \<or>
     (\<not> E A1 \<and> E A2 \<and> \<not> E A3 \<and> \<not> E A5 \<and> E A6) \<or>
     (E A1 \<and> \<not> E A2 \<and> E A3 \<and> E A5 \<and> \<not> E A6)"
  unfolding extensions.completeExt_def extensions.admissibleExt_def
    extensions.conflictfreeExt_def defends_rel_def bio_att_def
  by (auto simp: bio_all bio_ex; blast)

lemma bio_minus4_left_preferred:
  "extensions.preferredExt (bio_minus A4) bio_att \<lbrace>A2,A6\<rbrace>"
  unfolding extensions.preferredExt_def maximal_rel_def id_def
  by (auto simp: bio_minus4_complete bio_all)

lemma bio_minus4_right_preferred:
  "extensions.preferredExt (bio_minus A4) bio_att \<lbrace>A1,A3,A5\<rbrace>"
  unfolding extensions.preferredExt_def maximal_rel_def id_def
  by (auto simp: bio_minus4_complete bio_all)

lemma bio_A4_weak_spot: "weak_spot (\<lambda>_. True) bio_att bio_con True A4"
proof -
  have shared: "shared_conclusion (\<lambda>_. True) bio_att bio_con True"
    by (rule shared_argument_imp_shared_conclusion[OF bio_shared_argument])
  have cred: "credulous_conclusion (bio_minus A4) bio_att bio_con True"
    unfolding credulous_conclusion_def proximal_explanation_def
    using bio_minus4_right_preferred by fastforce
  have nshared: "\<not> shared_conclusion (bio_minus A4) bio_att bio_con True"
    unfolding shared_conclusion_def proximal_explanation_def
    using bio_minus4_left_preferred by (auto simp: bio_ex)
  show ?thesis
    unfolding weak_spot_def disagrees_that_def bio_minus_def[symmetric]
    using shared cred nshared by simp
qed

text \<open>The paper's antagonists: removing A2, A5 or A6 turns the distal
disagreement into agreement from a shared explanation. In each case an
explicit explanation is contained in every preferred extension of the
reduced framework.\<close>

lemma bio_A2_antagonist: "antagonist (\<lambda>_. True) bio_att bio_con True A2"
proof -
  have expl: "explanation (bio_minus A2) bio_att bio_con True \<lbrace>A1\<rbrace>"
    unfolding explanation_def minimal_def explanation_support_def defends_rel_def id_def
      extensions.conflictfreeExt_def
    by (auto simp: bio_att_def bio_all bio_ex)
  have inall: "\<lbrace>A1\<rbrace> \<subseteq> P" if "extensions.preferredExt (bio_minus A2) bio_att P" for P
  proof -
    have "extensions.completeExt (bio_minus A2) bio_att P"
      using that unfolding extensions.preferredExt_def maximal_rel_def by blast
    then show ?thesis
      unfolding extensions.completeExt_def extensions.admissibleExt_def
        extensions.conflictfreeExt_def defends_rel_def bio_att_def
      by (auto simp: bio_all bio_ex)
  qed
  have sh: "shared_explanation (bio_minus A2) bio_att bio_con True"
    unfolding shared_explanation_def using expl inall by blast
  show ?thesis
    unfolding antagonist_def bio_minus_def[symmetric]
    using conjunct1[OF bio_distal_but_not_proximal] sh by simp
qed

lemma bio_A5_antagonist: "antagonist (\<lambda>_. True) bio_att bio_con True A5"
proof -
  have expl: "explanation (bio_minus A5) bio_att bio_con True \<lbrace>A1,A4\<rbrace>"
    unfolding explanation_def minimal_def explanation_support_def defends_rel_def id_def
      extensions.conflictfreeExt_def
    by (auto simp: bio_att_def bio_all bio_ex)
  have inall: "\<lbrace>A1,A4\<rbrace> \<subseteq> P" if "extensions.preferredExt (bio_minus A5) bio_att P" for P
  proof -
    have comp: "extensions.completeExt (bio_minus A5) bio_att P"
      using that unfolding extensions.preferredExt_def maximal_rel_def by blast
    have p4: "P A4"
      using comp unfolding extensions.completeExt_def extensions.admissibleExt_def
        extensions.conflictfreeExt_def defends_rel_def bio_att_def
      by (auto simp: bio_all bio_ex)
    have p1: "P A1"
      using comp p4 unfolding extensions.completeExt_def extensions.admissibleExt_def
        extensions.conflictfreeExt_def defends_rel_def bio_att_def
      by (auto simp: bio_all bio_ex)
    show ?thesis using p1 p4 by (auto simp: bio_all)
  qed
  have sh: "shared_explanation (bio_minus A5) bio_att bio_con True"
    unfolding shared_explanation_def using expl inall by blast
  show ?thesis
    unfolding antagonist_def bio_minus_def[symmetric]
    using conjunct1[OF bio_distal_but_not_proximal] sh by simp
qed

lemma bio_A6_antagonist: "antagonist (\<lambda>_. True) bio_att bio_con True A6"
proof -
  have expl: "explanation (bio_minus A6) bio_att bio_con True \<lbrace>A1,A3\<rbrace>"
    unfolding explanation_def minimal_def explanation_support_def defends_rel_def id_def
      extensions.conflictfreeExt_def
    by (auto simp: bio_att_def bio_all bio_ex)
  have inall: "\<lbrace>A1,A3\<rbrace> \<subseteq> P" if "extensions.preferredExt (bio_minus A6) bio_att P" for P
  proof -
    have comp: "extensions.completeExt (bio_minus A6) bio_att P"
      using that unfolding extensions.preferredExt_def maximal_rel_def by blast
    have p3: "P A3"
      using comp unfolding extensions.completeExt_def extensions.admissibleExt_def
        extensions.conflictfreeExt_def defends_rel_def bio_att_def
      by (auto simp: bio_all bio_ex)
    have p1: "P A1"
      using comp p3 unfolding extensions.completeExt_def extensions.admissibleExt_def
        extensions.conflictfreeExt_def defends_rel_def bio_att_def
      by (auto simp: bio_all bio_ex)
    show ?thesis using p1 p3 by (auto simp: bio_all)
  qed
  have sh: "shared_explanation (bio_minus A6) bio_att bio_con True"
    unfolding shared_explanation_def using expl inall by blast
  show ?thesis
    unfolding antagonist_def bio_minus_def[symmetric]
    using conjunct1[OF bio_distal_but_not_proximal] sh by simp
qed

text \<open>The coalition-only example of the paper, witnessing the distal case in
which the agents cannot derive the conclusion individually:
each agent's own argument (CE resp.\ CF) defeats its defender of CA, so
neither agent accepts CA individually. In the coalition CE and CF attack
each other, every preferred extension keeps exactly one of them, and CA is
accepted in all of them---yet no explanation is shared. This yields distal
implicit disagreement that is not potential disagreement.\<close>

datatype (plugins only: code) co_argument = CA | CB | CE | CF | CG | CH

definition co_att :: "co_argument Rel" where
  "co_att a b \<longleftrightarrow>
    (a = CB \<and> b = CA) \<or> (a = CG \<and> b = CB) \<or> (a = CH \<and> b = CB) \<or>
    (a = CE \<and> b = CG) \<or> (a = CF \<and> b = CH) \<or>
    (a = CE \<and> b = CF) \<or> (a = CF \<and> b = CE)"

abbreviation co_con :: "co_argument \<Rightarrow> bool" where "co_con a \<equiv> a = CA"

definition co_alpha :: "co_argument Set" where
  "co_alpha = \<lbrace>CA,CB\<rbrace> \<union> \<lbrace>CE,CG\<rbrace>"

definition co_beta :: "co_argument Set" where
  "co_beta = \<lbrace>CA,CB\<rbrace> \<union> \<lbrace>CF,CH\<rbrace>"

lemma co_alpha_mem [simp]: "co_alpha x \<longleftrightarrow> x = CA \<or> x = CB \<or> x = CE \<or> x = CG"
  unfolding co_alpha_def by auto

lemma co_beta_mem [simp]: "co_beta x \<longleftrightarrow> x = CA \<or> x = CB \<or> x = CF \<or> x = CH"
  unfolding co_beta_def by auto

abbreviation co_left where "co_left \<equiv> \<lbrace>CA,CE,CH\<rbrace>"
abbreviation co_right where "co_right \<equiv> \<lbrace>CA,CF,CG\<rbrace>"

lemma co_all:
  "(\<forall>x::co_argument. P x) \<longleftrightarrow>
    P CA \<and> P CB \<and> P CE \<and> P CF \<and> P CG \<and> P CH"
  by (metis co_argument.exhaust)

lemma co_ex:
  "(\<exists>x::co_argument. P x) \<longleftrightarrow>
    P CA \<or> P CB \<or> P CE \<or> P CF \<or> P CG \<or> P CH"
  by (metis co_argument.exhaust)

lemma co_agents_wellformed:
  "is_agent (\<lambda>_. True) co_att co_alpha (induced_att co_att co_alpha) \<and>
    is_agent (\<lambda>_. True) co_att co_beta (induced_att co_att co_beta)"
  unfolding is_agent_def by simp

lemma co_coalition_all: "coalition co_alpha co_beta = (\<lambda>_. True)"
  by (auto simp: fun_eq_iff co_all)

lemma co_alpha_complete:
  "extensions.completeExt co_alpha co_att E \<longleftrightarrow>
     (\<not> E CA \<and> E CB \<and> E CE \<and> \<not> E CG)"
  unfolding extensions.completeExt_def extensions.admissibleExt_def
    extensions.conflictfreeExt_def defends_rel_def co_att_def
  by (auto simp: co_all co_ex)

lemma co_beta_complete:
  "extensions.completeExt co_beta co_att E \<longleftrightarrow>
     (\<not> E CA \<and> E CB \<and> E CF \<and> \<not> E CH)"
  unfolding extensions.completeExt_def extensions.admissibleExt_def
    extensions.conflictfreeExt_def defends_rel_def co_att_def
  by (auto simp: co_all co_ex)

lemma co_agents_reject:
  "\<not> shared_conclusion co_alpha co_att co_con True \<and>
    \<not> shared_conclusion co_beta co_att co_con True"
proof -
  have a: "\<not> shared_conclusion co_alpha co_att co_con True"
  proof
    assume sh: "shared_conclusion co_alpha co_att co_con True"
    obtain E where pref: "extensions.preferredExt co_alpha co_att E"
      using preferred_extensions_exist by blast
    have "extensions.completeExt co_alpha co_att E"
      using pref unfolding extensions.preferredExt_def maximal_rel_def by blast
    then show False
      using sh pref unfolding shared_conclusion_def proximal_explanation_def
      by (auto simp: co_alpha_complete)
  qed
  have b: "\<not> shared_conclusion co_beta co_att co_con True"
  proof
    assume sh: "shared_conclusion co_beta co_att co_con True"
    obtain E where pref: "extensions.preferredExt co_beta co_att E"
      using preferred_extensions_exist by blast
    have "extensions.completeExt co_beta co_att E"
      using pref unfolding extensions.preferredExt_def maximal_rel_def by blast
    then show False
      using sh pref unfolding shared_conclusion_def proximal_explanation_def
      by (auto simp: co_beta_complete)
  qed
  show ?thesis using a b by blast
qed

lemma co_complete:
  "extensions.completeExt (\<lambda>_. True) co_att E \<longleftrightarrow>
    (E \<approx> (\<lambda>_. False)) \<or> E \<approx> co_left \<or> E \<approx> co_right"
  unfolding extensions.completeExt_def extensions.admissibleExt_def
    extensions.conflictfreeExt_def defends_rel_def co_att_def
  by (auto simp: co_all co_ex; blast)

lemma co_left_preferred: "extensions.preferredExt (\<lambda>_. True) co_att co_left"
  unfolding extensions.preferredExt_def maximal_rel_def co_complete id_def
  by (auto simp: co_all)

lemma co_right_preferred: "extensions.preferredExt (\<lambda>_. True) co_att co_right"
  unfolding extensions.preferredExt_def maximal_rel_def co_complete id_def
  by (auto simp: co_all)

lemma co_preferred:
  "extensions.preferredExt (\<lambda>_. True) co_att E \<longleftrightarrow>
    E \<approx> co_left \<or> E \<approx> co_right"
proof
  assume pref: "extensions.preferredExt (\<lambda>_. True) co_att E"
  have comp: "extensions.completeExt (\<lambda>_. True) co_att E"
    using pref unfolding extensions.preferredExt_def maximal_rel_def by blast
  have left_comp: "extensions.completeExt (\<lambda>_. True) co_att co_left"
    using co_left_preferred unfolding extensions.preferredExt_def maximal_rel_def by blast
  have nonempty: "\<not> E \<approx> (\<lambda>_. False)"
  proof
    assume empty: "E \<approx> (\<lambda>_. False)"
    have sub: "E \<subseteq> co_left" using empty by blast
    have "co_left \<approx> E"
      using pref left_comp sub
      unfolding extensions.preferredExt_def maximal_rel_def id_def by blast
    then show False using empty by (auto simp: co_all)
  qed
  show "E \<approx> co_left \<or> E \<approx> co_right"
    using comp nonempty by (auto simp: co_complete)
next
  assume "E \<approx> co_left \<or> E \<approx> co_right"
  then have "E = co_left \<or> E = co_right" by (auto simp: fun_eq_iff)
  then show "extensions.preferredExt (\<lambda>_. True) co_att E"
    using co_left_preferred co_right_preferred by auto
qed

lemma co_shared_argument: "shared_argument (\<lambda>_. True) co_att co_con True"
  unfolding shared_argument_def proximal_explanation_def
  by (auto simp: co_preferred co_all co_ex)

lemma co_no_shared_explanation: "\<not> shared_explanation (\<lambda>_. True) co_att co_con True"
proof
  assume strong: "shared_explanation (\<lambda>_. True) co_att co_con True"
  obtain E where expl: "explanation (\<lambda>_. True) co_att co_con True E"
    and shared: "\<forall>P. extensions.preferredExt (\<lambda>_. True) co_att P \<longrightarrow> E \<subseteq> P"
    using strong unfolding shared_explanation_def by blast
  have support: "explanation_support (\<lambda>_. True) co_att co_con True E"
    by (rule explanation_has_support[OF expl])
  have left: "E \<subseteq> co_left"
    using shared[rule_format, OF co_left_preferred] by blast
  have right: "E \<subseteq> co_right"
    using shared[rule_format, OF co_right_preferred] by blast
  have member: "E CA"
    using support unfolding explanation_support_def by (auto simp: co_ex)
  have defended: "defends_rel (\<lambda>_. True) co_att E CA"
    using support member unfolding explanation_support_def by blast
  have no_defender: "\<not> E CG \<and> \<not> E CH"
    using left right by (auto simp: co_all)
  show False using defended no_defender
    unfolding defends_rel_def co_att_def by (auto simp: co_all co_ex)
qed

theorem co_distal_disagreement_only_in_coalition:
  "\<not> shared_conclusion co_alpha co_att co_con True \<and>
    \<not> shared_conclusion co_beta co_att co_con True \<and>
    distal_implicit_disagreement co_alpha co_beta co_att co_con True \<and>
    \<not> potential_distal_disagreement co_alpha co_beta co_att co_con True"
proof -
  have shared: "shared_conclusion (\<lambda>_. True) co_att co_con True"
    by (rule shared_argument_imp_shared_conclusion[OF co_shared_argument])
  have distal: "distal_disagreement (coalition co_alpha co_beta) co_att co_con True"
    unfolding distal_disagreement_def
    by (subst co_coalition_all)+ (use shared co_no_shared_explanation in blast)
  have npot: "\<not> potential_distal_disagreement co_alpha co_beta co_att co_con True"
    using co_agents_reject unfolding potential_distal_disagreement_def by blast
  show ?thesis using co_agents_reject distal npot by blast
qed

section \<open>Locus versus weak spots\<close>

text \<open>The locus and the weak spots are independent notions. First example: three
pairwise conflicting defenders T3, T4, T5 of the concluder T1 against T2. The
locus is {T3, T4, T5}, yet deleting T3 leaves the two other explanations in
place, so T3 is neither a weak spot nor an antagonist.\<close>
datatype (plugins only: code) tri_argument = T1 | T2 | T3 | T4 | T5

definition tri_att :: "tri_argument Rel" where
  "tri_att a b \<longleftrightarrow>
    (a = T2 \<and> b = T1) \<or> (a = T3 \<and> b = T2) \<or> (a = T4 \<and> b = T2) \<or> (a = T5 \<and> b = T2) \<or>
    (a = T3 \<and> b = T4) \<or> (a = T4 \<and> b = T3) \<or> (a = T4 \<and> b = T5) \<or> (a = T5 \<and> b = T4) \<or>
    (a = T3 \<and> b = T5) \<or> (a = T5 \<and> b = T3)"

abbreviation tri_con where "tri_con a \<equiv> a = T1"

lemma tri_all:
  "(\<forall>x::tri_argument. P x) \<longleftrightarrow> P T1 \<and> P T2 \<and> P T3 \<and> P T4 \<and> P T5"
  by (metis tri_argument.exhaust)

lemma tri_ex:
  "(\<exists>x::tri_argument. P x) \<longleftrightarrow> P T1 \<or> P T2 \<or> P T3 \<or> P T4 \<or> P T5"
  by (metis tri_argument.exhaust)

text \<open>The characterizations of complete extensions below are decided by splitting
on the membership of every argument first (the resulting goals are ground), which
is far cheaper than letting \<open>auto\<close> search the propositional problem.\<close>
lemma tri_complete:
  "extensions.completeExt (\<lambda>_. True) tri_att E \<longleftrightarrow>
    E \<approx> (\<lambda>_. False) \<or> E \<approx> \<lbrace>T1,T3\<rbrace> \<or> E \<approx> \<lbrace>T1,T4\<rbrace> \<or> E \<approx> \<lbrace>T1,T5\<rbrace>"
  unfolding extensions.completeExt_def extensions.admissibleExt_def
    extensions.conflictfreeExt_def defends_rel_def tri_att_def
  by (cases "E T1"; cases "E T2"; cases "E T3"; cases "E T4"; cases "E T5";
      simp add: tri_all tri_ex)

lemma tri_pref3: "extensions.preferredExt (\<lambda>_. True) tri_att \<lbrace>T1,T3\<rbrace>"
  unfolding extensions.preferredExt_def maximal_rel_def id_def
  by (auto simp: tri_complete tri_all)

lemma tri_pref4: "extensions.preferredExt (\<lambda>_. True) tri_att \<lbrace>T1,T4\<rbrace>"
  unfolding extensions.preferredExt_def maximal_rel_def id_def
  by (auto simp: tri_complete tri_all)

lemma tri_pref5: "extensions.preferredExt (\<lambda>_. True) tri_att \<lbrace>T1,T5\<rbrace>"
  unfolding extensions.preferredExt_def maximal_rel_def id_def
  by (auto simp: tri_complete tri_all)

lemma tri_preferred:
  "extensions.preferredExt (\<lambda>_. True) tri_att E \<longleftrightarrow>
    E \<approx> \<lbrace>T1,T3\<rbrace> \<or> E \<approx> \<lbrace>T1,T4\<rbrace> \<or> E \<approx> \<lbrace>T1,T5\<rbrace>"
proof
  assume pref: "extensions.preferredExt (\<lambda>_. True) tri_att E"
  have comp: "extensions.completeExt (\<lambda>_. True) tri_att E"
    using pref unfolding extensions.preferredExt_def maximal_rel_def by blast
  have c3: "extensions.completeExt (\<lambda>_. True) tri_att \<lbrace>T1,T3\<rbrace>"
    using tri_pref3 unfolding extensions.preferredExt_def maximal_rel_def by blast
  have nonempty: "\<not> E \<approx> (\<lambda>_. False)"
  proof
    assume empty: "E \<approx> (\<lambda>_. False)"
    have sub: "E \<subseteq> \<lbrace>T1,T3\<rbrace>" using empty by blast
    have "\<lbrace>T1,T3\<rbrace> \<approx> E"
      using pref c3 sub
      unfolding extensions.preferredExt_def maximal_rel_def id_def by blast
    then show False using empty by (auto simp: tri_all)
  qed
  show "E \<approx> \<lbrace>T1,T3\<rbrace> \<or> E \<approx> \<lbrace>T1,T4\<rbrace> \<or> E \<approx> \<lbrace>T1,T5\<rbrace>"
    using comp nonempty by (auto simp: tri_complete)
next
  assume "E \<approx> \<lbrace>T1,T3\<rbrace> \<or> E \<approx> \<lbrace>T1,T4\<rbrace> \<or> E \<approx> \<lbrace>T1,T5\<rbrace>"
  then have "E = \<lbrace>T1,T3\<rbrace> \<or> E = \<lbrace>T1,T4\<rbrace> \<or> E = \<lbrace>T1,T5\<rbrace>"
    by (auto simp: fun_eq_iff)
  then show "extensions.preferredExt (\<lambda>_. True) tri_att E"
    using tri_pref3 tri_pref4 tri_pref5 by auto
qed

lemma tri_shared_argument: "shared_argument (\<lambda>_. True) tri_att tri_con True"
  unfolding shared_argument_def proximal_explanation_def
  by (auto simp: tri_preferred tri_all tri_ex)

lemma tri_no_shared_explanation: "\<not> shared_explanation (\<lambda>_. True) tri_att tri_con True"
proof
  assume strong: "shared_explanation (\<lambda>_. True) tri_att tri_con True"
  obtain E where expl: "explanation (\<lambda>_. True) tri_att tri_con True E"
    and shared: "\<forall>P. extensions.preferredExt (\<lambda>_. True) tri_att P \<longrightarrow> E \<subseteq> P"
    using strong unfolding shared_explanation_def by blast
  have support: "explanation_support (\<lambda>_. True) tri_att tri_con True E"
    by (rule explanation_has_support[OF expl])
  have s3: "E \<subseteq> \<lbrace>T1,T3\<rbrace>" using shared[rule_format, OF tri_pref3] by blast
  have s4: "E \<subseteq> \<lbrace>T1,T4\<rbrace>" using shared[rule_format, OF tri_pref4] by blast
  have member: "E T1"
    using support unfolding explanation_support_def by (auto simp: tri_ex)
  have defended: "defends_rel (\<lambda>_. True) tri_att E T1"
    using support member unfolding explanation_support_def by blast
  have no_defender: "\<not> E T3 \<and> \<not> E T4 \<and> \<not> E T5"
    using s3 s4 by (auto simp: tri_all)
  show False using defended no_defender
    unfolding defends_rel_def tri_att_def by (auto simp: tri_all tri_ex)
qed

lemma tri_distal: "distal_disagreement (\<lambda>_. True) tri_att tri_con True"
  by (simp add: distal_disagreement_def shared_argument_imp_shared_conclusion tri_no_shared_explanation tri_shared_argument)

lemma tri_support_forces:
  assumes "explanation_support (\<lambda>_. True) tri_att tri_con True X"
  shows "X \<subseteq> \<lbrace>T1,T3\<rbrace> \<Longrightarrow> X = \<lbrace>T1,T3\<rbrace>"
    and "X \<subseteq> \<lbrace>T1,T4\<rbrace> \<Longrightarrow> X = \<lbrace>T1,T4\<rbrace>"
    and "X \<subseteq> \<lbrace>T1,T5\<rbrace> \<Longrightarrow> X = \<lbrace>T1,T5\<rbrace>"
  using assms unfolding explanation_support_def defends_rel_def tri_att_def
  by (auto simp: fun_eq_iff tri_all tri_ex)

lemma tri_explanation3: "explanation (\<lambda>_. True) tri_att tri_con True \<lbrace>T1,T3\<rbrace>"
proof -
  have supp: "explanation_support (\<lambda>_. True) tri_att tri_con True \<lbrace>T1,T3\<rbrace>"
    unfolding explanation_support_def defends_rel_def extensions.conflictfreeExt_def tri_att_def
    by (auto simp: tri_all tri_ex)
  show ?thesis
    unfolding explanation_def minimal_def id_def
    using supp by (auto dest: tri_support_forces(1))
qed

lemma tri_explanation4: "explanation (\<lambda>_. True) tri_att tri_con True \<lbrace>T1,T4\<rbrace>"
proof -
  have supp: "explanation_support (\<lambda>_. True) tri_att tri_con True \<lbrace>T1,T4\<rbrace>"
    unfolding explanation_support_def defends_rel_def extensions.conflictfreeExt_def tri_att_def
    by (auto simp: tri_all tri_ex)
  show ?thesis
    unfolding explanation_def minimal_def id_def
    using supp by (auto dest: tri_support_forces(2))
qed

lemma tri_explanation5: "explanation (\<lambda>_. True) tri_att tri_con True \<lbrace>T1,T5\<rbrace>"
proof -
  have supp: "explanation_support (\<lambda>_. True) tri_att tri_con True \<lbrace>T1,T5\<rbrace>"
    unfolding explanation_support_def defends_rel_def extensions.conflictfreeExt_def tri_att_def
    by (auto simp: tri_all tri_ex)
  show ?thesis
    unfolding explanation_def minimal_def id_def
    using supp by (auto dest: tri_support_forces(3))
qed

lemma tri_accepted_explanations:
  "accepted_explanation (\<lambda>_. True) tri_att tri_con True E \<longleftrightarrow>
    E = \<lbrace>T1,T3\<rbrace> \<or> E = \<lbrace>T1,T4\<rbrace> \<or> E = \<lbrace>T1,T5\<rbrace>"
proof
  assume "accepted_explanation (\<lambda>_. True) tri_att tri_con True E"
  then obtain P where expl: "explanation (\<lambda>_. True) tri_att tri_con True E"
    and P: "extensions.preferredExt (\<lambda>_. True) tri_att P" and EP: "E \<subseteq> P"
    unfolding accepted_explanation_def by blast
  have supp: "explanation_support (\<lambda>_. True) tri_att tri_con True E"
    by (rule explanation_has_support[OF expl])
  from P consider "P = \<lbrace>T1,T3\<rbrace>" | "P = \<lbrace>T1,T4\<rbrace>" | "P = \<lbrace>T1,T5\<rbrace>"
    by (auto simp: tri_preferred fun_eq_iff)
  then show "E = \<lbrace>T1,T3\<rbrace> \<or> E = \<lbrace>T1,T4\<rbrace> \<or> E = \<lbrace>T1,T5\<rbrace>"
  proof cases
    case 1
    with EP have "E \<subseteq> \<lbrace>T1,T3\<rbrace>" by auto
    thus ?thesis using tri_support_forces(1)[OF supp] by blast
  next
    case 2
    with EP have "E \<subseteq> \<lbrace>T1,T4\<rbrace>" by auto
    thus ?thesis using tri_support_forces(2)[OF supp] by blast
  next
    case 3
    with EP have "E \<subseteq> \<lbrace>T1,T5\<rbrace>" by auto
    thus ?thesis using tri_support_forces(3)[OF supp] by blast
  qed
next
  assume "E = \<lbrace>T1,T3\<rbrace> \<or> E = \<lbrace>T1,T4\<rbrace> \<or> E = \<lbrace>T1,T5\<rbrace>"
  thus "accepted_explanation (\<lambda>_. True) tri_att tri_con True E"
    unfolding accepted_explanation_def
    using tri_explanation3 tri_explanation4 tri_explanation5 tri_pref3 tri_pref4 tri_pref5
    by blast
qed

lemma tri_locus:
  "locus (\<lambda>_. True) tri_att tri_con True x \<longleftrightarrow> x = T3 \<or> x = T4 \<or> x = T5"
  unfolding locus_def tri_accepted_explanations by (cases x) auto

definition tri_minus :: "tri_argument \<Rightarrow> tri_argument Set" where
  "tri_minus a = remove_argument (\<lambda>_. True) a"

lemma tri_minus_mem [simp]: "tri_minus a x \<longleftrightarrow> x \<noteq> a"
  unfolding tri_minus_def by simp

lemma tri_minus3_complete:
  "extensions.completeExt (tri_minus T3) tri_att E \<longleftrightarrow>
     (\<not> E T1 \<and> \<not> E T2 \<and> \<not> E T4 \<and> \<not> E T5) \<or>
     (E T1 \<and> \<not> E T2 \<and> E T4 \<and> \<not> E T5) \<or>
     (E T1 \<and> \<not> E T2 \<and> \<not> E T4 \<and> E T5)"
  unfolding extensions.completeExt_def extensions.admissibleExt_def
    extensions.conflictfreeExt_def defends_rel_def tri_att_def
  by (cases "E T1"; cases "E T2"; cases "E T4"; cases "E T5"; simp add: tri_all tri_ex)

lemma tri_minus3_pref4: "extensions.preferredExt (tri_minus T3) tri_att \<lbrace>T1,T4\<rbrace>"
  unfolding extensions.preferredExt_def maximal_rel_def id_def
  by (auto simp: tri_minus3_complete tri_all)

lemma tri_minus3_pref5: "extensions.preferredExt (tri_minus T3) tri_att \<lbrace>T1,T5\<rbrace>"
  unfolding extensions.preferredExt_def maximal_rel_def id_def
  by (auto simp: tri_minus3_complete tri_all)

lemma tri_minus3_preferred_has_T1:
  assumes pref: "extensions.preferredExt (tri_minus T3) tri_att P"
  shows "P T1"
proof (rule ccontr)
  assume n: "\<not> P T1"
  have comp: "extensions.completeExt (tri_minus T3) tri_att P"
    using pref unfolding extensions.preferredExt_def maximal_rel_def by blast
  have c4: "extensions.completeExt (tri_minus T3) tri_att \<lbrace>T1,T4\<rbrace>"
    using tri_minus3_pref4 unfolding extensions.preferredExt_def maximal_rel_def by blast
  have empty: "\<not> P T2 \<and> \<not> P T4 \<and> \<not> P T5"
    using comp n by (auto simp: tri_minus3_complete)
  have sub: "\<forall>x. tri_minus T3 x \<longrightarrow> P x \<longrightarrow> \<lbrace>T1,T4\<rbrace> x"
    using n empty by (auto simp: tri_all)
  have "\<forall>x. tri_minus T3 x \<longrightarrow> (\<lbrace>T1,T4\<rbrace> x \<longleftrightarrow> P x)"
    using pref c4 sub
    unfolding extensions.preferredExt_def maximal_rel_def id_def by blast
  thus False using n by (auto simp: tri_all)
qed

lemma tri_minus3_shared_conclusion: "shared_conclusion (tri_minus T3) tri_att tri_con True"
  unfolding shared_conclusion_def proximal_explanation_def
  by (simp add: tri_minus3_preferred_has_T1)

lemma tri_minus3_no_shared_explanation:
  "\<not> shared_explanation (tri_minus T3) tri_att tri_con True"
proof
  assume strong: "shared_explanation (tri_minus T3) tri_att tri_con True"
  obtain E where expl: "explanation (tri_minus T3) tri_att tri_con True E"
    and shared: "\<forall>P. extensions.preferredExt (tri_minus T3) tri_att P \<longrightarrow> E \<subseteq> P"
    using strong unfolding shared_explanation_def by blast
  have support: "explanation_support (tri_minus T3) tri_att tri_con True E"
    by (rule explanation_has_support[OF expl])
  have s4: "E \<subseteq> \<lbrace>T1,T4\<rbrace>" using shared[rule_format, OF tri_minus3_pref4] by blast
  have s5: "E \<subseteq> \<lbrace>T1,T5\<rbrace>" using shared[rule_format, OF tri_minus3_pref5] by blast
  have member: "E T1"
    using support unfolding explanation_support_def by (auto simp: tri_ex)
  have defended: "defends_rel (tri_minus T3) tri_att E T1"
    using support member unfolding explanation_support_def by blast
  have no_defender: "\<not> E T4 \<and> \<not> E T5"
    using s4 s5 by (auto simp: tri_all)
  show False using defended no_defender
    unfolding defends_rel_def tri_att_def by (auto simp: tri_all tri_ex)
qed

lemma tri_T3_not_weak_spot: "\<not> weak_spot (\<lambda>_. True) tri_att tri_con True T3"
  unfolding weak_spot_def disagrees_that_def tri_minus_def[symmetric]
  using tri_minus3_shared_conclusion by simp

lemma tri_T3_not_antagonist: "\<not> antagonist (\<lambda>_. True) tri_att tri_con True T3"
  unfolding antagonist_def tri_minus_def[symmetric]
  using tri_minus3_no_shared_explanation by simp

theorem tri_locus_element_neither:
  "distal_disagreement (\<lambda>_. True) tri_att tri_con True \<and>
   locus (\<lambda>_. True) tri_att tri_con True T3 \<and>
   \<not> weak_spot (\<lambda>_. True) tri_att tri_con True T3 \<and>
   \<not> antagonist (\<lambda>_. True) tri_att tri_con True T3"
  using tri_distal tri_T3_not_weak_spot tri_T3_not_antagonist by (simp add: tri_locus)

text \<open>Second example: the running example plus an unattacked gatekeeper GA that
keeps out GW, an argument attacking all four stances G3--G6 and attacked back by
G5 and G6. GA belongs to every preferred extension but to no explanation, since
G5 (resp. G6) already defends against GW; so GA is outside the locus. Deleting
GA lets {GW, G2} form a preferred extension without any argument for the issue,
so GA is a weak spot.\<close>
datatype (plugins only: code) gate_argument = G1 | G2 | G3 | G4 | G5 | G6 | GA | GW

text \<open>The fourteen edges are listed by attacker, so that a ground instance of the
relation is decided in a few rewrite steps.\<close>
definition gate_att :: "gate_argument Rel" where
  "gate_att a b \<longleftrightarrow> (case a of
      G1 \<Rightarrow> False
    | G2 \<Rightarrow> b = G1
    | G3 \<Rightarrow> b = G2
    | G4 \<Rightarrow> b = G2
    | G5 \<Rightarrow> b = G4 \<or> b = G6 \<or> b = GW
    | G6 \<Rightarrow> b = G3 \<or> b = G5 \<or> b = GW
    | GA \<Rightarrow> b = GW
    | GW \<Rightarrow> b = G3 \<or> b = G4 \<or> b = G5 \<or> b = G6)"

abbreviation gate_con where "gate_con a \<equiv> a = G1"
abbreviation gate_left where "gate_left \<equiv> \<lbrace>G1,G3,G5\<rbrace>"
abbreviation gate_right where "gate_right \<equiv> \<lbrace>G1,G4,G6\<rbrace>"
abbreviation gate_left_pref where "gate_left_pref \<equiv> gate_left \<union> \<lbrace>GA\<rbrace>"
abbreviation gate_right_pref where "gate_right_pref \<equiv> gate_right \<union> \<lbrace>GA\<rbrace>"

lemma gate_all:
  "(\<forall>x::gate_argument. P x) \<longleftrightarrow>
    P G1 \<and> P G2 \<and> P G3 \<and> P G4 \<and> P G5 \<and> P G6 \<and> P GA \<and> P GW"
  by (metis gate_argument.exhaust)

lemma gate_ex:
  "(\<exists>x::gate_argument. P x) \<longleftrightarrow>
    P G1 \<or> P G2 \<or> P G3 \<or> P G4 \<or> P G5 \<or> P G6 \<or> P GA \<or> P GW"
  by (metis gate_argument.exhaust)

lemma gate_complete_GA:
  assumes comp: "extensions.completeExt (\<lambda>_. True) gate_att E"
  shows "E GA \<and> \<not> E GW"
proof -
  have closed: "\<And>a. defends_rel (\<lambda>_. True) gate_att E a \<Longrightarrow> E a"
    using comp unfolding extensions.completeExt_def by blast
  have cf: "extensions.conflictfreeExt (\<lambda>_. True) gate_att E"
    using comp unfolding extensions.completeExt_def extensions.admissibleExt_def by blast
  have ga: "E GA"
    by (rule closed) (simp add: defends_rel_def gate_all gate_att_def)
  have "\<not> E GW"
    using cf[unfolded extensions.conflictfreeExt_def, rule_format, of GA GW] ga
    by (auto simp: gate_att_def)
  with ga show ?thesis by simp
qed

lemma gate_complete:
  "extensions.completeExt (\<lambda>_. True) gate_att E \<longleftrightarrow>
    E \<approx> \<lbrace>GA\<rbrace> \<or> E \<approx> gate_left_pref \<or> E \<approx> gate_right_pref"
proof
  assume comp: "extensions.completeExt (\<lambda>_. True) gate_att E"
  have ga: "E GA" and gw: "\<not> E GW" using gate_complete_GA[OF comp] by auto
  have closed: "\<And>a. defends_rel (\<lambda>_. True) gate_att E a \<Longrightarrow> E a"
    and adm: "\<And>a. E a \<Longrightarrow> defends_rel (\<lambda>_. True) gate_att E a"
    and cf: "\<And>a b. E a \<Longrightarrow> E b \<Longrightarrow> \<not> gate_att a b"
    using comp unfolding extensions.completeExt_def extensions.admissibleExt_def
      extensions.conflictfreeExt_def by blast+
  \<comment> \<open>one side in: the whole side is in, the other side and the objection are out\<close>
  have l5: "E G5 \<Longrightarrow> E G3"
    by (rule closed) (simp add: defends_rel_def gate_all gate_ex gate_att_def ga)
  have l3: "E G3 \<Longrightarrow> E G1"
    by (rule closed) (simp add: defends_rel_def gate_all gate_ex gate_att_def)
  have r6: "E G6 \<Longrightarrow> E G4"
    by (rule closed) (simp add: defends_rel_def gate_all gate_ex gate_att_def ga)
  have r4: "E G4 \<Longrightarrow> E G1"
    by (rule closed) (simp add: defends_rel_def gate_all gate_ex gate_att_def)
  have c54: "E G5 \<Longrightarrow> \<not> E G4" using cf[of G5 G4] by (auto simp: gate_att_def)
  have c56: "E G5 \<Longrightarrow> \<not> E G6" using cf[of G5 G6] by (auto simp: gate_att_def)
  have c32: "E G3 \<Longrightarrow> \<not> E G2" using cf[of G3 G2] by (auto simp: gate_att_def)
  have c63: "E G6 \<Longrightarrow> \<not> E G3" using cf[of G6 G3] by (auto simp: gate_att_def)
  have c42: "E G4 \<Longrightarrow> \<not> E G2" using cf[of G4 G2] by (auto simp: gate_att_def)
  \<comment> \<open>no stance in: nothing but GA is defended\<close>
  have n3: "\<not> E G5 \<Longrightarrow> \<not> E G6 \<Longrightarrow> \<not> E G3"
    using adm[of G3] gw unfolding defends_rel_def by (auto simp: gate_all gate_ex gate_att_def)
  have n4: "\<not> E G5 \<Longrightarrow> \<not> E G6 \<Longrightarrow> \<not> E G4"
    using adm[of G4] gw unfolding defends_rel_def by (auto simp: gate_all gate_ex gate_att_def)
  have n1: "\<not> E G3 \<Longrightarrow> \<not> E G4 \<Longrightarrow> \<not> E G1"
    using adm[of G1] unfolding defends_rel_def by (auto simp: gate_all gate_ex gate_att_def)
  have n2: "\<not> E G5 \<Longrightarrow> \<not> E G6 \<Longrightarrow> \<not> E G2"
    using adm[of G2] gw unfolding defends_rel_def by (auto simp: gate_all gate_ex gate_att_def)
  show "E \<approx> \<lbrace>GA\<rbrace> \<or> E \<approx> gate_left_pref \<or> E \<approx> gate_right_pref"
    using ga gw l5 l3 r6 r4 c54 c56 c32 c63 c42 n3 n4 n1 n2
    by (cases "E G5"; cases "E G6"; auto simp: gate_all)
next
  assume "E \<approx> \<lbrace>GA\<rbrace> \<or> E \<approx> gate_left_pref \<or> E \<approx> gate_right_pref"
  then have "E = \<lbrace>GA\<rbrace> \<or> E = gate_left_pref \<or> E = gate_right_pref"
    by (auto simp: fun_eq_iff)
  then show "extensions.completeExt (\<lambda>_. True) gate_att E"
    unfolding extensions.completeExt_def extensions.admissibleExt_def
      extensions.conflictfreeExt_def defends_rel_def gate_att_def
    by (elim disjE; simp add: gate_all gate_ex)
qed

lemma gate_left_preferred: "extensions.preferredExt (\<lambda>_. True) gate_att gate_left_pref"
proof -
  have comp: "extensions.completeExt (\<lambda>_. True) gate_att gate_left_pref"
    by (simp add: gate_complete gate_all)
  have max: "\<forall>x. X x \<longleftrightarrow> gate_left_pref x"
    if cX: "extensions.completeExt (\<lambda>_. True) gate_att X"
    and sub: "\<forall>x. gate_left_pref x \<longrightarrow> X x" for X
  proof -
    from cX have "X \<approx> \<lbrace>GA\<rbrace> \<or> X \<approx> gate_left_pref \<or> X \<approx> gate_right_pref"
      by (simp add: gate_complete)
    thus ?thesis using sub by (auto simp: gate_all)
  qed
  show ?thesis
    unfolding extensions.preferredExt_def maximal_rel_def id_def
    using comp max by blast
qed

lemma gate_right_preferred: "extensions.preferredExt (\<lambda>_. True) gate_att gate_right_pref"
proof -
  have comp: "extensions.completeExt (\<lambda>_. True) gate_att gate_right_pref"
    by (simp add: gate_complete gate_all)
  have max: "\<forall>x. X x \<longleftrightarrow> gate_right_pref x"
    if cX: "extensions.completeExt (\<lambda>_. True) gate_att X"
    and sub: "\<forall>x. gate_right_pref x \<longrightarrow> X x" for X
  proof -
    from cX have "X \<approx> \<lbrace>GA\<rbrace> \<or> X \<approx> gate_left_pref \<or> X \<approx> gate_right_pref"
      by (simp add: gate_complete)
    thus ?thesis using sub by (auto simp: gate_all)
  qed
  show ?thesis
    unfolding extensions.preferredExt_def maximal_rel_def id_def
    using comp max by blast
qed

lemma gate_preferred:
  "extensions.preferredExt (\<lambda>_. True) gate_att E \<longleftrightarrow>
    E \<approx> gate_left_pref \<or> E \<approx> gate_right_pref"
proof
  assume pref: "extensions.preferredExt (\<lambda>_. True) gate_att E"
  have comp: "extensions.completeExt (\<lambda>_. True) gate_att E"
    using pref unfolding extensions.preferredExt_def maximal_rel_def by blast
  have left_comp: "extensions.completeExt (\<lambda>_. True) gate_att gate_left_pref"
    using gate_left_preferred unfolding extensions.preferredExt_def maximal_rel_def by blast
  have notmin: "\<not> E \<approx> \<lbrace>GA\<rbrace>"
  proof
    assume small: "E \<approx> \<lbrace>GA\<rbrace>"
    have sub: "E \<subseteq> gate_left_pref" using small by blast
    have "gate_left_pref \<approx> E"
      using pref left_comp sub
      unfolding extensions.preferredExt_def maximal_rel_def id_def by blast
    then show False using small by (auto simp: gate_all)
  qed
  show "E \<approx> gate_left_pref \<or> E \<approx> gate_right_pref"
    using comp notmin by (auto simp: gate_complete)
next
  assume "E \<approx> gate_left_pref \<or> E \<approx> gate_right_pref"
  then have "E = gate_left_pref \<or> E = gate_right_pref" by (auto simp: fun_eq_iff)
  then show "extensions.preferredExt (\<lambda>_. True) gate_att E"
    using gate_left_preferred gate_right_preferred by auto
qed

lemma gate_shared_argument: "shared_argument (\<lambda>_. True) gate_att gate_con True"
  unfolding shared_argument_def proximal_explanation_def
  by (auto simp: gate_preferred gate_all gate_ex)

lemma gate_no_shared_explanation: "\<not> shared_explanation (\<lambda>_. True) gate_att gate_con True"
proof
  assume strong: "shared_explanation (\<lambda>_. True) gate_att gate_con True"
  obtain E where expl: "explanation (\<lambda>_. True) gate_att gate_con True E"
    and shared: "\<forall>P. extensions.preferredExt (\<lambda>_. True) gate_att P \<longrightarrow> E \<subseteq> P"
    using strong unfolding shared_explanation_def by blast
  have support: "explanation_support (\<lambda>_. True) gate_att gate_con True E"
    by (rule explanation_has_support[OF expl])
  have left: "E \<subseteq> gate_left_pref"
    using shared[rule_format, OF gate_left_preferred] by blast
  have right: "E \<subseteq> gate_right_pref"
    using shared[rule_format, OF gate_right_preferred] by blast
  have member: "E G1"
    using support unfolding explanation_support_def by (auto simp: gate_ex)
  have defended: "defends_rel (\<lambda>_. True) gate_att E G1"
    using support member unfolding explanation_support_def by blast
  have no_defender: "\<not> E G3 \<and> \<not> E G4"
    using left right by (auto simp: gate_all)
  show False using defended no_defender
    unfolding defends_rel_def gate_att_def by (auto simp: gate_all gate_ex)
qed

lemma gate_distal: "distal_disagreement (\<lambda>_. True) gate_att gate_con True"
  by (simp add: distal_disagreement_def gate_no_shared_explanation gate_shared_argument shared_argument_imp_shared_conclusion)

text \<open>Any support inside a preferred extension contains the whole explanation of
that side: GA is never needed, because G5 (resp. G6) already attacks GW.\<close>
lemma gate_left_support_forces:
  assumes supp: "explanation_support (\<lambda>_. True) gate_att gate_con True X"
    and sub: "X \<subseteq> gate_left_pref"
  shows "gate_left \<subseteq> X"
proof -
  have adm: "\<And>a. X a \<Longrightarrow> defends_rel (\<lambda>_. True) gate_att X a" and x1: "X G1"
    using supp unfolding explanation_support_def by blast+
  have n: "\<not> X G4" "\<not> X GW" using sub by auto
  have x3: "X G3"
    using adm[OF x1] n unfolding defends_rel_def by (auto simp: gate_all gate_ex gate_att_def)
  have x5: "X G5"
    using adm[OF x3] n unfolding defends_rel_def by (auto simp: gate_all gate_ex gate_att_def)
  show ?thesis using x1 x3 x5 by auto
qed

lemma gate_right_support_forces:
  assumes supp: "explanation_support (\<lambda>_. True) gate_att gate_con True X"
    and sub: "X \<subseteq> gate_right_pref"
  shows "gate_right \<subseteq> X"
proof -
  have adm: "\<And>a. X a \<Longrightarrow> defends_rel (\<lambda>_. True) gate_att X a" and x1: "X G1"
    using supp unfolding explanation_support_def by blast+
  have n: "\<not> X G3" "\<not> X GW" using sub by auto
  have x4: "X G4"
    using adm[OF x1] n unfolding defends_rel_def by (auto simp: gate_all gate_ex gate_att_def)
  have x6: "X G6"
    using adm[OF x4] n unfolding defends_rel_def by (auto simp: gate_all gate_ex gate_att_def)
  show ?thesis using x1 x4 x6 by auto
qed

lemma gate_left_support: "explanation_support (\<lambda>_. True) gate_att gate_con True gate_left"
  unfolding explanation_support_def defends_rel_def extensions.conflictfreeExt_def gate_att_def
  by (auto simp: gate_all gate_ex)

lemma gate_right_support: "explanation_support (\<lambda>_. True) gate_att gate_con True gate_right"
  unfolding explanation_support_def defends_rel_def extensions.conflictfreeExt_def gate_att_def
  by (auto simp: gate_all gate_ex)

lemma gate_left_explanation: "explanation (\<lambda>_. True) gate_att gate_con True gate_left"
proof -
  have forces: "X = gate_left"
    if "explanation_support (\<lambda>_. True) gate_att gate_con True X" and "X \<subseteq> gate_left" for X
  proof -
    have "X \<subseteq> gate_left_pref" using that(2) by blast
    from gate_left_support_forces[OF that(1) this] that(2) show ?thesis
      by (auto simp: fun_eq_iff)
  qed
  show ?thesis
    unfolding explanation_def minimal_def id_def
    using gate_left_support forces by blast
qed

lemma gate_right_explanation: "explanation (\<lambda>_. True) gate_att gate_con True gate_right"
proof -
  have forces: "X = gate_right"
    if "explanation_support (\<lambda>_. True) gate_att gate_con True X" and "X \<subseteq> gate_right" for X
  proof -
    have "X \<subseteq> gate_right_pref" using that(2) by blast
    from gate_right_support_forces[OF that(1) this] that(2) show ?thesis
      by (auto simp: fun_eq_iff)
  qed
  show ?thesis
    unfolding explanation_def minimal_def id_def
    using gate_right_support forces by blast
qed

lemma gate_accepted_explanations:
  "accepted_explanation (\<lambda>_. True) gate_att gate_con True E \<longleftrightarrow>
    E = gate_left \<or> E = gate_right"
proof
  assume "accepted_explanation (\<lambda>_. True) gate_att gate_con True E"
  then obtain P where expl: "explanation (\<lambda>_. True) gate_att gate_con True E"
    and P: "extensions.preferredExt (\<lambda>_. True) gate_att P" and EP: "E \<subseteq> P"
    unfolding accepted_explanation_def by blast
  have supp: "explanation_support (\<lambda>_. True) gate_att gate_con True E"
    by (rule explanation_has_support[OF expl])
  have minimal: "D \<approx> E"
    if "explanation_support (\<lambda>_. True) gate_att gate_con True D" and "D \<subseteq> E" for D
    using expl that unfolding explanation_def minimal_def id_def by blast
  from P consider "P = gate_left_pref" | "P = gate_right_pref"
    by (auto simp: gate_preferred fun_eq_iff)
  then show "E = gate_left \<or> E = gate_right"
  proof cases
    case 1
    with EP have sub: "E \<subseteq> gate_left_pref" by auto
    have "gate_left \<subseteq> E" by (rule gate_left_support_forces[OF supp sub])
    hence "gate_left \<approx> E" using minimal[OF gate_left_support] by blast
    thus ?thesis by (auto simp: fun_eq_iff)
  next
    case 2
    with EP have sub: "E \<subseteq> gate_right_pref" by auto
    have "gate_right \<subseteq> E" by (rule gate_right_support_forces[OF supp sub])
    hence "gate_right \<approx> E" using minimal[OF gate_right_support] by blast
    thus ?thesis by (auto simp: fun_eq_iff)
  qed
next
  assume "E = gate_left \<or> E = gate_right"
  thus "accepted_explanation (\<lambda>_. True) gate_att gate_con True E"
    unfolding accepted_explanation_def
    using gate_left_explanation gate_right_explanation gate_left_preferred gate_right_preferred
    by blast
qed

lemma gate_locus:
  "locus (\<lambda>_. True) gate_att gate_con True x \<longleftrightarrow>
    x = G3 \<or> x = G4 \<or> x = G5 \<or> x = G6"
  unfolding locus_def gate_accepted_explanations by (cases x) auto

definition gate_minus :: "gate_argument \<Rightarrow> gate_argument Set" where
  "gate_minus a = remove_argument (\<lambda>_. True) a"

lemma gate_minus_mem [simp]: "gate_minus a x \<longleftrightarrow> x \<noteq> a"
  unfolding gate_minus_def by simp

text \<open>After deleting the gatekeeper, Julia's reasons still form a preferred
extension, but so do the wrecker and the objection to the issue.\<close>
lemma gate_minusA_left_preferred: "extensions.preferredExt (gate_minus GA) gate_att gate_left"
proof -
  have comp: "extensions.completeExt (gate_minus GA) gate_att gate_left"
    unfolding extensions.completeExt_def extensions.admissibleExt_def
      extensions.conflictfreeExt_def defends_rel_def gate_att_def
    by (simp add: gate_all gate_ex)
  have max: "\<forall>x. gate_minus GA x \<longrightarrow> (X x \<longleftrightarrow> gate_left x)"
    if cX: "extensions.completeExt (gate_minus GA) gate_att X"
    and sub: "\<forall>x. gate_minus GA x \<longrightarrow> gate_left x \<longrightarrow> X x" for X
  proof -
    have cf: "\<And>a b. gate_minus GA a \<Longrightarrow> gate_minus GA b \<Longrightarrow> X a \<Longrightarrow> X b \<Longrightarrow> \<not> gate_att a b"
      using cX unfolding extensions.completeExt_def extensions.admissibleExt_def
        extensions.conflictfreeExt_def by blast
    have x1: "X G1" and x3: "X G3" and x5: "X G5" using sub by (simp_all add: gate_all)
    have n2: "\<not> X G2" using cf[of G3 G2] x3 by (auto simp: gate_att_def)
    have n4: "\<not> X G4" using cf[of G5 G4] x5 by (auto simp: gate_att_def)
    have n6: "\<not> X G6" using cf[of G5 G6] x5 by (auto simp: gate_att_def)
    have nw: "\<not> X GW" using cf[of G5 GW] x5 by (auto simp: gate_att_def)
    show ?thesis using x1 x3 x5 n2 n4 n6 nw by (simp add: gate_all)
  qed
  show ?thesis
    unfolding extensions.preferredExt_def maximal_rel_def id_def
    using comp max by blast
qed

lemma gate_minusA_wrecker_preferred:
  "extensions.preferredExt (gate_minus GA) gate_att \<lbrace>GW,G2\<rbrace>"
proof -
  have comp: "extensions.completeExt (gate_minus GA) gate_att \<lbrace>GW,G2\<rbrace>"
    unfolding extensions.completeExt_def extensions.admissibleExt_def
      extensions.conflictfreeExt_def defends_rel_def gate_att_def
    by (simp add: gate_all gate_ex)
  have max: "\<forall>x. gate_minus GA x \<longrightarrow> (X x \<longleftrightarrow> \<lbrace>GW,G2\<rbrace> x)"
    if cX: "extensions.completeExt (gate_minus GA) gate_att X"
    and sub: "\<forall>x. gate_minus GA x \<longrightarrow> \<lbrace>GW,G2\<rbrace> x \<longrightarrow> X x" for X
  proof -
    have cf: "\<And>a b. gate_minus GA a \<Longrightarrow> gate_minus GA b \<Longrightarrow> X a \<Longrightarrow> X b \<Longrightarrow> \<not> gate_att a b"
      using cX unfolding extensions.completeExt_def extensions.admissibleExt_def
        extensions.conflictfreeExt_def by blast
    have xw: "X GW" and x2: "X G2" using sub by (simp_all add: gate_all)
    have n1: "\<not> X G1" using cf[of G2 G1] x2 by (auto simp: gate_att_def)
    have n3: "\<not> X G3" using cf[of GW G3] xw by (auto simp: gate_att_def)
    have n4: "\<not> X G4" using cf[of GW G4] xw by (auto simp: gate_att_def)
    have n5: "\<not> X G5" using cf[of GW G5] xw by (auto simp: gate_att_def)
    have n6: "\<not> X G6" using cf[of GW G6] xw by (auto simp: gate_att_def)
    show ?thesis using xw x2 n1 n3 n4 n5 n6 by (simp add: gate_all)
  qed
  show ?thesis
    unfolding extensions.preferredExt_def maximal_rel_def id_def
    using comp max by blast
qed

lemma gate_GA_weak_spot: "weak_spot (\<lambda>_. True) gate_att gate_con True GA"
proof -
  have shared: "shared_conclusion (\<lambda>_. True) gate_att gate_con True"
    by (rule shared_argument_imp_shared_conclusion[OF gate_shared_argument])
  have cred: "credulous_conclusion (gate_minus GA) gate_att gate_con True"
    unfolding credulous_conclusion_def proximal_explanation_def
    using gate_minusA_left_preferred by fastforce
  have nshared: "\<not> shared_conclusion (gate_minus GA) gate_att gate_con True"
    unfolding shared_conclusion_def proximal_explanation_def
    using gate_minusA_wrecker_preferred by (auto simp: gate_ex)
  show ?thesis
    unfolding weak_spot_def disagrees_that_def gate_minus_def[symmetric]
    using shared cred nshared by simp
qed

theorem gate_weak_spot_outside_locus:
  "distal_disagreement (\<lambda>_. True) gate_att gate_con True \<and>
   weak_spot (\<lambda>_. True) gate_att gate_con True GA \<and>
   \<not> locus (\<lambda>_. True) gate_att gate_con True GA \<and>
   (\<forall>E. accepted_explanation (\<lambda>_. True) gate_att gate_con True E \<longrightarrow> \<not> E GA)"
  using gate_distal gate_GA_weak_spot
  by (simp add: gate_locus gate_accepted_explanations)

(*<*)
end
(*>*)
