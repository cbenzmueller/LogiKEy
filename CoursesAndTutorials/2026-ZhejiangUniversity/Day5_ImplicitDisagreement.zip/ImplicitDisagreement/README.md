# Implicit disagreement in Isabelle/HOL

## Building

The formalization was developed and checked with **Isabelle2025-2** (available from <https://isabelle.in.tum.de>); other releases are not guaranteed to work.

Building the **PDF document** additionally needs a LaTeX installation
(TeX Live, or MacTeX on macOS): Isabelle does not bundle one, it calls
`lualatex` from the environment. Without it the script still checks every
proof and simply skips the PDF. To inspect the theories interactively no
LaTeX is needed at all -- open them in Isabelle/jEdit (`isabelle jedit -d .
-d AA_Fixed -l AA_Fixed ID_Examples.thy`).

From this directory, build the session and its document:

- **macOS / Linux:** `./build.sh`
- **Windows:** run it in the Isabelle-bundled shell, e.g. `isabelle env bash build.sh` (native `cmd`/PowerShell cannot run the script).

If `isabelle` is not on your `PATH`, point the script at it explicitly:

```
ISABELLE=/path/to/isabelle ./build.sh
```

The first run also builds the parent session `AA_Fixed`. On a Windows laptop (Isabelle2025-2, Intel i7-1365U) the complete first build took about 11.5 minutes: 9 minutes for `AA_Fixed`, then under half a minute for this session plus about 2 minutes for the PDF. The generated document is written to `output/document.pdf`.

On Windows, Nitpick has only the pure-Java SAT4J solver available (Kodkodi ships native solvers for Linux and macOS only). The two ideal-extension model-generation queries in `AA_Fixed/simplified/model-generation.thy` take about a minute each with it, so they carry an explicit `timeout=300`: Nitpick's default 30 s timeout would report "unknown", which the session-wide `expect=genuine` setting turns into a build error.

## Mapping to the paper

| Paper | Isabelle representation | Location |
|---|---|---|
| Framework | Existing argument predicate `U :: 'a Set` and `att :: 'a Rel` | Imported library; no replacement record |
| Extension semantics (defence, complete, grounded, preferred) | `defends_rel`, `extensions.completeExt`, `extensions.groundedExt`, `extensions.preferredExt` | Imported library |
| Conclusion map | Parameter `Con :: 'a => 'c` | New predicates, polymorphic in conclusion type |
| Inference relations (credulous, shared conclusion, shared argument) | `credulous_conclusion`, `shared_conclusion`, `shared_argument` | `ID_Inference.thy` |
| Agents | `is_agent U att A r`, with `r = induced_att att A` | `ID_Frameworks.thy` |
| Coalition | `coalition A B`, abbreviation for imported union; `coalition_att` | `ID_Frameworks.thy` |
| Agreement (agrees that / agrees because) | `agrees_that`, `agrees_because`, aliases for the corresponding inference relations | `ID_Inference.thy` |
| Proximal explanation | `proximal_explanation U Con p a` | `ID_Inference.thy` |
| Explanation | `explanation_support` for conditions (i)–(ii), conflict-freeness included; `explanation` uses imported `minimal`; `explanation_nocf` is the variant without conflict-freeness, kept for `explanation_cf_invariant` | `ID_Explanations.thy` |
| Shared-explanation inference / strong agreement because | `shared_explanation`; alias `strongly_agrees_because` | `ID_Explanations.thy` |
| Disagreement predicates (ordinary, proximal, distal) | `disagrees_that`, `proximal_disagreement`, `distal_disagreement` | `ID_Disagreement.thy` |
| Actual implicit disagreement | `proximal_implicit_disagreement`, `distal_implicit_disagreement`, coalition-evaluated aliases of the disagreement predicates | `ID_Disagreement.thy` |
| Potential implicit disagreement | `potential_proximal_disagreement A B att Con p`, `potential_distal_disagreement A B att Con p` | `ID_Disagreement.thy` |
| Deletion and weak spots | `remove_argument`, `remove_att`, `weak_spot` | `ID_Frameworks.thy`, `ID_Disagreement.thy` |
| Antagonist | `antagonist U att Con p a` | `ID_Disagreement.thy` |
| Locus | `accepted_explanation` (an explanation inside some preferred extension), `locus U att Con p x`; `distal_disagreement_locus_nonempty` (finite `U`) | `ID_Disagreement.thy` |
| Shared-explanation / ideal-semantics correspondence | `shared_explanation_iff_idealset` (finite `U`) | `ID_Explanations.thy` |

## Interpretation choices

Sets are characteristic predicates, using the library's `'a Set` type and inclusion/union operations. An agent can have an empty argument universe even though the ambient HOL type is nonempty. The attack relation of an agent or coalition is induced by its arguments. The proved `*_induced` lemmas justify using an ambient attack relation with the smaller universe when evaluating the relative semantics.

The inference predicates range over preferred extensions, not stable extensions. `shared_conclusion` means that **each extension contains some argument** with the conclusion; `shared_argument` means that **one argument occurs in every extension**. They cannot be identified with each other or with the existing argument-level labelling acceptance predicates. Witness arguments are explicitly required to belong to `U`, since the imported extension predicates ignore membership outside that universe.

The conclusion type is arbitrary and no entailment on conclusions is assumed. In particular, an argument concluding a conjunction does not automatically conclude either conjunct. Multiple arguments may have the same conclusion. A proximal explanation is therefore a relation, not a single-valued choice function.

The explanation definition is encoded literally: an explanation is an inclusion-minimal subset of the framework that contains a concluder, is conflict-free and defends all its own arguments; every explanation is therefore admissible (`explanation_admissible`). Defence is evaluated against attackers in the entire current framework, not just in the explanation's induced subgraph. The conflict-freeness clause only matters outside conflict-free sets: without it a self-attacking singleton would be an explanation of its own conclusion (`self_attacking_explanation_without_cf` vs. `self_attacking_no_explanation`), whereas on subsets of a conflict-free set, in particular of a preferred extension, the two versions of the definition coincide (`explanation_cf_invariant`). Shared-explanation inference, the ideal-semantics correspondence and the locus only look inside preferred extensions and are unaffected by the clause.

All definitions work without assuming finitely many arguments or finitely many preferred extensions. This generalizes the paper's finite indexing by quantification; it does not add an assertion that a minimal explanation always exists in an infinite framework.

Potential disagreement retains the two agents as separate parameters because their individual commitments matter. Actual implicit disagreement is exactly the corresponding proximal/distal disagreement of their coalition and is only abbreviated, avoiding duplicate definitions.

A weak spot must turn shared-conclusion acceptance into ordinary disagreement after deletion: some preferred extension must still support the conclusion, while another does not. Merely removing its sole concluder is insufficient. An antagonist (paper Definition "Antagonist") is a present argument whose removal turns distal disagreement into shared-explanation agreement.

The locus (paper Definition "Locus") is the union minus the intersection of the explanations contained in some preferred extension. The paper states it for a conclusion under distal implicit disagreement; the predicate is defined for every framework, and for finite frameworks it is proved nonempty under distal disagreement, because every preferred extension then contains an explanation (`preferred_contains_explanation`, by the same minimal-support extraction as the ideal-semantics correspondence).

`ID_Examples.thy` tests the quantifier distinction, coalition edges, the role of the conflict-freeness clause, and the displayed six-argument graph, for which it also computes the locus `{A3, A4, A5, A6}` (`bio_locus_set`, `bio_coalition_locus`). Its last section shows that the locus and the weak spots are independent: with three pairwise conflicting defenders a locus element is neither a weak spot nor an antagonist (`tri_locus_element_neither`), and an unattacked gatekeeper added to the running example is a weak spot that belongs to no explanation (`gate_weak_spot_outside_locus`).

