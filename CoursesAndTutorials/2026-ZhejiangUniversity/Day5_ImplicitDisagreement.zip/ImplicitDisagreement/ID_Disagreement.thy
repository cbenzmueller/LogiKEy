(*<*)
theory ID_Disagreement
  imports ID_Explanations
begin
(*>*)

section \<open>Disagreement, weak spots, and antagonists\<close>

text \<open>Disagreement predicates (paper Definition ``Disagreements, explicit and
implicit''); the proximal/distal naming matches the paper. Each predicate is the
characteristic predicate of the corresponding conclusion set (Dis, proximal,
distal); evaluate it on the coalition argument predicate for the two-agent
formulation.\<close>
definition disagrees_that where
  "disagrees_that U att Con p \<longleftrightarrow>
    credulous_conclusion U att Con p \<and> \<not> shared_conclusion U att Con p"

definition proximal_disagreement where
  "proximal_disagreement U att Con p \<longleftrightarrow>
    shared_conclusion U att Con p \<and> \<not> shared_argument U att Con p"

definition distal_disagreement where
  "distal_disagreement U att Con p \<longleftrightarrow>
    shared_conclusion U att Con p \<and> \<not> shared_explanation U att Con p"

text \<open>Actual implicit disagreement coincides with the proximal/distal
disagreement predicates above, evaluated on the coalition. Potential disagreement
keeps A and B as separate parameters: its truth cannot be determined from their
union alone.\<close>
abbreviation proximal_implicit_disagreement where
  "proximal_implicit_disagreement A B att Con p \<equiv>
    proximal_disagreement (coalition A B) att Con p"

abbreviation distal_implicit_disagreement where
  "distal_implicit_disagreement A B att Con p \<equiv>
    distal_disagreement (coalition A B) att Con p"

definition potential_proximal_disagreement where
  "potential_proximal_disagreement A B att Con p \<longleftrightarrow>
    shared_conclusion A att Con p \<and> shared_conclusion B att Con p \<and>
    \<not> shared_argument (coalition A B) att Con p"

definition potential_distal_disagreement where
  "potential_distal_disagreement A B att Con p \<longleftrightarrow>
    shared_conclusion A att Con p \<and> shared_conclusion B att Con p \<and>
    \<not> shared_explanation (coalition A B) att Con p"

text \<open>Weak spots (paper Definition ``weak spot''). Losing skeptical acceptance
alone is insufficient: after removal, the conclusion must still be credulously
supported. Pass coalition A B for U to obtain a weak spot of that coalition.\<close>
definition weak_spot where
  "weak_spot U att Con p a \<longleftrightarrow>
    shared_conclusion U att Con p \<and>
    disagrees_that (remove_argument U a) (remove_att U att a) Con p"

text \<open>Antagonists (paper Definition ``Antagonist''): removing a present argument
turns distal disagreement into agreement from a shared explanation.\<close>
definition antagonist where
  "antagonist U att Con p a \<longleftrightarrow>
    U a \<and> distal_disagreement U att Con p \<and>
    shared_explanation (remove_argument U a) (remove_att U att a) Con p"

text \<open>Locus (paper Definition ``Locus''): the arguments on which the explanations
of p contained in some preferred extension differ, i.e. the union of these
explanations minus their intersection. The paper states it for p under distal
implicit disagreement; the predicate is defined for every framework, and
\<open>distal_disagreement_locus_nonempty\<close> below shows that it is then nonempty.\<close>
definition accepted_explanation where
  "accepted_explanation U att Con p E \<longleftrightarrow>
    explanation U att Con p E \<and>
    (\<exists>P. extensions.preferredExt U att P \<and> E \<subseteq> P)"

definition locus where
  "locus U att Con p x \<longleftrightarrow>
    (\<exists>E. accepted_explanation U att Con p E \<and> E x) \<and>
    \<not> (\<forall>E. accepted_explanation U att Con p E \<longrightarrow> E x)"

lemma proximal_imp_distal:
  "proximal_disagreement U att Con p \<Longrightarrow> distal_disagreement U att Con p"
  using shared_explanation_imp_shared_argument[of U att Con p]
  unfolding proximal_disagreement_def distal_disagreement_def by blast

lemma potential_proximal_imp_distal:
  "potential_proximal_disagreement A B att Con p \<Longrightarrow>
    potential_distal_disagreement A B att Con p"
  using shared_explanation_imp_shared_argument[of "coalition A B" att Con p]
  unfolding potential_proximal_disagreement_def potential_distal_disagreement_def by blast

text \<open>Ordinary disagreement is disjoint from both proximal and distal
disagreement, as follows from their definitions.\<close>
lemma ordinary_and_distal_disjoint:
  "\<not> (disagrees_that U att Con p \<and> distal_disagreement U att Con p)"
  unfolding disagrees_that_def distal_disagreement_def by blast

lemma ordinary_and_proximal_disjoint:
  "\<not> (disagrees_that U att Con p \<and> proximal_disagreement U att Con p)"
  unfolding disagrees_that_def proximal_disagreement_def by blast

lemma weak_spot_retains_credulous_support:
  "weak_spot U att Con p a \<Longrightarrow>
    credulous_conclusion (remove_argument U a) att Con p \<and>
    \<not> shared_conclusion (remove_argument U a) att Con p"
  unfolding weak_spot_def disagrees_that_def by simp

lemma weak_spot_is_present:
  assumes "weak_spot U att Con p a"
  shows "U a"
proof (rule ccontr)
  assume absent: "\<not> U a"
  have unchanged: "remove_argument U a = U"
    using absent by (auto simp: fun_eq_iff)
  show False
    using assms unfolding weak_spot_def disagrees_that_def
    by (auto simp: unchanged)
qed

lemma removing_the_only_concluder_is_not_a_weak_spot:
  assumes "\<forall>b. U b \<longrightarrow> Con b = p \<longrightarrow> b = a"
  shows "\<not> weak_spot U att Con p a"
  by (smt (verit, ccfv_threshold) assms no_argument_no_credulous
      weak_spot_retains_credulous_support)


lemma antagonists_are_not_weak_spots:
  assumes ant: "antagonist U att Con p a"
  shows "\<not> weak_spot U att Con p a"
  by (metis (lifting) agreement_hierarchy antagonist_def assms disagrees_that_def weak_spot_def)

text \<open>In a finite framework that skeptically supports p, every preferred
extension contains an explanation of p: the extension restricted to U is a
support, from which a minimal one is extracted.\<close>
lemma preferred_contains_explanation:
  assumes fin: "finite {a. U a}"
    and sc: "shared_conclusion U att Con p"
    and P: "extensions.preferredExt U att P"
  shows "\<exists>E. explanation U att Con p E \<and> E \<subseteq> P"
proof -
  define P' where "P' = (\<lambda>x. U x \<and> P x)"
  have P'U: "P' \<subseteq> U" unfolding P'_def by auto
  have P'P: "P' \<subseteq> P" unfolding P'_def by auto
  have comp: "extensions.completeExt U att P"
    using P unfolding extensions.preferredExt_def maximal_rel_def by blast
  have adm: "extensions.admissibleExt U att P"
    using comp unfolding extensions.completeExt_def by auto
  have cf: "extensions.conflictfreeExt U att P'"
    using adm unfolding extensions.admissibleExt_def extensions.conflictfreeExt_def P'_def
    by blast
  have conc: "\<exists>a. P' a \<and> Con a = p"
    using sc P unfolding shared_conclusion_def proximal_explanation_def P'_def by blast
  have defd: "\<forall>a. P' a \<longrightarrow> defends_rel U att P' a"
  proof (intro allI impI)
    fix a assume "P' a"
    hence Ua: "U a" and Pa: "P a" unfolding P'_def by auto
    have "defends_rel U att P a"
      using adm Ua Pa unfolding extensions.admissibleExt_def by auto
    thus "defends_rel U att P' a" unfolding defends_rel_def P'_def by auto
  qed
  have supp: "explanation_support U att Con p P'"
    unfolding explanation_support_def using P'U conc cf defd by auto
  obtain E where "explanation U att Con p E" and "E \<subseteq> P'"
    using minimal_support_extract[OF fin P'U supp] by blast
  thus ?thesis using P'P by blast
qed

text \<open>Under distal disagreement the locus is nonempty (finite frameworks): two
preferred extensions carry explanations that differ on some argument.\<close>
lemma distal_disagreement_locus_nonempty:
  assumes fin: "finite {a. U a}"
    and dd: "distal_disagreement U att Con p"
  shows "\<exists>x. locus U att Con p x"
proof -
  have sc: "shared_conclusion U att Con p"
    and nsh: "\<not> shared_explanation U att Con p"
    using dd unfolding distal_disagreement_def by auto
  obtain P1 where P1: "extensions.preferredExt U att P1"
    using preferred_extensions_exist by blast
  obtain E1 where E1: "explanation U att Con p E1" and E1P1: "E1 \<subseteq> P1"
    using preferred_contains_explanation[OF fin sc P1] by blast
  obtain P2 where P2: "extensions.preferredExt U att P2" and notin: "\<not> E1 \<subseteq> P2"
    using nsh E1 unfolding shared_explanation_def by blast
  obtain E2 where E2: "explanation U att Con p E2" and E2P2: "E2 \<subseteq> P2"
    using preferred_contains_explanation[OF fin sc P2] by blast
  obtain x where x1: "E1 x" and nx2: "\<not> P2 x" using notin by blast
  have nx: "\<not> E2 x" using nx2 E2P2 by blast
  have acc1: "accepted_explanation U att Con p E1"
    unfolding accepted_explanation_def using E1 P1 E1P1 by blast
  have acc2: "accepted_explanation U att Con p E2"
    unfolding accepted_explanation_def using E2 P2 E2P2 by blast
  show ?thesis
    unfolding locus_def using acc1 acc2 x1 nx by blast
qed

(*<*)
end
(*>*)
