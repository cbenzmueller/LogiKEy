#!/usr/bin/env bash
# Build the Implicit_Disagreement session and its AFP-style document.
#
# Usage:            ./build.sh
# Custom Isabelle:  ISABELLE=/path/to/isabelle ./build.sh
#
# The first run also builds the parent session AA_Fixed (a few minutes).
# The generated document is written to output/document.pdf.

set -euo pipefail
cd "$(dirname "$0")"

if [ -z "${ISABELLE:-}" ]; then
  if command -v isabelle >/dev/null 2>&1; then
    ISABELLE=isabelle
  else
    # Fall back to a local Isabelle2025* app bundle (macOS).
    ISABELLE=$(ls -d /Applications/Isabelle2025*.app/bin/isabelle 2>/dev/null | sort | tail -n 1 || true)
    if [ -z "$ISABELLE" ]; then
      echo "error: no 'isabelle' on PATH and no /Applications/Isabelle2025*.app found." >&2
      echo "       Set ISABELLE=/path/to/isabelle and re-run." >&2
      exit 1
    fi
  fi
fi

# Isabelle does not ship a LaTeX installation: it calls lualatex from the
# environment. Build the PDF only when that is available, so that a reviewer
# without TeX still gets a complete check of every proof (the session options
# in ROOT deliberately leave "document" unset -- a session option there would
# override -o on the command line and make LaTeX a hard requirement).
# No arrays here: under "set -u" bash 3.2 (the /bin/bash of macOS) rejects the
# expansion of an empty array, which is precisely the no-LaTeX case.
if "$ISABELLE" env bash -c 'command -v lualatex' >/dev/null 2>&1; then
  BUILD_DOC=yes
else
  BUILD_DOC=no
  echo "note: lualatex not found; checking the proofs only, no PDF." >&2
  echo "      Install TeX Live/MacTeX and re-run to also build output/document.pdf." >&2
  echo >&2
fi

if [ "$BUILD_DOC" = yes ]; then
  "$ISABELLE" build -o timeout_scale=3 -o document=pdf \
    -d . -d AA_Fixed Implicit_Disagreement "$@"
else
  "$ISABELLE" build -o timeout_scale=3 \
    -d . -d AA_Fixed Implicit_Disagreement "$@"
fi

echo
if [ "$BUILD_DOC" = yes ]; then
  echo "OK. Document: $(pwd)/output/document.pdf"
else
  echo "OK. All proofs checked (no PDF: lualatex was not available)."
fi
