theory QBFinHOL_deep_subst_lemma_old imports QBFinHOL_deep                        
begin
  primrec is_free (infix "free'_in" 900)  where
       "x free_in (y\<^sup>d) = (y = x)"
     | "x free_in (\<not>\<^sup>d\<phi>) = (x free_in \<phi>)"
     | "x free_in (\<phi> \<or>\<^sup>d \<psi>) = (x free_in \<phi> \<or> x free_in \<psi>)"
     | "x free_in (\<forall>\<^sup>dy. \<phi>) = (x free_in \<phi> \<and> x \<noteq> y)"
  abbreviation is_not_free (infix "not'_free'_in" 900) where "x not_free_in \<phi> \<equiv> \<not>(x free_in \<phi>)"
  fun is_bound (infix "bound'_in" 900)  where
       "x bound_in (y\<^sup>d) = False"
     | "x bound_in (\<not>\<^sup>d\<phi>) = (x bound_in \<phi>)"
     | "x bound_in (\<phi> \<or>\<^sup>d \<psi>) = (x bound_in \<phi> \<or> x bound_in \<psi>)"
     | "x bound_in (\<forall>\<^sup>d y. \<phi>) = (x = y \<or> (x bound_in \<phi>))"
  abbreviation is_not_bound (infix "not'_bound'_in" 900) where "x not_bound_in \<phi> \<equiv> \<not>(x bound_in \<phi>)"
  abbreviation occurs (infix "occurs'_in" 900) where "x occurs_in \<phi> \<equiv> x free_in \<phi> \<or> x bound_in \<phi>"
  abbreviation not_in (infix "not'_in" 900) where "x not_in \<phi> \<equiv> x not_free_in \<phi> \<and> x not_bound_in \<phi>"
  primrec FreshVar ("fresh'(_')") where
      "fresh(x\<^sup>d) = Suc x"
    | "fresh(\<not>\<^sup>d\<phi>) = fresh(\<phi>)"
    | "fresh(\<phi> \<or>\<^sup>d \<psi>) = max (fresh(\<phi>)) (fresh(\<psi>))"
    | "fresh(\<forall>\<^sup>d x. \<phi>) = max (Suc x) (fresh(\<phi>))"
  lemma L5: "x bound_in \<phi> \<Longrightarrow> x < fresh(\<phi>)" by (induct \<phi>) auto
  lemma L6: "x free_in \<phi> \<Longrightarrow> x < fresh(\<phi>)" by (induct \<phi>) auto
  lemma L7: "fresh(\<phi>) not_in \<phi>" using L5 L6 by blast
  lemma L8: "max fresh(\<phi>) fresh(\<psi>) not_free_in \<phi>" by (metis L6 L7 max.absorb3 max_def)
  lemma L9: "max fresh(\<phi>) fresh(\<psi>) not_bound_in \<phi>" by (metis L5 L7 max.absorb3 max_def)
  lemma L10: "max fresh(\<phi>) fresh(\<psi>) not_free_in \<psi>" by (metis L8 max.commute)
  lemma L11: "max fresh(\<phi>) fresh(\<psi>) not_bound_in \<psi>" by (metis L9 max.commute)
  lemma L12: "y not_free_in \<phi> \<Longrightarrow> (I\<langle>y\<leftarrow>s\<rangle> \<Turnstile>\<^sup>d \<phi>) = (I \<Turnstile>\<^sup>d \<phi>)" by (induct \<phi> arbitrary: I; simp) (metis L4 L2)
  primrec Subst ("[_\<leftarrow>_]'(_')") where \<comment>\<open>Substitution ignoring potential variable capture\<close>
      "[x\<leftarrow>\<tau>](y\<^sup>d) = (if x = y then \<tau> else (y\<^sup>d))"
    | "[x\<leftarrow>\<tau>](\<not>\<^sup>d\<phi>) = \<not>\<^sup>d[x\<leftarrow>\<tau>](\<phi>)"
    | "[x\<leftarrow>\<tau>](\<phi> \<or>\<^sup>d \<psi>) = ([x\<leftarrow>\<tau>](\<phi>) \<or>\<^sup>d [x\<leftarrow>\<tau>](\<psi>))"
    | "[x\<leftarrow>\<tau>](\<forall>\<^sup>dy. \<phi>) = (if x = y then (\<forall>\<^sup>dy. \<phi>) else (\<forall>\<^sup>dy. [x\<leftarrow>\<tau>](\<phi>)))"
  lemma L13[simp]: "size [x\<leftarrow>y\<^sup>d](\<phi>) = size \<phi>" by (induct \<phi>; auto)
  lemma L14[simp]: "[x\<leftarrow>x\<^sup>d](\<phi>) = \<phi>" by (induct \<phi>; auto)
  lemma L15: assumes "x \<noteq> a" shows "[a\<leftarrow>\<tau>]([a\<leftarrow>x\<^sup>d](\<phi>)) = [a\<leftarrow>x\<^sup>d](\<phi>)" using assms by (induct \<phi>) auto
  lemma L16[simp]: assumes "a \<noteq> x" shows "a not_free_in ([a\<leftarrow>x\<^sup>d](\<phi>))" using assms by (induct \<phi>) auto
  lemma SInduct:  \<comment>\<open>Induction over the size of a formula\<close>
    assumes "\<And> x. P (x\<^sup>d)"
    assumes "\<And> \<phi>. (\<And> \<psi>. size \<psi> \<le> size \<phi> \<Longrightarrow> P \<psi>) \<Longrightarrow> P (\<not>\<^sup>d\<phi>)"
    assumes "\<And> \<phi> \<psi>. (\<And> \<chi>. size \<chi> \<le> size \<phi> + size \<psi> \<Longrightarrow> P \<chi>) \<Longrightarrow> P (\<phi> \<or>\<^sup>d \<psi>)"
    assumes "\<And> y \<phi>. (\<And> \<psi>. size \<psi> \<le> size \<phi> \<Longrightarrow> P \<psi>) \<Longrightarrow> P (\<forall>\<^sup>dy. \<phi>)"
    shows "P \<phi>"
    using assms proof (induct "size \<phi>" arbitrary: \<phi> rule: less_induct) case less thus ?case by (induct \<phi>) auto qed
  lemma QInduct: \<comment>\<open>Stronger induction\<close>
    assumes "\<And> x. P (x\<^sup>d)"
    assumes "\<And> \<phi>. P \<phi> \<Longrightarrow> P (\<not>\<^sup>d\<phi>)"
    assumes "\<And> \<phi> \<psi>. P \<phi> \<Longrightarrow> P \<psi> \<Longrightarrow> P (\<phi> \<or>\<^sup>d \<psi>)"
    assumes "\<And> y \<phi>. (\<And> \<psi>. size \<psi> \<le> size \<phi> \<Longrightarrow> P \<psi>) \<Longrightarrow> P (\<forall>\<^sup>dy. \<phi>)"
    shows "P \<phi>"
    using assms by (induct \<phi> rule: SInduct) auto
  primrec SubstitutableForIn \<comment>\<open>Substitutable for a variable\<close>
      ("_ is'_subst'_for _ in _" [1000,1,1000] 1000) where "\<tau> is_subst_for x in (y\<^sup>d) = True"
    |  "\<tau> is_subst_for x in (\<not>\<^sup>d\<phi>) = \<tau> is_subst_for x in (\<phi>)"
    |  "\<tau> is_subst_for x in (\<phi> \<or>\<^sup>d \<psi>) = (\<tau> is_subst_for x in (\<phi>) \<and> \<tau> is_subst_for x in (\<psi>))"
    |  "\<tau> is_subst_for x in (\<forall>\<^sup>d y. \<phi>) = (y = x \<or> (x not_free_in \<phi> \<or> y not_free_in \<tau>) \<and> \<tau> is_subst_for x in \<phi>)"
  lemma SubstitutionLemma [simp]: \<comment>\<open>Substitution lemma\<close>
    assumes "\<tau> is_subst_for x in \<phi>" shows "(I \<Turnstile>\<^sup>d ([x\<leftarrow>\<tau>](\<phi>))) = I\<langle>x\<leftarrow>(I \<Turnstile>\<^sup>d \<tau>)\<rangle> \<Turnstile>\<^sup>d \<phi>"
    using assms by (induction \<phi> arbitrary: I; auto simp: L12 L2)
  fun ren_for_subst where \<comment>\<open>Alphabetic variants for unrestricted substitution\<close>
      "ren_for_subst x \<tau> (y\<^sup>d) = y\<^sup>d"
    | "ren_for_subst x \<tau> (\<not>\<^sup>d\<phi>) = (\<not>\<^sup>d(ren_for_subst x \<tau> \<phi>))"
    | "ren_for_subst x \<tau> (\<phi> \<or>\<^sup>d \<psi>) = (ren_for_subst x \<tau> \<phi> \<or>\<^sup>d ren_for_subst x \<tau> \<psi>)"
    | "ren_for_subst x \<tau> (\<forall>\<^sup>d y. \<phi>) = (if y free_in \<tau> \<and> x free_in \<phi>  then 
           let f = fresh(\<phi> \<or>\<^sup>d \<tau>); \<phi>' = [y\<leftarrow>f\<^sup>d](\<phi>) in (\<forall>\<^sup>df. ren_for_subst x \<tau> \<phi>') else \<forall>\<^sup>dy. ren_for_subst x \<tau> \<phi>)"
  lemma L17 [simp]: "size (ren_for_subst x \<tau> \<phi>) = size \<phi>" by (induct \<phi> arbitrary: \<tau> x rule: QInduct; simp add: Let_def)
  lemma L18: "\<alpha> not_in \<phi> \<Longrightarrow> (\<alpha>\<^sup>d) is_subst_for \<beta> in \<phi>" by (induct \<phi>) auto
  lemma L19: "x free_in \<psi> \<Longrightarrow> y \<noteq> x \<Longrightarrow> x free_in [y\<leftarrow>\<tau>](\<psi>)" by (induct \<psi>) auto
  lemma L20 [simp]: "x free_in ren_for_subst x \<tau> \<phi> = (x free_in \<phi>)" by (induct \<phi> rule: QInduct; simp add: Let_def)
     (metis L16 L6 L7 L19 max.absorb3 max_def_raw)
  lemma L21: "(I \<Turnstile>\<^sup>d \<phi>) = (I \<Turnstile>\<^sup>d (ren_for_subst x \<tau> \<phi>))" by (induct \<phi> arbitrary: x \<tau> I rule: QInduct;
      simp add: Let_def; subst SubstitutionLemma; safe intro!: L18; insert L8 L9; simp; metis L8 L2 L12)
  lemma L22: "\<tau> is_subst_for x in (ren_for_subst x \<tau> \<phi>)" by (induct \<phi> rule: QInduct; auto simp add: Let_def) (metis L10)
  lemma L23: "(\<alpha>\<^sup>d) is_subst_for \<alpha> in \<phi>" by (induct \<phi>) auto
  lemma L24: assumes "\<alpha> not_free_in \<phi>" shows "[\<alpha>\<leftarrow>\<tau>](\<phi>) = \<phi>" using assms by (induct \<phi>) auto
  lemma L25: "\<beta> not_free_in \<phi> \<Longrightarrow> (\<alpha>\<^sup>d) is_subst_for \<beta> in \<phi>" by (induct \<phi>) auto
  lemma L26 [simp]: "z bound_in [x\<leftarrow>y\<^sup>d](\<phi>) = z bound_in \<phi>" by (induct \<phi>) auto
  definition ren_subst ("[_ \<leftarrow>\<^sub>r _]'(_')") where "[x \<leftarrow>\<^sub>r \<tau>](\<phi>) = [x\<leftarrow>\<tau>](ren_for_subst x \<tau> \<phi>)" \<comment>\<open>Renaming substitution\<close>
  lemma L27 [simp]: "(I \<Turnstile>\<^sup>d [x \<leftarrow>\<^sub>r \<tau>](\<phi>)) = (I\<langle>x\<leftarrow>I \<Turnstile>\<^sup>d \<tau>\<rangle> \<Turnstile>\<^sup>d \<phi>)" using L22 L21 unfolding ren_subst_def by force
  lemma L28 [simp]: "size ([x \<leftarrow>\<^sub>r y\<^sup>d](\<phi>)) = size \<phi>" by (induct \<phi> rule: QInduct) (auto simp: ren_subst_def Let_def)
  lemma L29: "I \<Turnstile>\<^sup>d (\<forall>\<^sup>dx. \<phi>) = (\<forall>\<tau>. I \<Turnstile>\<^sup>d ([x \<leftarrow>\<^sub>r \<tau>](\<phi>)))" by (smt L27 RelativeTruthD.simps(4))
end




