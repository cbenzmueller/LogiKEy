theory QBFinHOL_experiments imports QBFinHOL_deep  QBFinHOL_shallow  QBFinHOL_shallow_minimal                                   
begin
  abbreviation "(x::\<S>) \<equiv> 1"  abbreviation "(y::\<S>) \<equiv> 2"  abbreviation "(z::\<S>) \<equiv> 3"
  lemma "\<Turnstile>\<^sup>d \<forall>\<^sup>dx.\<exists>\<^sup>dy. (x\<^sup>d \<or>\<^sup>d y\<^sup>d)"       unfolding DefD apply simp by auto
  lemma "\<Turnstile>\<^sup>s \<forall>\<^sup>sx.\<exists>\<^sup>sy. (x\<^sup>s \<or>\<^sup>s y\<^sup>s)"        unfolding DefS apply simp by auto
  lemma "\<Turnstile>\<^sup>m \<forall>\<^sup>mx.\<exists>\<^sup>my. (x\<^sup>m \<or>\<^sup>m y\<^sup>m)"  unfolding DefM apply simp by (metis IF_surj surjE) 
  lemma "\<Turnstile>\<^sup>d \<forall>\<^sup>dx.\<exists>\<^sup>dy. (x\<^sup>d \<and>\<^sup>d y\<^sup>d)"       unfolding DefD apply simp nitpick oops \<comment>\<open>Counterexample\<close>
  lemma "\<Turnstile>\<^sup>s \<forall>\<^sup>sx.\<exists>\<^sup>sy. (x\<^sup>s \<and>\<^sup>s y\<^sup>s)"       unfolding DefS apply simp nitpick oops \<comment>\<open>Counterexample\<close>
  lemma "\<Turnstile>\<^sup>m \<forall>\<^sup>mx.\<exists>\<^sup>my. (x\<^sup>m \<and>\<^sup>m y\<^sup>m)"  unfolding DefM apply simp nitpick oops \<comment>\<open>Counterexample\<close>
  lemma "\<Turnstile>\<^sup>d \<forall>\<^sup>dx.\<forall>\<^sup>dy.\<exists>\<^sup>dz. (((z\<^sup>d \<supset>\<^sup>d ((x\<^sup>d \<supset>\<^sup>d \<not>\<^sup>d y\<^sup>d) \<and>\<^sup>d (y\<^sup>d \<supset>\<^sup>d \<not>\<^sup>d x\<^sup>d))) \<and>\<^sup>d (((x\<^sup>d \<supset>\<^sup>d \<not>\<^sup>d y\<^sup>d) \<and>\<^sup>d (y\<^sup>d \<supset>\<^sup>d \<not>\<^sup>d x\<^sup>d)) \<supset>\<^sup>d z\<^sup>d)))"
    unfolding DefD apply simp by auto
  lemma "\<Turnstile>\<^sup>s \<forall>\<^sup>sx.\<forall>\<^sup>sy.\<exists>\<^sup>sz. (((z\<^sup>s \<supset>\<^sup>s ((x\<^sup>s \<supset>\<^sup>s \<not>\<^sup>s y\<^sup>s) \<and>\<^sup>s (y\<^sup>s \<supset>\<^sup>s \<not>\<^sup>s x\<^sup>s))) \<and>\<^sup>s (((x\<^sup>s \<supset>\<^sup>s \<not>\<^sup>s y\<^sup>s) \<and>\<^sup>s (y\<^sup>s \<supset>\<^sup>s \<not>\<^sup>s x\<^sup>s)) \<supset>\<^sup>s z\<^sup>s)))"
    unfolding DefS apply simp by auto
  lemma "\<Turnstile>\<^sup>m \<forall>\<^sup>mx.\<forall>\<^sup>my.\<exists>\<^sup>mz. (((z\<^sup>m\<supset>\<^sup>m((x\<^sup>m\<supset>\<^sup>m \<not>\<^sup>my\<^sup>m) \<and>\<^sup>m (y\<^sup>m\<supset>\<^sup>m \<not>\<^sup>mx\<^sup>m))) \<and>\<^sup>m (((x\<^sup>m\<supset>\<^sup>m \<not>\<^sup>my\<^sup>m) \<and>\<^sup>m (y\<^sup>m\<supset>\<^sup>m \<not>\<^sup>mx\<^sup>m))\<supset>\<^sup>mz\<^sup>m)))"
    unfolding DefM apply simp by (metis IF_surj surjE)
end

