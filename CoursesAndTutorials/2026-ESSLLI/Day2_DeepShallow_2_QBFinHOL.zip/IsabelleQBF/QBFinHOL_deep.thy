theory QBFinHOL_deep imports QBFinHOL_preliminaries                                      
begin
\<comment>\<open>Deep embedding (of QBF in HOL)\<close>
  datatype \<F> = VarD \<S> ("_\<^sup>d") | NotD \<F> ("\<not>\<^sup>d _") | OrD \<F> \<F> (infixr "\<or>\<^sup>d" 925) | AllD \<S> \<F> ("\<forall>\<^sup>d_. _") 
\<comment>\<open>Further logical connectives as definitions\<close>
  definition ImpD  (infixr "\<supset>\<^sup>d " 92)  where                                         "\<phi> \<supset>\<^sup>d \<psi>  \<equiv>  (\<not>\<^sup>d\<phi>) \<or>\<^sup>d \<psi>"
  definition AndD  (infixr "\<and>\<^sup>d" 95)  where                                           "\<phi> \<and>\<^sup>d \<psi>  \<equiv>  \<not>\<^sup>d(\<phi> \<supset>\<^sup>d \<not>\<^sup>d\<psi>)"
  definition ExD    ("\<exists>\<^sup>d_. _")  where                                                       "\<exists>\<^sup>da. \<phi>  \<equiv>  \<not>\<^sup>d(\<forall>\<^sup>da. \<not>\<^sup>d\<phi>) "
  consts p :: \<S>
  definition TopD  ("\<top>\<^sup>d") where                                                                 "\<top>\<^sup>d   \<equiv>  p\<^sup>d \<supset>\<^sup>d p\<^sup>d"
  definition BotD   ("\<bottom>\<^sup>d") where                                                                 "\<bottom>\<^sup>d   \<equiv>  \<not>\<^sup>d \<top>\<^sup>d"
\<comment>\<open>Relative truth\<close>
  primrec RelativeTruthD ("_ \<Turnstile>\<^sup>d_" [100,100] 100) where          "I \<Turnstile>\<^sup>d(a\<^sup>d)        = I a"
                                                                                                       | "I \<Turnstile>\<^sup>d (\<not>\<^sup>d\<phi>)    = (\<not> I \<Turnstile>\<^sup>d \<phi>)"   
                                                                                                       | "I \<Turnstile>\<^sup>d \<phi> \<or>\<^sup>d \<psi>  = (I \<Turnstile>\<^sup>d \<phi> \<or> I \<Turnstile>\<^sup>d \<psi>)"
                                                                                                       | "I \<Turnstile>\<^sup>d \<forall>\<^sup>dx. \<phi>   = (\<forall>v.  I\<langle>x \<leftarrow> v\<rangle> \<Turnstile>\<^sup>d \<phi>)"
\<comment>\<open>Validity\<close>
  definition ValD ("\<Turnstile>\<^sup>d _" 9) where                                                          "\<Turnstile>\<^sup>d \<phi>  \<equiv>   \<forall>I. I \<Turnstile>\<^sup>d \<phi>"
\<comment>\<open>Collection of definitions in a bag called DefD\<close>
  named_theorems DefD 
  declare  ImpD_def[DefD] AndD_def[DefD] ExD_def[DefD] TopD_def[DefD] BotD_def[DefD] ValD_def[DefD]  
end

