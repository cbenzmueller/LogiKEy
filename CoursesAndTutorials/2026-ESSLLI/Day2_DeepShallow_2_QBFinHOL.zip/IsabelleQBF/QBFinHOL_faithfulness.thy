theory QBFinHOL_faithfulness                                                                                
  imports QBFinHOL_deep QBFinHOL_shallow_minimal QBFinHOL_shallow QBFinHOL_deep_subst_lemma QBFinHOL_surj
begin
\<comment>\<open>Mappings: deep to maximal shallow and deep to minimal shallow\<close>
  fun DpToShS ("\<lbrakk>_\<rbrakk>") where         "\<lbrakk>x\<^sup>d\<rbrakk> = x\<^sup>s" | "\<lbrakk>\<not>\<^sup>d\<phi>\<rbrakk> = \<not>\<^sup>s\<lbrakk>\<phi>\<rbrakk>"  | "\<lbrakk>\<phi>\<or>\<^sup>d\<psi>\<rbrakk> = \<lbrakk>\<phi>\<rbrakk>\<or>\<^sup>s\<lbrakk>\<psi>\<rbrakk>" | "\<lbrakk>\<forall>\<^sup>dv. \<phi>\<rbrakk> = \<forall>\<^sup>sv. \<lbrakk>\<phi>\<rbrakk>"
  fun DpToShM ("\<lparr>_\<rparr>") where        "\<lparr>x\<^sup>d\<rparr> = x\<^sup>m" | "\<lparr>\<not>\<^sup>d\<phi>\<rparr> = \<not>\<^sup>m\<lparr>\<phi>\<rparr>" | "\<lparr>\<phi>\<or>\<^sup>d\<psi>\<rparr> = \<lparr>\<phi>\<rparr>\<or>\<^sup>m\<lparr>\<psi>\<rparr>" | "\<lparr>\<forall>\<^sup>dv. \<phi>\<rparr> = (\<forall>\<^sup>mx. \<lparr>[v\<leftarrow>\<^sub>rx\<^sup>d](\<phi>)\<rparr>)"
\<comment>\<open>Proving faithfulness between deep and maximal shallow\<close>
  theorem FaithfulSDlem: "(I \<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>) \<longleftrightarrow> (I \<Turnstile>\<^sup>d \<phi>)"                by (induct \<phi> arbitrary: I) (auto simp: DefS DefD)
  theorem FaithfulSD:        "(\<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>) \<longleftrightarrow>   (\<Turnstile>\<^sup>d \<phi>)"                 by (simp add: FaithfulSDlem ValD_def ValS_def)
\<comment>\<open>Proving faithfulness between deep and minimal shallow\<close>
  theorem FaithfulMD:       "(\<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (IF \<Turnstile>\<^sup>d \<phi>)" by (induct \<phi> rule: QInduct; simp add: DefD DefM; metis IF_surj surjE)
\<comment>\<open>Proving faithfulness between maximal and minimal shallow\<close>
  theorem FaithfulMS:        "(\<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (IF \<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>)"             using FaithfulSDlem FaithfulMD by auto
end



 