theory QBFinHOL_experiments_further imports QBFinHOL_deep  QBFinHOL_shallow  QBFinHOL_shallow_minimal                                   
begin
abbreviation "(x::\<S>) \<equiv> 1"  
abbreviation "(y::\<S>) \<equiv> 2" 
abbreviation "(z::\<S>) \<equiv> 3"
abbreviation "(u::\<S>) \<equiv> 4"
abbreviation "(v::\<S>) \<equiv> 5"
abbreviation "(w::\<S>) \<equiv> 6"
abbreviation "(a::\<S>) \<equiv> 7" 
abbreviation "(b::\<S>) \<equiv> 8"
abbreviation "(c::\<S>) \<equiv> 9"
abbreviation "(d::\<S>) \<equiv> 10"
abbreviation "(e::\<S>) \<equiv> 11"
abbreviation "(f::\<S>) \<equiv> 12"


(* QBF1: \<forall>x \<exists>y \<exists>z. (x \<supset> y) \<and> (y \<supset> z) \<and> (z \<or> \<not>x) *)
abbreviation "QBF1_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<exists>\<^sup>d z. ((x\<^sup>d \<supset>\<^sup>d y\<^sup>d) \<and>\<^sup>d (y\<^sup>d \<supset>\<^sup>d z\<^sup>d) \<and>\<^sup>d (z\<^sup>d \<or>\<^sup>d \<not>\<^sup>d x\<^sup>d)))"
abbreviation "QBF1_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<exists>\<^sup>s z. ((x\<^sup>s \<supset>\<^sup>s y\<^sup>s) \<and>\<^sup>s (y\<^sup>s \<supset>\<^sup>s z\<^sup>s) \<and>\<^sup>s (z\<^sup>s \<or>\<^sup>s \<not>\<^sup>s x\<^sup>s)))"
abbreviation "QBF1_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<exists>\<^sup>m z. ((x\<^sup>m \<supset>\<^sup>m y\<^sup>m) \<and>\<^sup>m (y\<^sup>m \<supset>\<^sup>m z\<^sup>m) \<and>\<^sup>m (z\<^sup>m \<or>\<^sup>m \<not>\<^sup>m x\<^sup>m)))"

lemma QBF1_d: "QBF1_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF1_s: "QBF1_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF1_m: "QBF1_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF2: \<forall>x \<forall>y \<exists>z. (x \<and> y) \<supset> z *)
abbreviation "QBF2_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. ((x\<^sup>d \<and>\<^sup>d y\<^sup>d) \<supset>\<^sup>d z\<^sup>d))"
abbreviation "QBF2_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. ((x\<^sup>s \<and>\<^sup>s y\<^sup>s) \<supset>\<^sup>s z\<^sup>s))"
abbreviation "QBF2_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. ((x\<^sup>m \<and>\<^sup>m y\<^sup>m) \<supset>\<^sup>m z\<^sup>m))"

lemma QBF2_d: "QBF2_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF2_s: "QBF2_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF2_m: "QBF2_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF3: \<forall>x \<exists>y \<forall>z. (x \<supset> y) \<or> (y \<supset> z) *)
abbreviation "QBF3_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. ((x\<^sup>d \<supset>\<^sup>d y\<^sup>d) \<or>\<^sup>d (y\<^sup>d \<supset>\<^sup>d z\<^sup>d)))"
abbreviation "QBF3_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. ((x\<^sup>s \<supset>\<^sup>s y\<^sup>s) \<or>\<^sup>s (y\<^sup>s \<supset>\<^sup>s z\<^sup>s)))"
abbreviation "QBF3_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. ((x\<^sup>m \<supset>\<^sup>m y\<^sup>m) \<or>\<^sup>m (y\<^sup>m \<supset>\<^sup>m z\<^sup>m)))"

lemma QBF3_d: "QBF3_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF3_s: "QBF3_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF3_m: "QBF3_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF4: \<exists>x \<forall>y \<exists>z. (x \<and> \<not>y) \<or> z *)
abbreviation "QBF4_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. ((x\<^sup>d \<and>\<^sup>d \<not>\<^sup>d y\<^sup>d) \<or>\<^sup>d z\<^sup>d))"
abbreviation "QBF4_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. ((x\<^sup>s \<and>\<^sup>s \<not>\<^sup>s y\<^sup>s) \<or>\<^sup>s z\<^sup>s))"
abbreviation "QBF4_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. ((x\<^sup>m \<and>\<^sup>m \<not>\<^sup>m y\<^sup>m) \<or>\<^sup>m z\<^sup>m))"

lemma QBF4_d: "QBF4_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF4_s: "QBF4_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF4_m: "QBF4_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF5: \<forall>x \<exists>y \<exists>z. (x \<or> y) \<and> (\<not>y \<or> z) *)
abbreviation "QBF5_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<exists>\<^sup>d z. ((x\<^sup>d \<or>\<^sup>d y\<^sup>d) \<and>\<^sup>d ((\<not>\<^sup>d y\<^sup>d) \<or>\<^sup>d z\<^sup>d)))"
abbreviation "QBF5_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<exists>\<^sup>s z. ((x\<^sup>s \<or>\<^sup>s y\<^sup>s) \<and>\<^sup>s ((\<not>\<^sup>s y\<^sup>s) \<or>\<^sup>s z\<^sup>s)))"
abbreviation "QBF5_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<exists>\<^sup>m z. ((x\<^sup>m \<or>\<^sup>m y\<^sup>m) \<and>\<^sup>m ((\<not>\<^sup>m y\<^sup>m) \<or>\<^sup>m z\<^sup>m)))"

lemma QBF5_d: "QBF5_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF5_s: "QBF5_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF5_m: "QBF5_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF6: \<forall>x \<forall>y \<exists>z \<forall>w. ((x \<supset> y) \<and> (y \<supset> x)) \<or> (z \<supset> w) *)
abbreviation "QBF6_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. \<forall>\<^sup>d w. ((((x\<^sup>d \<supset>\<^sup>d y\<^sup>d) \<and>\<^sup>d (y\<^sup>d \<supset>\<^sup>d x\<^sup>d)) \<or>\<^sup>d (z\<^sup>d \<supset>\<^sup>d w\<^sup>d))))"
abbreviation "QBF6_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. \<forall>\<^sup>s w. ((((x\<^sup>s \<supset>\<^sup>s y\<^sup>s) \<and>\<^sup>s (y\<^sup>s \<supset>\<^sup>s x\<^sup>s)) \<or>\<^sup>s (z\<^sup>s \<supset>\<^sup>s w\<^sup>s))))"
abbreviation "QBF6_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. \<forall>\<^sup>m w. ((((x\<^sup>m \<supset>\<^sup>m y\<^sup>m) \<and>\<^sup>m (y\<^sup>m \<supset>\<^sup>m x\<^sup>m)) \<or>\<^sup>m (z\<^sup>m \<supset>\<^sup>m w\<^sup>m))))"

lemma QBF6_d: "QBF6_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF6_s: "QBF6_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF6_m: "QBF6_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops

lemma QBF6_d: "QBF6_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF6_s: "QBF6_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF6_m: "QBF6_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF7: \<exists>x \<forall>y \<forall>z \<exists>w. (x \<supset> y) \<and> (y \<supset> z) \<and> (z \<supset> w) *)
abbreviation "QBF7_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d x. \<forall>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d w. ((x\<^sup>d \<supset>\<^sup>d y\<^sup>d) \<and>\<^sup>d (y\<^sup>d \<supset>\<^sup>d z\<^sup>d) \<and>\<^sup>d (z\<^sup>d \<supset>\<^sup>d w\<^sup>d)))"
abbreviation "QBF7_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s x. \<forall>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s w. ((x\<^sup>s \<supset>\<^sup>s y\<^sup>s) \<and>\<^sup>s (y\<^sup>s \<supset>\<^sup>s z\<^sup>s) \<and>\<^sup>s (z\<^sup>s \<supset>\<^sup>s w\<^sup>s)))"
abbreviation "QBF7_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m x. \<forall>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m w. ((x\<^sup>m \<supset>\<^sup>m y\<^sup>m) \<and>\<^sup>m (y\<^sup>m \<supset>\<^sup>m z\<^sup>m) \<and>\<^sup>m (z\<^sup>m \<supset>\<^sup>m w\<^sup>m)))"

lemma QBF7_d: "QBF7_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF7_s: "QBF7_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF7_m: "QBF7_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF8: \<forall>x \<exists>y \<forall>z \<exists>w. (x \<and> y) \<or> (\<not>z \<and> w) *)
abbreviation "QBF8_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d w. ((x\<^sup>d \<and>\<^sup>d y\<^sup>d) \<or>\<^sup>d ((\<not>\<^sup>d z\<^sup>d) \<and>\<^sup>d w\<^sup>d)))"
abbreviation "QBF8_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s w. ((x\<^sup>s \<and>\<^sup>s y\<^sup>s) \<or>\<^sup>s ((\<not>\<^sup>s z\<^sup>s) \<and>\<^sup>s w\<^sup>s)))"
abbreviation "QBF8_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m w. ((x\<^sup>m \<and>\<^sup>m y\<^sup>m) \<or>\<^sup>m ((\<not>\<^sup>m z\<^sup>m) \<and>\<^sup>m w\<^sup>m)))"

lemma QBF8_d: "QBF8_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF8_s: "QBF8_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF8_m: "QBF8_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF9: \<exists>x \<forall>y \<exists>z \<forall>w. (x \<or> y) \<and> (z \<or> \<not>w) *)
abbreviation "QBF9_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. \<forall>\<^sup>d w. ((x\<^sup>d \<or>\<^sup>d y\<^sup>d) \<and>\<^sup>d (z\<^sup>d \<or>\<^sup>d \<not>\<^sup>d w\<^sup>d)))"
abbreviation "QBF9_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. \<forall>\<^sup>s w. ((x\<^sup>s \<or>\<^sup>s y\<^sup>s) \<and>\<^sup>s (z\<^sup>s \<or>\<^sup>s \<not>\<^sup>s w\<^sup>s)))"
abbreviation "QBF9_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. \<forall>\<^sup>m w. ((x\<^sup>m \<or>\<^sup>m y\<^sup>m) \<and>\<^sup>m (z\<^sup>m \<or>\<^sup>m \<not>\<^sup>m w\<^sup>m)))"

lemma QBF9_d: "QBF9_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF9_s: "QBF9_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF9_m: "QBF9_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF10: hardest: \<forall>x \<exists>y \<forall>z \<exists>w \<forall>u. ((x \<supset> y) \<and> (y \<or> z)) \<or> ((w \<supset> u) \<and> (\<not>x \<or> w)) *)
abbreviation "QBF10_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d w. \<forall>\<^sup>d u. (((x\<^sup>d \<supset>\<^sup>d y\<^sup>d) \<and>\<^sup>d (y\<^sup>d \<or>\<^sup>d z\<^sup>d)) \<or>\<^sup>d ((w\<^sup>d \<supset>\<^sup>d u\<^sup>d) \<and>\<^sup>d ((\<not>\<^sup>d x\<^sup>d) \<or>\<^sup>d w\<^sup>d))))"
abbreviation "QBF10_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s w. \<forall>\<^sup>s u. (((x\<^sup>s \<supset>\<^sup>s y\<^sup>s) \<and>\<^sup>s (y\<^sup>s \<or>\<^sup>s z\<^sup>s)) \<or>\<^sup>s ((w\<^sup>s \<supset>\<^sup>s u\<^sup>s) \<and>\<^sup>s ((\<not>\<^sup>s x\<^sup>s) \<or>\<^sup>s w\<^sup>s))))"
abbreviation "QBF10_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m w. \<forall>\<^sup>m u. (((x\<^sup>m \<supset>\<^sup>m y\<^sup>m) \<and>\<^sup>m (y\<^sup>m \<or>\<^sup>m z\<^sup>m)) \<or>\<^sup>m ((w\<^sup>m \<supset>\<^sup>m u\<^sup>m) \<and>\<^sup>m ((\<not>\<^sup>m x\<^sup>m) \<or>\<^sup>m w\<^sup>m))))"

lemma QBF10_d: "QBF10_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF10_s: "QBF10_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF10_m: "QBF10_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF11: \<forall>x \<exists>y \<forall>z \<exists>u. ((x \<supset> y) \<and> (\<not>y \<or> z) \<or> ((u \<supset> x) \<and> \<not>z)) *)
abbreviation "QBF11_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d u. ((((x\<^sup>d \<supset>\<^sup>d y\<^sup>d) \<and>\<^sup>d ((\<not>\<^sup>d y\<^sup>d) \<or>\<^sup>d z\<^sup>d)) \<or>\<^sup>d ((u\<^sup>d \<supset>\<^sup>d x\<^sup>d) \<and>\<^sup>d (\<not>\<^sup>d z\<^sup>d)))))"
abbreviation "QBF11_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s u. ((((x\<^sup>s \<supset>\<^sup>s y\<^sup>s) \<and>\<^sup>s ((\<not>\<^sup>s y\<^sup>s) \<or>\<^sup>s z\<^sup>s)) \<or>\<^sup>s ((u\<^sup>s \<supset>\<^sup>s x\<^sup>s) \<and>\<^sup>s (\<not>\<^sup>s z\<^sup>s)))))"
abbreviation "QBF11_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m u. ((((x\<^sup>m \<supset>\<^sup>m y\<^sup>m) \<and>\<^sup>m ((\<not>\<^sup>m y\<^sup>m) \<or>\<^sup>m z\<^sup>m)) \<or>\<^sup>m ((u\<^sup>m \<supset>\<^sup>m x\<^sup>m) \<and>\<^sup>m (\<not>\<^sup>m z\<^sup>m)))))"

lemma QBF11_d: "QBF11_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF11_s: "QBF11_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF11_m: "QBF11_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF12: \<exists>x \<forall>y \<exists>z \<forall>u \<exists>v. ((x \<or> (\<not>y)) \<and> (z \<supset> u) \<or> (\<not>v \<and> x)) *)
abbreviation "QBF12_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. \<forall>\<^sup>d u. \<exists>\<^sup>d v. ((((x\<^sup>d \<or>\<^sup>d (\<not>\<^sup>d y\<^sup>d)) \<and>\<^sup>d (z\<^sup>d \<supset>\<^sup>d u\<^sup>d)) \<or>\<^sup>d ((\<not>\<^sup>d v\<^sup>d) \<and>\<^sup>d x\<^sup>d))))"
abbreviation "QBF12_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. \<forall>\<^sup>s u. \<exists>\<^sup>s v. ((((x\<^sup>s \<or>\<^sup>s (\<not>\<^sup>s y\<^sup>s)) \<and>\<^sup>s (z\<^sup>s \<supset>\<^sup>s u\<^sup>s)) \<or>\<^sup>s ((\<not>\<^sup>s v\<^sup>s) \<and>\<^sup>s x\<^sup>s))))"
abbreviation "QBF12_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. \<forall>\<^sup>m u. \<exists>\<^sup>m v. ((((x\<^sup>m \<or>\<^sup>m (\<not>\<^sup>m y\<^sup>m)) \<and>\<^sup>m (z\<^sup>m \<supset>\<^sup>m u\<^sup>m)) \<or>\<^sup>m ((\<not>\<^sup>m v\<^sup>m) \<and>\<^sup>m x\<^sup>m))))"

lemma QBF12_d: "QBF12_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF12_s: "QBF12_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF12_m: "QBF12_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF13: \<forall>x \<exists>y \<forall>z \<exists>u \<forall>v \<exists>w. (((x \<supset> y) \<and> ((\<not>z) \<or> u)) \<or> ((v \<and> \<not>w) \<supset> y)) *)
abbreviation "QBF13_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d u. \<forall>\<^sup>d v. \<exists>\<^sup>d w. ((((x\<^sup>d \<supset>\<^sup>d y\<^sup>d) \<and>\<^sup>d ((\<not>\<^sup>d z\<^sup>d) \<or>\<^sup>d u\<^sup>d)) \<or>\<^sup>d ((v\<^sup>d \<and>\<^sup>d (\<not>\<^sup>d w\<^sup>d)) \<supset>\<^sup>d y\<^sup>d))))"
abbreviation "QBF13_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s u. \<forall>\<^sup>s v. \<exists>\<^sup>s w. ((((x\<^sup>s \<supset>\<^sup>s y\<^sup>s) \<and>\<^sup>s ((\<not>\<^sup>s z\<^sup>s) \<or>\<^sup>s u\<^sup>s)) \<or>\<^sup>s ((v\<^sup>s \<and>\<^sup>s (\<not>\<^sup>s w\<^sup>s)) \<supset>\<^sup>s y\<^sup>s))))"
abbreviation "QBF13_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m u. \<forall>\<^sup>m v. \<exists>\<^sup>m w. ((((x\<^sup>m \<supset>\<^sup>m y\<^sup>m) \<and>\<^sup>m ((\<not>\<^sup>m z\<^sup>m) \<or>\<^sup>m u\<^sup>m)) \<or>\<^sup>m ((v\<^sup>m \<and>\<^sup>m (\<not>\<^sup>m w\<^sup>m)) \<supset>\<^sup>m y\<^sup>m))))"

lemma QBF13_d: "QBF13_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF13_s: "QBF13_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF13_m: "QBF13_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF14: \<exists>x \<forall>y \<exists>z \<forall>u \<exists>v \<forall>w. (((x \<and> \<not>y) \<supset> z) \<or> ((u \<or> \<not>v) \<and> (w \<supset> x))) *)
abbreviation "QBF14_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. \<forall>\<^sup>d u. \<exists>\<^sup>d v. \<forall>\<^sup>d w. ((((x\<^sup>d \<and>\<^sup>d (\<not>\<^sup>d y\<^sup>d)) \<supset>\<^sup>d z\<^sup>d) \<or>\<^sup>d (((u\<^sup>d \<or>\<^sup>d (\<not>\<^sup>d v\<^sup>d)) \<and>\<^sup>d (w\<^sup>d \<supset>\<^sup>d x\<^sup>d))))))"
abbreviation "QBF14_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. \<forall>\<^sup>s u. \<exists>\<^sup>s v. \<forall>\<^sup>s w. ((((x\<^sup>s \<and>\<^sup>s (\<not>\<^sup>s y\<^sup>s)) \<supset>\<^sup>s z\<^sup>s) \<or>\<^sup>s (((u\<^sup>s \<or>\<^sup>s (\<not>\<^sup>s v\<^sup>s)) \<and>\<^sup>s (w\<^sup>s \<supset>\<^sup>s x\<^sup>s))))))"
abbreviation "QBF14_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. \<forall>\<^sup>m u. \<exists>\<^sup>m v. \<forall>\<^sup>m w. ((((x\<^sup>m \<and>\<^sup>m (\<not>\<^sup>m y\<^sup>m)) \<supset>\<^sup>m z\<^sup>m) \<or>\<^sup>m (((u\<^sup>m \<or>\<^sup>m (\<not>\<^sup>m v\<^sup>m)) \<and>\<^sup>m (w\<^sup>m \<supset>\<^sup>m x\<^sup>m))))))"

lemma QBF14_d: "QBF14_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF14_s: "QBF14_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF14_m: "QBF14_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF15: \<forall>x \<exists>y \<forall>z \<exists>u \<forall>v \<exists>w. (((x \<or> y) \<and> (\<not>z \<or> u)) \<supset> ((v \<and> w) \<or> (\<not>x \<and> \<not>y))) *)
abbreviation "QBF15_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d u. \<forall>\<^sup>d v. \<exists>\<^sup>d w. ((((x\<^sup>d \<or>\<^sup>d y\<^sup>d) \<and>\<^sup>d ((\<not>\<^sup>d z\<^sup>d) \<or>\<^sup>d u\<^sup>d)) \<supset>\<^sup>d ((v\<^sup>d \<and>\<^sup>d w\<^sup>d) \<or>\<^sup>d ((\<not>\<^sup>d x\<^sup>d) \<and>\<^sup>d (\<not>\<^sup>d y\<^sup>d))))))"
abbreviation "QBF15_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s u. \<forall>\<^sup>s v. \<exists>\<^sup>s w. ((((x\<^sup>s \<or>\<^sup>s y\<^sup>s) \<and>\<^sup>s ((\<not>\<^sup>s z\<^sup>s) \<or>\<^sup>s u\<^sup>s)) \<supset>\<^sup>s ((v\<^sup>s \<and>\<^sup>s w\<^sup>s) \<or>\<^sup>s ((\<not>\<^sup>s x\<^sup>s) \<and>\<^sup>s (\<not>\<^sup>s y\<^sup>s))))))"
abbreviation "QBF15_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m u. \<forall>\<^sup>m v. \<exists>\<^sup>m w. ((((x\<^sup>m \<or>\<^sup>m y\<^sup>m) \<and>\<^sup>m ((\<not>\<^sup>m z\<^sup>m) \<or>\<^sup>m u\<^sup>m)) \<supset>\<^sup>m ((v\<^sup>m \<and>\<^sup>m w\<^sup>m) \<or>\<^sup>m ((\<not>\<^sup>m x\<^sup>m) \<and>\<^sup>m (\<not>\<^sup>m y\<^sup>m))))))"

lemma QBF15_d: "QBF15_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF15_s: "QBF15_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF15_m: "QBF15_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF16: \<forall>x \<exists>y \<forall>z \<exists>u \<forall>v \<exists>w. (((x \<supset> y) \<and> ((\<not>z) \<or> u)) \<or> ((v \<supset> w) \<and> (\<not>u \<or> x))) *)
abbreviation "QBF16_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d u. \<forall>\<^sup>d v. \<exists>\<^sup>d w. ((((x\<^sup>d \<supset>\<^sup>d y\<^sup>d) \<and>\<^sup>d ((\<not>\<^sup>d z\<^sup>d) \<or>\<^sup>d u\<^sup>d)) \<or>\<^sup>d ((v\<^sup>d \<supset>\<^sup>d w\<^sup>d) \<and>\<^sup>d ((\<not>\<^sup>d u\<^sup>d) \<or>\<^sup>d x\<^sup>d)))))"
abbreviation "QBF16_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s u. \<forall>\<^sup>s v. \<exists>\<^sup>s w. ((((x\<^sup>s \<supset>\<^sup>s y\<^sup>s) \<and>\<^sup>s ((\<not>\<^sup>s z\<^sup>s) \<or>\<^sup>s u\<^sup>s)) \<or>\<^sup>s ((v\<^sup>s \<supset>\<^sup>s w\<^sup>s) \<and>\<^sup>s ((\<not>\<^sup>s u\<^sup>s) \<or>\<^sup>s x\<^sup>s)))))"
abbreviation "QBF16_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m u. \<forall>\<^sup>m v. \<exists>\<^sup>m w. ((((x\<^sup>m \<supset>\<^sup>m y\<^sup>m) \<and>\<^sup>m ((\<not>\<^sup>m z\<^sup>m) \<or>\<^sup>m u\<^sup>m)) \<or>\<^sup>m ((v\<^sup>m \<supset>\<^sup>m w\<^sup>m) \<and>\<^sup>m ((\<not>\<^sup>m u\<^sup>m) \<or>\<^sup>m x\<^sup>m)))))"

lemma QBF16_d: "QBF16_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF16_s: "QBF16_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF16_m: "QBF16_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF17: \<exists>x \<forall>y \<exists>z \<forall>u \<exists>v \<forall>w. (((x \<and> \<not>y) \<or> (z \<supset> u)) \<and> ((\<not>v \<or> w) \<supset> (\<not>x \<or> y))) *)
abbreviation "QBF17_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. \<forall>\<^sup>d u. \<exists>\<^sup>d v. \<forall>\<^sup>d w. ((((x\<^sup>d \<and>\<^sup>d (\<not>\<^sup>d y\<^sup>d)) \<or>\<^sup>d (z\<^sup>d \<supset>\<^sup>d u\<^sup>d)) \<and>\<^sup>d (((\<not>\<^sup>d v\<^sup>d) \<or>\<^sup>d w\<^sup>d) \<supset>\<^sup>d ((\<not>\<^sup>d x\<^sup>d) \<or>\<^sup>d y\<^sup>d)))))"
abbreviation "QBF17_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. \<forall>\<^sup>s u. \<exists>\<^sup>s v. \<forall>\<^sup>s w. ((((x\<^sup>s \<and>\<^sup>s (\<not>\<^sup>s y\<^sup>s)) \<or>\<^sup>s (z\<^sup>s \<supset>\<^sup>s u\<^sup>s)) \<and>\<^sup>s (((\<not>\<^sup>s v\<^sup>s) \<or>\<^sup>s w\<^sup>s) \<supset>\<^sup>s ((\<not>\<^sup>s x\<^sup>s) \<or>\<^sup>s y\<^sup>s)))))"
abbreviation "QBF17_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. \<forall>\<^sup>m u. \<exists>\<^sup>m v. \<forall>\<^sup>m w. ((((x\<^sup>m \<and>\<^sup>m (\<not>\<^sup>m y\<^sup>m)) \<or>\<^sup>m (z\<^sup>m \<supset>\<^sup>m u\<^sup>m)) \<and>\<^sup>m (((\<not>\<^sup>m v\<^sup>m) \<or>\<^sup>m w\<^sup>m) \<supset>\<^sup>m ((\<not>\<^sup>m x\<^sup>m) \<or>\<^sup>m y\<^sup>m)))))"

lemma QBF17_d: "QBF17_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF17_s: "QBF17_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF17_m: "QBF17_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF18: \<forall>x \<forall>y \<exists>z \<exists>u \<forall>v \<exists>w. ((((x \<or> \<not>y) \<and> (z \<supset> u)) \<or> ((\<not>v \<and> w) \<or> x))) *)
abbreviation "QBF18_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. \<exists>\<^sup>d u. \<forall>\<^sup>d v. \<exists>\<^sup>d w. ((((x\<^sup>d \<or>\<^sup>d (\<not>\<^sup>d y\<^sup>d)) \<and>\<^sup>d (z\<^sup>d \<supset>\<^sup>d u\<^sup>d)) \<or>\<^sup>d (((\<not>\<^sup>d v\<^sup>d) \<and>\<^sup>d w\<^sup>d) \<or>\<^sup>d x\<^sup>d))))"
abbreviation "QBF18_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. \<exists>\<^sup>s u. \<forall>\<^sup>s v. \<exists>\<^sup>s w. ((((x\<^sup>s \<or>\<^sup>s (\<not>\<^sup>s y\<^sup>s)) \<and>\<^sup>s (z\<^sup>s \<supset>\<^sup>s u\<^sup>s)) \<or>\<^sup>s (((\<not>\<^sup>s v\<^sup>s) \<and>\<^sup>s w\<^sup>s) \<or>\<^sup>s x\<^sup>s))))"
abbreviation "QBF18_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. \<exists>\<^sup>m u. \<forall>\<^sup>m v. \<exists>\<^sup>m w. ((((x\<^sup>m \<or>\<^sup>m (\<not>\<^sup>m y\<^sup>m)) \<and>\<^sup>m (z\<^sup>m \<supset>\<^sup>m u\<^sup>m)) \<or>\<^sup>m (((\<not>\<^sup>m v\<^sup>m) \<and>\<^sup>m w\<^sup>m) \<or>\<^sup>m x\<^sup>m))))"

lemma QBF18_d: "QBF18_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF18_s: "QBF18_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF18_m: "QBF18_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF19: \<exists>x \<forall>y \<forall>z \<exists>u \<forall>v \<exists>w. (((x \<and> y) \<supset> (\<not>z \<or> u)) \<and> ((v \<or> \<not>w) \<supset> (x \<or> \<not>u))) *)
abbreviation "QBF19_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d x. \<forall>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d u. \<forall>\<^sup>d v. \<exists>\<^sup>d w. ((((x\<^sup>d \<and>\<^sup>d y\<^sup>d) \<supset>\<^sup>d ((\<not>\<^sup>d z\<^sup>d) \<or>\<^sup>d u\<^sup>d)) \<and>\<^sup>d ((v\<^sup>d \<or>\<^sup>d (\<not>\<^sup>d w\<^sup>d)) \<supset>\<^sup>d (x\<^sup>d \<or>\<^sup>d (\<not>\<^sup>d u\<^sup>d))))))"
abbreviation "QBF19_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s x. \<forall>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s u. \<forall>\<^sup>s v. \<exists>\<^sup>s w. ((((x\<^sup>s \<and>\<^sup>s y\<^sup>s) \<supset>\<^sup>s ((\<not>\<^sup>s z\<^sup>s) \<or>\<^sup>s u\<^sup>s)) \<and>\<^sup>s ((v\<^sup>s \<or>\<^sup>s (\<not>\<^sup>s w\<^sup>s)) \<supset>\<^sup>s (x\<^sup>s \<or>\<^sup>s (\<not>\<^sup>s u\<^sup>s))))))"
abbreviation "QBF19_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m x. \<forall>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m u. \<forall>\<^sup>m v. \<exists>\<^sup>m w. ((((x\<^sup>m \<and>\<^sup>m y\<^sup>m) \<supset>\<^sup>m ((\<not>\<^sup>m z\<^sup>m) \<or>\<^sup>m u\<^sup>m)) \<and>\<^sup>m ((v\<^sup>m \<or>\<^sup>m (\<not>\<^sup>m w\<^sup>m)) \<supset>\<^sup>m (x\<^sup>m \<or>\<^sup>m (\<not>\<^sup>m u\<^sup>m))))))"

lemma QBF19_d: "QBF19_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF19_s: "QBF19_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF19_m: "QBF19_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF20: \<forall>x \<exists>y \<forall>z \<exists>u \<forall>v \<exists>w. (((x \<or> \<not>y) \<and> (z \<supset> u)) \<supset> ((v \<and> \<not>w) \<or> (\<not>x \<or> y))) *)
abbreviation "QBF20_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d u. \<forall>\<^sup>d v. \<exists>\<^sup>d w. ((((x\<^sup>d \<or>\<^sup>d (\<not>\<^sup>d y\<^sup>d)) \<and>\<^sup>d (z\<^sup>d \<supset>\<^sup>d u\<^sup>d)) \<supset>\<^sup>d ((v\<^sup>d \<and>\<^sup>d (\<not>\<^sup>d w\<^sup>d)) \<or>\<^sup>d ((\<not>\<^sup>d x\<^sup>d) \<or>\<^sup>d y\<^sup>d)))))"
abbreviation "QBF20_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s u. \<forall>\<^sup>s v. \<exists>\<^sup>s w. ((((x\<^sup>s \<or>\<^sup>s (\<not>\<^sup>s y\<^sup>s)) \<and>\<^sup>s (z\<^sup>s \<supset>\<^sup>s u\<^sup>s)) \<supset>\<^sup>s ((v\<^sup>s \<and>\<^sup>s (\<not>\<^sup>s w\<^sup>s)) \<or>\<^sup>s ((\<not>\<^sup>s x\<^sup>s) \<or>\<^sup>s y\<^sup>s)))))"
abbreviation "QBF20_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m u. \<forall>\<^sup>m v. \<exists>\<^sup>m w. ((((x\<^sup>m \<or>\<^sup>m (\<not>\<^sup>m y\<^sup>m)) \<and>\<^sup>m (z\<^sup>m \<supset>\<^sup>m u\<^sup>m)) \<supset>\<^sup>m ((v\<^sup>m \<and>\<^sup>m (\<not>\<^sup>m w\<^sup>m)) \<or>\<^sup>m ((\<not>\<^sup>m x\<^sup>m) \<or>\<^sup>m y\<^sup>m)))))"

lemma QBF20_d: "QBF20_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF20_s: "QBF20_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF20_m: "QBF20_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF21: \<exists>x \<forall>y \<exists>z \<forall>u \<exists>v \<forall>w. (((x \<supset> (\<not>y)) \<and> (z \<or> u)) \<supset> ((v \<supset> w) \<and> (\<not>x \<or> \<not>u))) *)
abbreviation "QBF21_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. \<forall>\<^sup>d u. \<exists>\<^sup>d v. \<forall>\<^sup>d w. ((((x\<^sup>d \<supset>\<^sup>d (\<not>\<^sup>d y\<^sup>d)) \<and>\<^sup>d (z\<^sup>d \<or>\<^sup>d u\<^sup>d)) \<supset>\<^sup>d ((v\<^sup>d \<supset>\<^sup>d w\<^sup>d) \<and>\<^sup>d ((\<not>\<^sup>d x\<^sup>d) \<or>\<^sup>d (\<not>\<^sup>d u\<^sup>d))))))"
abbreviation "QBF21_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. \<forall>\<^sup>s u. \<exists>\<^sup>s v. \<forall>\<^sup>s w. ((((x\<^sup>s \<supset>\<^sup>s (\<not>\<^sup>s y\<^sup>s)) \<and>\<^sup>s (z\<^sup>s \<or>\<^sup>s u\<^sup>s)) \<supset>\<^sup>s ((v\<^sup>s \<supset>\<^sup>s w\<^sup>s) \<and>\<^sup>s ((\<not>\<^sup>s x\<^sup>s) \<or>\<^sup>s (\<not>\<^sup>s u\<^sup>s))))))"
abbreviation "QBF21_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. \<forall>\<^sup>m u. \<exists>\<^sup>m v. \<forall>\<^sup>m w. ((((x\<^sup>m \<supset>\<^sup>m (\<not>\<^sup>m y\<^sup>m)) \<and>\<^sup>m (z\<^sup>m \<or>\<^sup>m u\<^sup>m)) \<supset>\<^sup>m ((v\<^sup>m \<supset>\<^sup>m w\<^sup>m) \<and>\<^sup>m ((\<not>\<^sup>m x\<^sup>m) \<or>\<^sup>m (\<not>\<^sup>m u\<^sup>m))))))"

lemma QBF21_d: "QBF21_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF21_s: "QBF21_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF21_m: "QBF21_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF22: \<forall>x \<exists>y \<forall>z \<exists>u \<forall>v \<exists>w. (((x \<or> \<not>y) \<supset> (z \<and> \<not>u)) \<or> ((v \<or> w) \<supset> (\<not>x \<or> y))) *)
abbreviation "QBF22_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d u. \<forall>\<^sup>d v. \<exists>\<^sup>d w. ((((x\<^sup>d \<or>\<^sup>d (\<not>\<^sup>d y\<^sup>d)) \<supset>\<^sup>d (z\<^sup>d \<and>\<^sup>d (\<not>\<^sup>d u\<^sup>d))) \<or>\<^sup>d ((v\<^sup>d \<or>\<^sup>d w\<^sup>d) \<supset>\<^sup>d ((\<not>\<^sup>d x\<^sup>d) \<or>\<^sup>d y\<^sup>d)))))"
abbreviation "QBF22_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s u. \<forall>\<^sup>s v. \<exists>\<^sup>s w. ((((x\<^sup>s \<or>\<^sup>s (\<not>\<^sup>s y\<^sup>s)) \<supset>\<^sup>s (z\<^sup>s \<and>\<^sup>s (\<not>\<^sup>s u\<^sup>s))) \<or>\<^sup>s ((v\<^sup>s \<or>\<^sup>s w\<^sup>s) \<supset>\<^sup>s ((\<not>\<^sup>s x\<^sup>s) \<or>\<^sup>s y\<^sup>s)))))"
abbreviation "QBF22_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m u. \<forall>\<^sup>m v. \<exists>\<^sup>m w. ((((x\<^sup>m \<or>\<^sup>m (\<not>\<^sup>m y\<^sup>m)) \<supset>\<^sup>m (z\<^sup>m \<and>\<^sup>m (\<not>\<^sup>m u\<^sup>m))) \<or>\<^sup>m ((v\<^sup>m \<or>\<^sup>m w\<^sup>m) \<supset>\<^sup>m ((\<not>\<^sup>m x\<^sup>m) \<or>\<^sup>m y\<^sup>m)))))"

lemma QBF22_d: "QBF22_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF22_s: "QBF22_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF22_m: "QBF22_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF23: \<forall>x \<exists>y \<forall>z \<exists>u \<forall>v \<exists>w. ((((x \<supset> \<not>y) \<or> (z \<and> u)) \<and> ((v \<supset> w) \<or> (\<not>x \<and> y)))) *)
abbreviation "QBF23_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d u. \<forall>\<^sup>d v. \<exists>\<^sup>d w. ((((x\<^sup>d \<supset>\<^sup>d (\<not>\<^sup>d y\<^sup>d)) \<or>\<^sup>d (z\<^sup>d \<and>\<^sup>d u\<^sup>d)) \<and>\<^sup>d ((v\<^sup>d \<supset>\<^sup>d w\<^sup>d) \<or>\<^sup>d ((\<not>\<^sup>d x\<^sup>d) \<and>\<^sup>d y\<^sup>d)))))"
abbreviation "QBF23_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s u. \<forall>\<^sup>s v. \<exists>\<^sup>s w. ((((x\<^sup>s \<supset>\<^sup>s (\<not>\<^sup>s y\<^sup>s)) \<or>\<^sup>s (z\<^sup>s \<and>\<^sup>s u\<^sup>s)) \<and>\<^sup>s ((v\<^sup>s \<supset>\<^sup>s w\<^sup>s) \<or>\<^sup>s ((\<not>\<^sup>s x\<^sup>s) \<and>\<^sup>s y\<^sup>s)))))"
abbreviation "QBF23_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m u. \<forall>\<^sup>m v. \<exists>\<^sup>m w. ((((x\<^sup>m \<supset>\<^sup>m (\<not>\<^sup>m y\<^sup>m)) \<or>\<^sup>m (z\<^sup>m \<and>\<^sup>m u\<^sup>m)) \<and>\<^sup>m ((v\<^sup>m \<supset>\<^sup>m w\<^sup>m) \<or>\<^sup>m ((\<not>\<^sup>m x\<^sup>m) \<and>\<^sup>m y\<^sup>m)))))"

lemma QBF23_d: "QBF23_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF23_s: "QBF23_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF23_m: "QBF23_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF24: \<exists>x \<forall>y \<exists>z \<forall>u \<exists>v \<forall>w. (((x \<and> \<not>y) \<supset> ((z \<or> u) \<and> (\<not>v \<or> w))) \<or> ((\<not>x \<or> y) \<supset> (z \<and> \<not>w)))) *)
abbreviation "QBF24_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. \<forall>\<^sup>d u. \<exists>\<^sup>d v. \<forall>\<^sup>d w. ((((x\<^sup>d \<and>\<^sup>d (\<not>\<^sup>d y\<^sup>d)) \<supset>\<^sup>d ((z\<^sup>d \<or>\<^sup>d u\<^sup>d) \<and>\<^sup>d ((\<not>\<^sup>d v\<^sup>d) \<or>\<^sup>d w\<^sup>d))) \<or>\<^sup>d (((\<not>\<^sup>d x\<^sup>d) \<or>\<^sup>d y\<^sup>d) \<supset>\<^sup>d (z\<^sup>d \<and>\<^sup>d (\<not>\<^sup>d w\<^sup>d))))))"
abbreviation "QBF24_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. \<forall>\<^sup>s u. \<exists>\<^sup>s v. \<forall>\<^sup>s w. ((((x\<^sup>s \<and>\<^sup>s (\<not>\<^sup>s y\<^sup>s)) \<supset>\<^sup>s ((z\<^sup>s \<or>\<^sup>s u\<^sup>s) \<and>\<^sup>s ((\<not>\<^sup>s v\<^sup>s) \<or>\<^sup>s w\<^sup>s))) \<or>\<^sup>s (((\<not>\<^sup>s x\<^sup>s) \<or>\<^sup>s y\<^sup>s) \<supset>\<^sup>s (z\<^sup>s \<and>\<^sup>s (\<not>\<^sup>s w\<^sup>s))))))"
abbreviation "QBF24_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. \<forall>\<^sup>m u. \<exists>\<^sup>m v. \<forall>\<^sup>m w. ((((x\<^sup>m \<and>\<^sup>m (\<not>\<^sup>m y\<^sup>m)) \<supset>\<^sup>m ((z\<^sup>m \<or>\<^sup>m u\<^sup>m) \<and>\<^sup>m ((\<not>\<^sup>m v\<^sup>m) \<or>\<^sup>m w\<^sup>m))) \<or>\<^sup>m (((\<not>\<^sup>m x\<^sup>m) \<or>\<^sup>m y\<^sup>m) \<supset>\<^sup>m (z\<^sup>m \<and>\<^sup>m (\<not>\<^sup>m w\<^sup>m))))))"

lemma QBF24_d: "QBF24_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF24_s: "QBF24_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF24_m: "QBF24_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF25: \<forall>x \<forall>y \<exists>z \<exists>u \<forall>v \<exists>w. ((((x \<or> (\<not>y)) \<supset> ((\<not>z \<or> u) \<and> (v \<supset> w))) \<and> (((\<not>x \<and> y) \<supset> ((\<not>u \<or> (\<not>v)) \<or> (z \<and> w)))) \<or> ((x \<and> (\<not>w)) \<supset> (y \<or> (\<not>z))))) *)
abbreviation "QBF25_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. \<exists>\<^sup>d u. \<forall>\<^sup>d v. \<exists>\<^sup>d w. (((((x\<^sup>d \<or>\<^sup>d ((\<not>\<^sup>d y\<^sup>d))) \<supset>\<^sup>d (((\<not>\<^sup>d z\<^sup>d) \<or>\<^sup>d u\<^sup>d) \<and>\<^sup>d (v\<^sup>d \<supset>\<^sup>d w\<^sup>d))) \<and>\<^sup>d (((((\<not>\<^sup>d x\<^sup>d) \<and>\<^sup>d y\<^sup>d)) \<supset>\<^sup>d (((\<not>\<^sup>d u\<^sup>d) \<or>\<^sup>d ((\<not>\<^sup>d v\<^sup>d))) \<or>\<^sup>d (z\<^sup>d \<and>\<^sup>d w\<^sup>d)))) \<or>\<^sup>d ((x\<^sup>d \<and>\<^sup>d ((\<not>\<^sup>d w\<^sup>d))) \<supset>\<^sup>d (y\<^sup>d \<or>\<^sup>d ((\<not>\<^sup>d z\<^sup>d))))))))"
abbreviation "QBF25_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. \<exists>\<^sup>s u. \<forall>\<^sup>s v. \<exists>\<^sup>s w. (((((x\<^sup>s \<or>\<^sup>s ((\<not>\<^sup>s y\<^sup>s))) \<supset>\<^sup>s (((\<not>\<^sup>s z\<^sup>s) \<or>\<^sup>s u\<^sup>s) \<and>\<^sup>s (v\<^sup>s \<supset>\<^sup>s w\<^sup>s))) \<and>\<^sup>s (((((\<not>\<^sup>s x\<^sup>s) \<and>\<^sup>s y\<^sup>s)) \<supset>\<^sup>s (((\<not>\<^sup>s u\<^sup>s) \<or>\<^sup>s ((\<not>\<^sup>s v\<^sup>s))) \<or>\<^sup>s (z\<^sup>s \<and>\<^sup>s w\<^sup>s)))) \<or>\<^sup>s ((x\<^sup>s \<and>\<^sup>s ((\<not>\<^sup>s w\<^sup>s))) \<supset>\<^sup>s (y\<^sup>s \<or>\<^sup>s ((\<not>\<^sup>s z\<^sup>s))))))))"
abbreviation "QBF25_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. \<exists>\<^sup>m u. \<forall>\<^sup>m v. \<exists>\<^sup>m w. (((((x\<^sup>m \<or>\<^sup>m ((\<not>\<^sup>m y\<^sup>m))) \<supset>\<^sup>m (((\<not>\<^sup>m z\<^sup>m) \<or>\<^sup>m u\<^sup>m) \<and>\<^sup>m (v\<^sup>m \<supset>\<^sup>m w\<^sup>m))) \<and>\<^sup>m (((((\<not>\<^sup>m x\<^sup>m) \<and>\<^sup>m y\<^sup>m)) \<supset>\<^sup>m (((\<not>\<^sup>m u\<^sup>m) \<or>\<^sup>m ((\<not>\<^sup>m v\<^sup>m))) \<or>\<^sup>m (z\<^sup>m \<and>\<^sup>m w\<^sup>m)))) \<or>\<^sup>m ((x\<^sup>m \<and>\<^sup>m ((\<not>\<^sup>m w\<^sup>m))) \<supset>\<^sup>m (y\<^sup>m \<or>\<^sup>m ((\<not>\<^sup>m z\<^sup>m))))))))"

lemma QBF25_d: "QBF25_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF25_s: "QBF25_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF25_m: "QBF25_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF26: \<forall>x \<exists>y \<forall>z \<exists>u \<forall>v \<exists>w. ((((x \<and> (\<not>y)) \<supset> (z \<or> u)) \<and> ((v \<or> (\<not>w)) \<supset> ((\<not>x) \<and> y))) \<or> (((\<not>z) \<and> u) \<supset> (v \<or> w))) *)
abbreviation "QBF26_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d u. \<forall>\<^sup>d v. \<exists>\<^sup>d w. ((((x\<^sup>d \<and>\<^sup>d ((\<not>\<^sup>d y\<^sup>d))) \<supset>\<^sup>d (z\<^sup>d \<or>\<^sup>d u\<^sup>d)) \<and>\<^sup>d ((v\<^sup>d \<or>\<^sup>d ((\<not>\<^sup>d w\<^sup>d))) \<supset>\<^sup>d (((\<not>\<^sup>d x\<^sup>d) \<and>\<^sup>d y\<^sup>d)))) \<or>\<^sup>d (((\<not>\<^sup>d z\<^sup>d) \<and>\<^sup>d u\<^sup>d) \<supset>\<^sup>d (v\<^sup>d \<or>\<^sup>d w\<^sup>d))))"
abbreviation "QBF26_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s u. \<forall>\<^sup>s v. \<exists>\<^sup>s w. ((((x\<^sup>s \<and>\<^sup>s ((\<not>\<^sup>s y\<^sup>s))) \<supset>\<^sup>s (z\<^sup>s \<or>\<^sup>s u\<^sup>s)) \<and>\<^sup>s ((v\<^sup>s \<or>\<^sup>s ((\<not>\<^sup>s w\<^sup>s))) \<supset>\<^sup>s (((\<not>\<^sup>s x\<^sup>s) \<and>\<^sup>s y\<^sup>s)))) \<or>\<^sup>s (((\<not>\<^sup>s z\<^sup>s) \<and>\<^sup>s u\<^sup>s) \<supset>\<^sup>s (v\<^sup>s \<or>\<^sup>s w\<^sup>s))))"
abbreviation "QBF26_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m u. \<forall>\<^sup>m v. \<exists>\<^sup>m w. ((((x\<^sup>m \<and>\<^sup>m ((\<not>\<^sup>m y\<^sup>m))) \<supset>\<^sup>m (z\<^sup>m \<or>\<^sup>m u\<^sup>m)) \<and>\<^sup>m ((v\<^sup>m \<or>\<^sup>m ((\<not>\<^sup>m w\<^sup>m))) \<supset>\<^sup>m (((\<not>\<^sup>m x\<^sup>m) \<and>\<^sup>m y\<^sup>m)))) \<or>\<^sup>m (((\<not>\<^sup>m z\<^sup>m) \<and>\<^sup>m u\<^sup>m) \<supset>\<^sup>m (v\<^sup>m \<or>\<^sup>m w\<^sup>m))))"

lemma QBF26_d: "QBF26_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF26_s: "QBF26_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF26_m: "QBF26_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops

(* QBF27: \<exists>x \<forall>y \<exists>z \<forall>u \<exists>v \<forall>w. (((x \<or> (\<not>y)) \<and> (z \<supset> u)) \<or> (((\<not>v \<or> w) \<and> (x \<supset> z)) \<supset> (((\<not>u) \<and> y) \<or> (v \<or> (\<not>w))))) *)
abbreviation "QBF27_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. \<forall>\<^sup>d u. \<exists>\<^sup>d v. \<forall>\<^sup>d w. ((((x\<^sup>d \<or>\<^sup>d ((\<not>\<^sup>d y\<^sup>d))) \<and>\<^sup>d (z\<^sup>d \<supset>\<^sup>d u\<^sup>d)) \<or>\<^sup>d (((((\<not>\<^sup>d v\<^sup>d) \<or>\<^sup>d w\<^sup>d) \<and>\<^sup>d (x\<^sup>d \<supset>\<^sup>d z\<^sup>d)) \<supset>\<^sup>d ((((\<not>\<^sup>d u\<^sup>d) \<and>\<^sup>d y\<^sup>d) \<or>\<^sup>d (v\<^sup>d \<or>\<^sup>d ((\<not>\<^sup>d w\<^sup>d))))))))))"
abbreviation "QBF27_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. \<forall>\<^sup>s u. \<exists>\<^sup>s v. \<forall>\<^sup>s w. ((((x\<^sup>s \<or>\<^sup>s ((\<not>\<^sup>s y\<^sup>s))) \<and>\<^sup>s (z\<^sup>s \<supset>\<^sup>s u\<^sup>s)) \<or>\<^sup>s (((((\<not>\<^sup>s v\<^sup>s) \<or>\<^sup>s w\<^sup>s) \<and>\<^sup>s (x\<^sup>s \<supset>\<^sup>s z\<^sup>s)) \<supset>\<^sup>s ((((\<not>\<^sup>s u\<^sup>s) \<and>\<^sup>s y\<^sup>s) \<or>\<^sup>s (v\<^sup>s \<or>\<^sup>s ((\<not>\<^sup>s w\<^sup>s))))))))))"
abbreviation "QBF27_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. \<forall>\<^sup>m u. \<exists>\<^sup>m v. \<forall>\<^sup>m w. ((((x\<^sup>m \<or>\<^sup>m ((\<not>\<^sup>m y\<^sup>m))) \<and>\<^sup>m (z\<^sup>m \<supset>\<^sup>m u\<^sup>m)) \<or>\<^sup>m (((((\<not>\<^sup>m v\<^sup>m) \<or>\<^sup>m w\<^sup>m) \<and>\<^sup>m (x\<^sup>m \<supset>\<^sup>m z\<^sup>m)) \<supset>\<^sup>m ((((\<not>\<^sup>m u\<^sup>m) \<and>\<^sup>m y\<^sup>m) \<or>\<^sup>m (v\<^sup>m \<or>\<^sup>m ((\<not>\<^sup>m w\<^sup>m))))))))))"

lemma QBF27_d: "QBF27_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF27_s: "QBF27_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF27_m: "QBF27_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF28: \<forall>x \<exists>y \<forall>z \<exists>u \<forall>v \<exists>w. ((((x \<or> y) \<supset> ((\<not>z) \<and> u)) \<and> ((v \<supset> (\<not>w)) \<or> (x \<and> (\<not>y)))) \<supset> (((\<not>x) \<or> z) \<and> (u \<or> v \<or> w))) *)
abbreviation "QBF28_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d u. \<forall>\<^sup>d v. \<exists>\<^sup>d w. (((((x\<^sup>d \<or>\<^sup>d y\<^sup>d) \<supset>\<^sup>d (((\<not>\<^sup>d z\<^sup>d) \<and>\<^sup>d u\<^sup>d)) ) \<and>\<^sup>d ((v\<^sup>d \<supset>\<^sup>d ((\<not>\<^sup>d w\<^sup>d))) \<or>\<^sup>d (x\<^sup>d \<and>\<^sup>d ((\<not>\<^sup>d y\<^sup>d))))) \<supset>\<^sup>d (((\<not>\<^sup>d x\<^sup>d) \<or>\<^sup>d z\<^sup>d) \<and>\<^sup>d (u\<^sup>d \<or>\<^sup>d v\<^sup>d \<or>\<^sup>d w\<^sup>d)))))"
abbreviation "QBF28_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s u. \<forall>\<^sup>s v. \<exists>\<^sup>s w. (((((x\<^sup>s \<or>\<^sup>s y\<^sup>s) \<supset>\<^sup>s (((\<not>\<^sup>s z\<^sup>s) \<and>\<^sup>s u\<^sup>s)) ) \<and>\<^sup>s ((v\<^sup>s \<supset>\<^sup>s ((\<not>\<^sup>s w\<^sup>s))) \<or>\<^sup>s (x\<^sup>s \<and>\<^sup>s ((\<not>\<^sup>s y\<^sup>s))))) \<supset>\<^sup>s (((\<not>\<^sup>s x\<^sup>s) \<or>\<^sup>s z\<^sup>s) \<and>\<^sup>s (u\<^sup>s \<or>\<^sup>s v\<^sup>s \<or>\<^sup>s w\<^sup>s)))))"
abbreviation "QBF28_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m u. \<forall>\<^sup>m v. \<exists>\<^sup>m w. (((((x\<^sup>m \<or>\<^sup>m y\<^sup>m) \<supset>\<^sup>m (((\<not>\<^sup>m z\<^sup>m) \<and>\<^sup>m u\<^sup>m)) ) \<and>\<^sup>m ((v\<^sup>m \<supset>\<^sup>m ((\<not>\<^sup>m w\<^sup>m))) \<or>\<^sup>m (x\<^sup>m \<and>\<^sup>m ((\<not>\<^sup>m y\<^sup>m))))) \<supset>\<^sup>m (((\<not>\<^sup>m x\<^sup>m) \<or>\<^sup>m z\<^sup>m) \<and>\<^sup>m (u\<^sup>m \<or>\<^sup>m v\<^sup>m \<or>\<^sup>m w\<^sup>m)))))"

lemma QBF28_d: "QBF28_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF28_s: "QBF28_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF28_m: "QBF28_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF29: \<exists>x \<forall>y \<exists>z \<forall>u \<exists>v \<forall>w. ((((x \<supset> ((\<not>y))) \<or> ((z \<and> (\<not>u)) \<supset> (v \<or> w))) \<and> (((((\<not>x) \<or> y) \<supset> ((\<not>z) \<or> u))) \<or> (v \<and> ((\<not>w)))))) *)
abbreviation "QBF29_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d x. \<forall>\<^sup>d y. \<exists>\<^sup>d z. \<forall>\<^sup>d u. \<exists>\<^sup>d v. \<forall>\<^sup>d w. ((((x\<^sup>d \<supset>\<^sup>d ((\<not>\<^sup>d y\<^sup>d))) \<or>\<^sup>d ((z\<^sup>d \<and>\<^sup>d ((\<not>\<^sup>d u\<^sup>d))) \<supset>\<^sup>d (v\<^sup>d \<or>\<^sup>d w\<^sup>d))) \<and>\<^sup>d (((((\<not>\<^sup>d x\<^sup>d) \<or>\<^sup>d y\<^sup>d) \<supset>\<^sup>d ((\<not>\<^sup>d z\<^sup>d) \<or>\<^sup>d u\<^sup>d))) \<or>\<^sup>d (v\<^sup>d \<and>\<^sup>d ((\<not>\<^sup>d w\<^sup>d)))))))"
abbreviation "QBF29_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s x. \<forall>\<^sup>s y. \<exists>\<^sup>s z. \<forall>\<^sup>s u. \<exists>\<^sup>s v. \<forall>\<^sup>s w. ((((x\<^sup>s \<supset>\<^sup>s ((\<not>\<^sup>s y\<^sup>s))) \<or>\<^sup>s ((z\<^sup>s \<and>\<^sup>s ((\<not>\<^sup>s u\<^sup>s))) \<supset>\<^sup>s (v\<^sup>s \<or>\<^sup>s w\<^sup>s))) \<and>\<^sup>s (((((\<not>\<^sup>s x\<^sup>s) \<or>\<^sup>s y\<^sup>s) \<supset>\<^sup>s ((\<not>\<^sup>s z\<^sup>s) \<or>\<^sup>s u\<^sup>s))) \<or>\<^sup>s (v\<^sup>s \<and>\<^sup>s ((\<not>\<^sup>s w\<^sup>s)))))))"
abbreviation "QBF29_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m x. \<forall>\<^sup>m y. \<exists>\<^sup>m z. \<forall>\<^sup>m u. \<exists>\<^sup>m v. \<forall>\<^sup>m w. ((((x\<^sup>m \<supset>\<^sup>m ((\<not>\<^sup>m y\<^sup>m))) \<or>\<^sup>m ((z\<^sup>m \<and>\<^sup>m ((\<not>\<^sup>m u\<^sup>m))) \<supset>\<^sup>m (v\<^sup>m \<or>\<^sup>m w\<^sup>m))) \<and>\<^sup>m (((((\<not>\<^sup>m x\<^sup>m) \<or>\<^sup>m y\<^sup>m) \<supset>\<^sup>m ((\<not>\<^sup>m z\<^sup>m) \<or>\<^sup>m u\<^sup>m))) \<or>\<^sup>m (v\<^sup>m \<and>\<^sup>m ((\<not>\<^sup>m w\<^sup>m)))))))"

lemma QBF29_d: "QBF29_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF29_s: "QBF29_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF29_m: "QBF29_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF30: \<forall>x \<exists>y \<forall>z \<exists>u \<forall>v \<exists>w. ((((x \<and> (\<not>y)) \<or> (z \<supset> (\<not>u))) \<and> ((v \<or> w) \<supset> (((\<not>x) \<and> y) \<or> ((\<not>z) \<and> u)))) \<supset> ((x \<or> v) \<and> (y \<or> w))) *)
abbreviation "QBF30_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d x. \<exists>\<^sup>d y. \<forall>\<^sup>d z. \<exists>\<^sup>d u. \<forall>\<^sup>d v. \<exists>\<^sup>d w. (((((x\<^sup>d \<and>\<^sup>d ((\<not>\<^sup>d y\<^sup>d))) \<or>\<^sup>d (z\<^sup>d \<supset>\<^sup>d ((\<not>\<^sup>d u\<^sup>d)))) \<and>\<^sup>d ((v\<^sup>d \<or>\<^sup>d w\<^sup>d) \<supset>\<^sup>d ((((\<not>\<^sup>d x\<^sup>d) \<and>\<^sup>d y\<^sup>d) \<or>\<^sup>d (((\<not>\<^sup>d z\<^sup>d) \<and>\<^sup>d u\<^sup>d)))))) \<supset>\<^sup>d ((x\<^sup>d \<or>\<^sup>d v\<^sup>d) \<and>\<^sup>d (y\<^sup>d \<or>\<^sup>d w\<^sup>d)))))"
abbreviation "QBF30_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s x. \<exists>\<^sup>s y. \<forall>\<^sup>s z. \<exists>\<^sup>s u. \<forall>\<^sup>s v. \<exists>\<^sup>s w. (((((x\<^sup>s \<and>\<^sup>s ((\<not>\<^sup>s y\<^sup>s))) \<or>\<^sup>s (z\<^sup>s \<supset>\<^sup>s ((\<not>\<^sup>s u\<^sup>s)))) \<and>\<^sup>s ((v\<^sup>s \<or>\<^sup>s w\<^sup>s) \<supset>\<^sup>s ((((\<not>\<^sup>s x\<^sup>s) \<and>\<^sup>s y\<^sup>s) \<or>\<^sup>s (((\<not>\<^sup>s z\<^sup>s) \<and>\<^sup>s u\<^sup>s)))))) \<supset>\<^sup>s ((x\<^sup>s \<or>\<^sup>s v\<^sup>s) \<and>\<^sup>s (y\<^sup>s \<or>\<^sup>s w\<^sup>s)))))"
abbreviation "QBF30_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m x. \<exists>\<^sup>m y. \<forall>\<^sup>m z. \<exists>\<^sup>m u. \<forall>\<^sup>m v. \<exists>\<^sup>m w. (((((x\<^sup>m \<and>\<^sup>m ((\<not>\<^sup>m y\<^sup>m))) \<or>\<^sup>m (z\<^sup>m \<supset>\<^sup>m ((\<not>\<^sup>m u\<^sup>m)))) \<and>\<^sup>m ((v\<^sup>m \<or>\<^sup>m w\<^sup>m) \<supset>\<^sup>m ((((\<not>\<^sup>m x\<^sup>m) \<and>\<^sup>m y\<^sup>m) \<or>\<^sup>m (((\<not>\<^sup>m z\<^sup>m) \<and>\<^sup>m u\<^sup>m)))))) \<supset>\<^sup>m ((x\<^sup>m \<or>\<^sup>m v\<^sup>m) \<and>\<^sup>m (y\<^sup>m \<or>\<^sup>m w\<^sup>m)))))"

lemma QBF30_d: "QBF30_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF30_s: "QBF30_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF30_m: "QBF30_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops

(* QBF31: \<exists>a \<forall>b \<exists>c \<forall>d \<exists>e \<forall>f. (((a \<and> (\<not>b)) \<supset> ((c \<or> (\<not>d)) \<and> (e \<supset> f))) \<or> (((\<not>a \<or> b) \<and> ((\<not>c) \<or> d)) \<supset> ((\<not>e \<and> f) \<or> (a \<or> (\<not>f))))) *)
abbreviation "QBF31_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d a. \<forall>\<^sup>d b. \<exists>\<^sup>d c. \<forall>\<^sup>d d. \<exists>\<^sup>d e. \<forall>\<^sup>d f. ((((a\<^sup>d \<and>\<^sup>d ((\<not>\<^sup>d b\<^sup>d))) \<supset>\<^sup>d ((c\<^sup>d \<or>\<^sup>d ((\<not>\<^sup>d d\<^sup>d))) \<and>\<^sup>d (e\<^sup>d \<supset>\<^sup>d f\<^sup>d))) \<or>\<^sup>d (((((\<not>\<^sup>d a\<^sup>d) \<or>\<^sup>d b\<^sup>d) \<and>\<^sup>d ((\<not>\<^sup>d c\<^sup>d) \<or>\<^sup>d d\<^sup>d)) \<supset>\<^sup>d (((\<not>\<^sup>d e\<^sup>d) \<and>\<^sup>d f\<^sup>d) \<or>\<^sup>d (a\<^sup>d \<or>\<^sup>d ((\<not>\<^sup>d f\<^sup>d)))))))))"
abbreviation "QBF31_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s a. \<forall>\<^sup>s b. \<exists>\<^sup>s c. \<forall>\<^sup>s d. \<exists>\<^sup>s e. \<forall>\<^sup>s f. ((((a\<^sup>s \<and>\<^sup>s ((\<not>\<^sup>s b\<^sup>s))) \<supset>\<^sup>s ((c\<^sup>s \<or>\<^sup>s ((\<not>\<^sup>s d\<^sup>s))) \<and>\<^sup>s (e\<^sup>s \<supset>\<^sup>s f\<^sup>s))) \<or>\<^sup>s (((((\<not>\<^sup>s a\<^sup>s) \<or>\<^sup>s b\<^sup>s) \<and>\<^sup>s ((\<not>\<^sup>s c\<^sup>s) \<or>\<^sup>s d\<^sup>s)) \<supset>\<^sup>s (((\<not>\<^sup>s e\<^sup>s) \<and>\<^sup>s f\<^sup>s) \<or>\<^sup>s (a\<^sup>s \<or>\<^sup>s ((\<not>\<^sup>s f\<^sup>s)))))))))"
abbreviation "QBF31_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m a. \<forall>\<^sup>m b. \<exists>\<^sup>m c. \<forall>\<^sup>m d. \<exists>\<^sup>m e. \<forall>\<^sup>m f. ((((a\<^sup>m \<and>\<^sup>m ((\<not>\<^sup>m b\<^sup>m))) \<supset>\<^sup>m ((c\<^sup>m \<or>\<^sup>m ((\<not>\<^sup>m d\<^sup>m))) \<and>\<^sup>m (e\<^sup>m \<supset>\<^sup>m f\<^sup>m))) \<or>\<^sup>m (((((\<not>\<^sup>m a\<^sup>m) \<or>\<^sup>m b\<^sup>m) \<and>\<^sup>m ((\<not>\<^sup>m c\<^sup>m) \<or>\<^sup>m d\<^sup>m)) \<supset>\<^sup>m (((\<not>\<^sup>m e\<^sup>m) \<and>\<^sup>m f\<^sup>m) \<or>\<^sup>m (a\<^sup>m \<or>\<^sup>m ((\<not>\<^sup>m f\<^sup>m)))))))))"

lemma QBF31_d: "QBF31_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF31_s: "QBF31_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF31_m: "QBF31_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF32: \<forall>a \<exists>b \<forall>c \<exists>d \<forall>e \<exists>f. (((a \<or> (\<not>b)) \<and> ((\<not>c) \<supset> (d \<or> e))) \<supset> (((\<not>a \<and> c) \<or> ((\<not>d) \<and> f)) \<and> (b \<supset> ((\<not>e) \<or> f)))) *)
abbreviation "QBF32_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d a. \<exists>\<^sup>d b. \<forall>\<^sup>d c. \<exists>\<^sup>d d. \<forall>\<^sup>d e. \<exists>\<^sup>d f. ((((a\<^sup>d \<or>\<^sup>d ((\<not>\<^sup>d b\<^sup>d))) \<and>\<^sup>d ((\<not>\<^sup>d c\<^sup>d) \<supset>\<^sup>d (d\<^sup>d \<or>\<^sup>d e\<^sup>d))) \<supset>\<^sup>d (((((\<not>\<^sup>d a\<^sup>d) \<and>\<^sup>d c\<^sup>d) \<or>\<^sup>d ((\<not>\<^sup>d d\<^sup>d) \<and>\<^sup>d f\<^sup>d)) \<and>\<^sup>d (b\<^sup>d \<supset>\<^sup>d ((\<not>\<^sup>d e\<^sup>d) \<or>\<^sup>d f\<^sup>d)))))))"
abbreviation "QBF32_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s a. \<exists>\<^sup>s b. \<forall>\<^sup>s c. \<exists>\<^sup>s d. \<forall>\<^sup>s e. \<exists>\<^sup>s f. ((((a\<^sup>s \<or>\<^sup>s ((\<not>\<^sup>s b\<^sup>s))) \<and>\<^sup>s ((\<not>\<^sup>s c\<^sup>s) \<supset>\<^sup>s (d\<^sup>s \<or>\<^sup>s e\<^sup>s))) \<supset>\<^sup>s (((((\<not>\<^sup>s a\<^sup>s) \<and>\<^sup>s c\<^sup>s) \<or>\<^sup>s ((\<not>\<^sup>s d\<^sup>s) \<and>\<^sup>s f\<^sup>s)) \<and>\<^sup>s (b\<^sup>s \<supset>\<^sup>s ((\<not>\<^sup>s e\<^sup>s) \<or>\<^sup>s f\<^sup>s)))))))"
abbreviation "QBF32_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m a. \<exists>\<^sup>m b. \<forall>\<^sup>m c. \<exists>\<^sup>m d. \<forall>\<^sup>m e. \<exists>\<^sup>m f. ((((a\<^sup>m \<or>\<^sup>m ((\<not>\<^sup>m b\<^sup>m))) \<and>\<^sup>m ((\<not>\<^sup>m c\<^sup>m) \<supset>\<^sup>m (d\<^sup>m \<or>\<^sup>m e\<^sup>m))) \<supset>\<^sup>m (((((\<not>\<^sup>m a\<^sup>m) \<and>\<^sup>m c\<^sup>m) \<or>\<^sup>m ((\<not>\<^sup>m d\<^sup>m) \<and>\<^sup>m f\<^sup>m)) \<and>\<^sup>m (b\<^sup>m \<supset>\<^sup>m ((\<not>\<^sup>m e\<^sup>m) \<or>\<^sup>m f\<^sup>m)))))))"

lemma QBF32_d: "QBF32_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF32_s: "QBF32_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF32_m: "QBF32_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF33: \<exists>a \<forall>b \<exists>c \<forall>d \<exists>e \<forall>f. (((a \<supset> ((\<not>b \<or> c))) \<and> ((\<not>d \<and> e) \<supset> (f \<or> a))) \<or> (((\<not>a \<and> b) \<or> (\<not>c \<and> d)) \<supset> ((\<not>e \<or> f) \<and> (a \<supset> b)))) *)
abbreviation "QBF33_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d a. \<forall>\<^sup>d b. \<exists>\<^sup>d c. \<forall>\<^sup>d d. \<exists>\<^sup>d e. \<forall>\<^sup>d f. ((((a\<^sup>d \<supset>\<^sup>d (((\<not>\<^sup>d b\<^sup>d) \<or>\<^sup>d c\<^sup>d))) \<and>\<^sup>d (((\<not>\<^sup>d d\<^sup>d) \<and>\<^sup>d e\<^sup>d) \<supset>\<^sup>d (f\<^sup>d \<or>\<^sup>d a\<^sup>d))) \<or>\<^sup>d (((((\<not>\<^sup>d a\<^sup>d) \<and>\<^sup>d b\<^sup>d) \<or>\<^sup>d ((\<not>\<^sup>d c\<^sup>d) \<and>\<^sup>d d\<^sup>d)) \<supset>\<^sup>d (((\<not>\<^sup>d e\<^sup>d) \<or>\<^sup>d f\<^sup>d) \<and>\<^sup>d (a\<^sup>d \<supset>\<^sup>d b\<^sup>d)))))))"
abbreviation "QBF33_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s a. \<forall>\<^sup>s b. \<exists>\<^sup>s c. \<forall>\<^sup>s d. \<exists>\<^sup>s e. \<forall>\<^sup>s f. ((((a\<^sup>s \<supset>\<^sup>s (((\<not>\<^sup>s b\<^sup>s) \<or>\<^sup>s c\<^sup>s))) \<and>\<^sup>s (((\<not>\<^sup>s d\<^sup>s) \<and>\<^sup>s e\<^sup>s) \<supset>\<^sup>s (f\<^sup>s \<or>\<^sup>s a\<^sup>s))) \<or>\<^sup>s (((((\<not>\<^sup>s a\<^sup>s) \<and>\<^sup>s b\<^sup>s) \<or>\<^sup>s ((\<not>\<^sup>s c\<^sup>s) \<and>\<^sup>s d\<^sup>s)) \<supset>\<^sup>s (((\<not>\<^sup>s e\<^sup>s) \<or>\<^sup>s f\<^sup>s) \<and>\<^sup>s (a\<^sup>s \<supset>\<^sup>s b\<^sup>s)))))))"
abbreviation "QBF33_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m a. \<forall>\<^sup>m b. \<exists>\<^sup>m c. \<forall>\<^sup>m d. \<exists>\<^sup>m e. \<forall>\<^sup>m f. ((((a\<^sup>m \<supset>\<^sup>m (((\<not>\<^sup>m b\<^sup>m) \<or>\<^sup>m c\<^sup>m))) \<and>\<^sup>m (((\<not>\<^sup>m d\<^sup>m) \<and>\<^sup>m e\<^sup>m) \<supset>\<^sup>m (f\<^sup>m \<or>\<^sup>m a\<^sup>m))) \<or>\<^sup>m (((((\<not>\<^sup>m a\<^sup>m) \<and>\<^sup>m b\<^sup>m) \<or>\<^sup>m ((\<not>\<^sup>m c\<^sup>m) \<and>\<^sup>m d\<^sup>m)) \<supset>\<^sup>m (((\<not>\<^sup>m e\<^sup>m) \<or>\<^sup>m f\<^sup>m) \<and>\<^sup>m (a\<^sup>m \<supset>\<^sup>m b\<^sup>m)))))))"

lemma QBF33_d: "QBF33_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF33_s: "QBF33_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF33_m: "QBF33_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops

(* Parsing starts to fail here

(* QBF34: \<forall>a \<exists>b \<forall>c \<exists>d \<forall>e \<exists>f. ((((a \<or> (\<not>b)) \<supset> ((\<not>c \<and> d) \<or> e)) \<and> ((f \<supset> (a \<and> b)) \<or> ((\<not>d) \<supset> (\<not>e \<or> c)))) \<supset> ((\<not>a \<or> f) \<and> (b \<or> \<not>c \<or> d))) *)
abbreviation "QBF34_d \<equiv> \<Turnstile>\<^sup>d (\<forall>\<^sup>d a. \<exists>\<^sup>d b. \<forall>\<^sup>d c. \<exists>\<^sup>d d. \<forall>\<^sup>d e. \<exists>\<^sup>d f. (((((a\<^sup>d \<or>\<^sup>d ((\<not>\<^sup>d b\<^sup>d))) \<supset>\<^sup>d (((\<not>\<^sup>d c\<^sup>d) \<and>\<^sup>d d\<^sup>d) \<or>\<^sup>d e\<^sup>d)) \<and>\<^sup>d ((f\<^sup>d \<supset>\<^sup>d (a\<^sup>d \<and>\<^sup>d b\<^sup>d)) \<or>\<^sup>d (((\<not>\<^sup>d d\<^sup>d) \<supset>\<^sup>d ((\<not>\<^sup>d e\<^sup>d) \<or>\<^sup>d c\<^sup>d))))) \<supset>\<^sup>d ((((\<not>\<^sup>d a\<^sup>d) \<or>\<^sup>d f\<^sup>d) \<and>\<^sup>d (b\<^sup>d \<or>\<^sup>d (\<not>\<^sup>d c\<^sup>d) \<or>\<^sup>d d\<^sup>d))))))"
abbreviation "QBF34_s \<equiv> \<Turnstile>\<^sup>s (\<forall>\<^sup>s a. \<exists>\<^sup>s b. \<forall>\<^sup>s c. \<exists>\<^sup>s d. \<forall>\<^sup>s e. \<exists>\<^sup>s f. (((((a\<^sup>s \<or>\<^sup>s ((\<not>\<^sup>s b\<^sup>s))) \<supset>\<^sup>s (((\<not>\<^sup>s c\<^sup>s) \<and>\<^sup>s d\<^sup>s) \<or>\<^sup>s e\<^sup>s)) \<and>\<^sup>s ((f\<^sup>s \<supset>\<^sup>s (a\<^sup>s \<and>\<^sup>s b\<^sup>s)) \<or>\<^sup>s (((\<not>\<^sup>s d\<^sup>s) \<supset>\<^sup>s ((\<not>\<^sup>s e\<^sup>s) \<or>\<^sup>s c\<^sup>s))))) \<supset>\<^sup>s ((((\<not>\<^sup>s a\<^sup>s) \<or>\<^sup>s f\<^sup>s) \<and>\<^sup>s (b\<^sup>s \<or>\<^sup>s (\<not>\<^sup>s c\<^sup>s) \<or>\<^sup>s d\<^sup>s))))))"
abbreviation "QBF34_m \<equiv> \<Turnstile>\<^sup>m (\<forall>\<^sup>m a. \<exists>\<^sup>m b. \<forall>\<^sup>m c. \<exists>\<^sup>m d. \<forall>\<^sup>m e. \<exists>\<^sup>m f. (((((a\<^sup>m \<or>\<^sup>m ((\<not>\<^sup>m b\<^sup>m))) \<supset>\<^sup>m (((\<not>\<^sup>m c\<^sup>m) \<and>\<^sup>m d\<^sup>m) \<or>\<^sup>m e\<^sup>m)) \<and>\<^sup>m ((f\<^sup>m \<supset>\<^sup>m (a\<^sup>m \<and>\<^sup>m b\<^sup>m)) \<or>\<^sup>m (((\<not>\<^sup>m d\<^sup>m) \<supset>\<^sup>m ((\<not>\<^sup>m e\<^sup>m) \<or>\<^sup>m c\<^sup>m))))) \<supset>\<^sup>m ((((\<not>\<^sup>m a\<^sup>m) \<or>\<^sup>m f\<^sup>m) \<and>\<^sup>m (b\<^sup>m \<or>\<^sup>m (\<not>\<^sup>m c\<^sup>m) \<or>\<^sup>m d\<^sup>m))))))"

lemma QBF34_d: "QBF34_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF34_s: "QBF34_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF34_m: "QBF34_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops


(* QBF35: \<exists>a \<forall>b \<exists>c \<forall>d \<exists>e \<forall>f. ((((a \<and> \<not>b) \<supset> (c \<or> \<not>d)) \<or> (((\<not>a \<and> b) \<supset> ((\<not>c) \<and> d)) \<and> (e \<supset> (f \<or> a)))) \<and> (((\<not>e \<or> f) \<and> (\<not>a \<supset> b)) \<supset> ((c \<or> d) \<and> (\<not>b \<or> \<not>f)))) *)
abbreviation "QBF35_d \<equiv> \<Turnstile>\<^sup>d (\<exists>\<^sup>d a. \<forall>\<^sup>d b. \<exists>\<^sup>d c. \<forall>\<^sup>d d. \<exists>\<^sup>d e. \<forall>\<^sup>d f. (((((a\<^sup>d \<and>\<^sup>d (\<not>\<^sup>d b\<^sup>d)) \<supset>\<^sup>d (c\<^sup>d \<or>\<^sup>d (\<not>\<^sup>d d\<^sup>d))) \<or>\<^sup>d (((((\<not>\<^sup>d a\<^sup>d) \<and>\<^sup>d b\<^sup>d) \<supset>\<^sup>d ((\<not>\<^sup>d c\<^sup>d) \<and>\<^sup>d d\<^sup>d)) \<and>\<^sup>d (e\<^sup>d \<supset>\<^sup>d (f\<^sup>d \<or>\<^sup>d a\<^sup>d))))) \<and>\<^sup>d (((((\<not>\<^sup>d e\<^sup>d) \<or>\<^sup>d f\<^sup>d) \<and>\<^sup>d ((\<not>\<^sup>d a\<^sup>d) \<supset>\<^sup>d b\<^sup>d)) \<supset>\<^sup>d ((c\<^sup>d \<or>\<^sup>d d\<^sup>d) \<and>\<^sup>d ((\<not>\<^sup>d b\<^sup>d) \<or>\<^sup>d (\<not>\<^sup>d f\<^sup>d))))))))"
abbreviation "QBF35_s \<equiv> \<Turnstile>\<^sup>s (\<exists>\<^sup>s a. \<forall>\<^sup>s b. \<exists>\<^sup>s c. \<forall>\<^sup>s d. \<exists>\<^sup>s e. \<forall>\<^sup>s f. (((((a\<^sup>s \<and>\<^sup>s (\<not>\<^sup>s b\<^sup>s)) \<supset>\<^sup>s (c\<^sup>s \<or>\<^sup>s (\<not>\<^sup>s d\<^sup>s))) \<or>\<^sup>s (((((\<not>\<^sup>s a\<^sup>s) \<and>\<^sup>s b\<^sup>s) \<supset>\<^sup>s ((\<not>\<^sup>s c\<^sup>s) \<and>\<^sup>s d\<^sup>s)) \<and>\<^sup>s (e\<^sup>s \<supset>\<^sup>s (f\<^sup>s \<or>\<^sup>s a\<^sup>s))))) \<and>\<^sup>s (((((\<not>\<^sup>s e\<^sup>s) \<or>\<^sup>s f\<^sup>s) \<and>\<^sup>s ((\<not>\<^sup>s a\<^sup>s) \<supset>\<^sup>s b\<^sup>s)) \<supset>\<^sup>s ((c\<^sup>s \<or>\<^sup>s d\<^sup>s) \<and>\<^sup>s ((\<not>\<^sup>s b\<^sup>s) \<or>\<^sup>s (\<not>\<^sup>s f\<^sup>s))))))))"
abbreviation "QBF35_m \<equiv> \<Turnstile>\<^sup>m (\<exists>\<^sup>m a. \<forall>\<^sup>m b. \<exists>\<^sup>m c. \<forall>\<^sup>m d. \<exists>\<^sup>m e. \<forall>\<^sup>m f. (((((a\<^sup>m \<and>\<^sup>m (\<not>\<^sup>m b\<^sup>m)) \<supset>\<^sup>m (c\<^sup>m \<or>\<^sup>m (\<not>\<^sup>m d\<^sup>m))) \<or>\<^sup>m (((((\<not>\<^sup>m a\<^sup>m) \<and>\<^sup>m b\<^sup>m) \<supset>\<^sup>m ((\<not>\<^sup>m c\<^sup>m) \<and>\<^sup>m d\<^sup>m)) \<and>\<^sup>m (e\<^sup>m \<supset>\<^sup>m (f\<^sup>m \<or>\<^sup>m a\<^sup>m))))) \<and>\<^sup>m (((((\<not>\<^sup>m e\<^sup>m) \<or>\<^sup>m f\<^sup>m) \<and>\<^sup>m ((\<not>\<^sup>m a\<^sup>m) \<supset>\<^sup>m b\<^sup>m)) \<supset>\<^sup>m ((c\<^sup>m \<or>\<^sup>m d\<^sup>m) \<and>\<^sup>m ((\<not>\<^sup>m b\<^sup>m) \<or>\<^sup>m (\<not>\<^sup>m f\<^sup>m))))))))"

lemma QBF35_d: "QBF35_d" unfolding DefD nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF35_s: "QBF35_s" unfolding DefS nitpick sledgehammer apply simp nitpick sledgehammer oops
lemma QBF35_m: "QBF35_m" unfolding DefM nitpick sledgehammer apply simp nitpick sledgehammer oops

*)

end





