theory QBFinHOL_shallow imports QBFinHOL_preliminaries                               
begin
  type_synonym \<sigma> = "\<I>\<Rightarrow>bool"
\<comment>\<open>Maximal shallow embedding (of QBF in HOL)\<close>
  definition VarS :: "\<S>\<Rightarrow>\<sigma>"         ("_\<^sup>s")                    where                                         "a\<^sup>s  \<equiv>  \<lambda>I. I a"
  definition NotS :: "\<sigma>\<Rightarrow>\<sigma>"         ("\<not>\<^sup>s _")                 where                                     "\<not>\<^sup>s \<phi>  \<equiv>  \<lambda>I. \<not> (\<phi> I)"
  definition OrS   :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"   (infixr "\<or>\<^sup>s" 930)  where                                  "\<phi> \<or>\<^sup>s \<psi>  \<equiv>  \<lambda>I. \<phi> I \<or> \<psi> I"
  definition AllS   :: "\<S>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"   ("\<forall>\<^sup>s_. _")               where                                  "\<forall>\<^sup>sa. \<phi>  \<equiv>  \<lambda>I. \<forall>v. \<phi> (I\<langle>a \<leftarrow> v\<rangle>)"
\<comment>\<open>Further logical connectives as derived definitions\<close>
  definition ImpS :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"   (infixr "\<supset>\<^sup>s " 92)   where                                 "\<phi> \<supset>\<^sup>s \<psi>  \<equiv>  (\<not>\<^sup>s\<phi>) \<or>\<^sup>s \<psi>"
  definition AndS :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"   (infixr "\<and>\<^sup>s" 95)    where                                 "\<phi> \<and>\<^sup>s \<psi>  \<equiv>  \<not>\<^sup>s(\<phi> \<supset>\<^sup>s \<not>\<^sup>s\<psi>)"
  definition ExS   :: "\<S>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"   ("\<exists>\<^sup>s_. _")               where                                  "\<exists>\<^sup>sa. \<phi>  \<equiv>  \<not>\<^sup>s(\<forall>\<^sup>sa. \<not>\<^sup>s\<phi>) "
  consts q :: \<S>
  definition TopS :: "\<sigma>"              ("\<top>\<^sup>s")                    where                                       "\<top>\<^sup>s  \<equiv>  q\<^sup>s \<supset>\<^sup>s q\<^sup>s"
  definition BotS :: "\<sigma>"              ("\<bottom>\<^sup>s")                    where                                        "\<bottom>\<^sup>s  \<equiv>  \<not>\<^sup>s \<top>\<^sup>s"
\<comment>\<open>Relative truth\<close>
  definition RelTruthS :: "\<I>\<Rightarrow>\<sigma>\<Rightarrow>bool" (infix "\<Turnstile>\<^sup>s" 10) where                           "I \<Turnstile>\<^sup>s \<phi>  \<equiv>  \<phi> I"
\<comment>\<open>Validity\<close>
  definition ValS :: "\<sigma>\<Rightarrow>bool"    ("\<Turnstile>\<^sup>s _" 9)               where                                  "\<Turnstile>\<^sup>s \<phi>  \<equiv>  \<forall>I. I \<Turnstile>\<^sup>s \<phi>"
\<comment>\<open>Collection of definitions in a bag called DefS\<close>
  named_theorems DefS declare VarS_def[DefS] NotS_def[DefS] OrS_def[DefS] AllS_def[DefS] 
     ImpS_def[DefS] AndS_def[DefS] ExS_def[DefS] TopS_def[DefS] BotS_def[DefS] RelTruthS_def[DefS]  ValS_def[DefS]  
end 

