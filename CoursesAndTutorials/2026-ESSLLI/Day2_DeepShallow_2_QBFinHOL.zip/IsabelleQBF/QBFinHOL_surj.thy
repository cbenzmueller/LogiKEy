theory QBFinHOL_surj imports QBFinHOL_deep_subst_lemma
begin
  theorem SurjectiveDeep:          "(\<forall>I. I \<Turnstile>\<^sup>d \<phi>) \<longleftrightarrow> (\<forall>I. surj I \<longrightarrow> I \<Turnstile>\<^sup>d \<phi>)"
    proof(safe) fix I 
      obtain a b where                   "a \<noteq> b \<and> a not_free_in \<phi> \<and> b not_free_in \<phi>"        by (metis L10 L8 is_free.simps(1))
      moreover define J where     "J \<equiv> \<lambda>x. if x free_in \<phi> then I x else x = a"
      ultimately have                     "surj J"                                                                 by (smt surj_def)
      moreover assume                 "\<forall> I. surj I \<longrightarrow> I \<Turnstile>\<^sup>d \<phi>"
      ultimately have                     "J \<Turnstile>\<^sup>d \<phi>"                                                               by blast
      moreover have                      "\<forall> x. x free_in \<phi> \<longrightarrow> J x = I x"                             unfolding J_def by force
      ultimately show                    "I \<Turnstile>\<^sup>d \<phi>"                             by (induct \<phi> arbitrary: I J; simp add: DefD; smt IntMod_def)
    qed(auto)
end

