theory QBFinHOL_shallow_minimal imports QBFinHOL_preliminaries               
begin
  type_synonym \<sigma>=bool
\<comment>\<open>Surjective assignment functions are assumed at the meta-level\<close>
  consts  IF::\<I>  axiomatization where IF_surj: "surj IF"
\<comment>\<open>Mimimal shallow embedding (of QBF in HOL)\<close>
  definition VarM :: "\<S>\<Rightarrow>\<sigma>"         ("_\<^sup>m")                      where                                          "v\<^sup>m  \<equiv>  IF v"
  definition NotM :: "\<sigma>\<Rightarrow>\<sigma>"         ("\<not>\<^sup>m _")                   where                                      "\<not>\<^sup>m \<phi>  \<equiv>  \<not> \<phi>"
  definition OrM   :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"    (infixr "\<or>\<^sup>m" 930)   where                                   "\<phi> \<or>\<^sup>m \<psi>  \<equiv>  \<phi> \<or> \<psi>"
  definition AllM   :: "(\<S>\<Rightarrow>\<sigma>)\<Rightarrow>\<sigma>" (binder "\<forall>\<^sup>m" 910)  where                                "\<forall>\<^sup>mx. \<Phi> x  \<equiv>  \<forall>x. \<Phi> x"
\<comment>\<open>Further logical connectives as derived definitions\<close>
  definition ImpM  :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"   (infixr "\<supset>\<^sup>m " 92)    where                                  "\<phi> \<supset>\<^sup>m \<psi>  \<equiv>  (\<not>\<^sup>m\<phi>) \<or>\<^sup>m \<psi>"
  definition AndM  :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"   (infixr "\<and>\<^sup>m" 95)     where                                   "\<phi> \<and>\<^sup>m \<psi>  \<equiv>  \<not>\<^sup>m(\<phi> \<supset>\<^sup>m \<not>\<^sup>m\<psi>)"
  definition ExM    :: "(\<S>\<Rightarrow>\<sigma>)\<Rightarrow>\<sigma>" (binder "\<exists>\<^sup>m" 910) where                                 "\<exists>\<^sup>mx. \<Phi> x  \<equiv>  \<not>\<^sup>m\<forall>\<^sup>mx. \<not>\<^sup>m(\<Phi> x)"
  consts p::\<S> 
  definition TopM  :: "\<sigma>"              ("\<top>\<^sup>m")                    where                                        "\<top>\<^sup>m   \<equiv>  p\<^sup>m \<supset>\<^sup>m p\<^sup>m"
  definition BotM  :: "\<sigma>"              ("\<bottom>\<^sup>m")                     where                                        "\<bottom>\<^sup>m   \<equiv>  \<not>\<^sup>m \<top>\<^sup>m"
\<comment>\<open>Validity\<close>
  definition ValM  :: "\<sigma>\<Rightarrow>bool"    ("\<Turnstile>\<^sup>m _" 9)               where                                      "\<Turnstile>\<^sup>m \<phi>  \<equiv>  \<phi>"
\<comment>\<open>Collection of definitions in a bag called DefS\<close>
  named_theorems DefM declare VarM_def[DefM] NotM_def[DefM] OrM_def[DefM] AllM_def[DefM] 
      ImpM_def[DefM] AndM_def[DefM] ExM_def[DefM] TopM_def[DefM] BotM_def[DefM] ValM_def[DefM]  
end

