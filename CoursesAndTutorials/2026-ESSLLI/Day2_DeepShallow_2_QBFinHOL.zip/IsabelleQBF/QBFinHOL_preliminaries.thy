theory QBFinHOL_preliminaries imports Main                                                     
begin
\<comment>\<open>Type declarations common for both the deep and shallow embedding\<close>
  type_synonym \<S> = nat \<comment>\<open>Signature of variable symbols: we simply use the natural numbers for this\<close>
  type_synonym \<I> = "\<S>\<Rightarrow>bool" \<comment>\<open>Assignment functions\<close>
\<comment>\<open>Modification of assignment functions\<close>
  definition IntMod :: "\<I>\<Rightarrow>\<S>\<Rightarrow>bool\<Rightarrow>\<I>" ("_\<langle>_ \<leftarrow> _\<rangle>") where          "I\<langle>x\<leftarrow>y\<rangle> \<equiv> \<lambda>z. if z = x then y else I z"
\<comment>\<open>Some lemmata\<close>
  lemma L1 [simp]:           "(I\<langle>y \<leftarrow> s\<rangle>) x = I x" if "x \<noteq> y"                                                 using that IntMod_def by auto
  lemma L2:                      "a \<noteq> c \<Longrightarrow> (I\<langle>a \<leftarrow> b\<rangle>\<langle>c \<leftarrow> d\<rangle>) = (I\<langle>c \<leftarrow> d\<rangle>\<langle>a \<leftarrow> b\<rangle>)"                using IntMod_def by auto
  lemma L3 [simp]:           "(I\<langle>a \<leftarrow> b\<rangle>) a = b"                                                                   using IntMod_def by auto
  lemma L4 [simp]:           "I\<langle>a \<leftarrow> b\<rangle>\<langle>a \<leftarrow> c\<rangle> = (I\<langle>a \<leftarrow> c\<rangle>)"                                               using IntMod_def by auto
\<comment>\<open>Further settings\<close> declare[[syntax_ambiguity_warning=false]] nitpick_params[user_axioms,expect=genuine]
end


