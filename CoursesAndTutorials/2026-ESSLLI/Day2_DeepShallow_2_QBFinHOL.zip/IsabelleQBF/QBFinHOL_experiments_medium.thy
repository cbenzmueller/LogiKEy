theory QBFinHOL_experiments_medium imports QBFinHOL_deep  QBFinHOL_shallow  QBFinHOL_shallow_minimal                                   
begin
  abbreviation "EquivD \<phi> \<psi> \<equiv>  (AndD (ImpD \<phi> \<psi>) (ImpD \<psi> \<phi>))"
  lemma QBFmediumD: "
\<Turnstile>\<^sup>d (AllD 30 (ExD 29 (AllD 28 (ExD 27 (AllD 26 (ExD 25 (AllD 24 (ExD 23 (AllD 22 (ExD 21 (AllD 20 (ExD 19 (AllD 18 (ExD 17 
(AllD 16 (ExD 15 (AllD 14 (ExD 13 (AllD 12 (ExD 11 (AllD 10 (ExD 9 (AllD 8 (ExD 7 (AllD 6 (ExD 5 (AllD 4 (ExD 3 (AllD 2 (ExD 1 
(AndD (EquivD (AndD (AndD (EquivD (OrD (EquivD (VarD 24) (VarD 21)) (EquivD (VarD 1) (VarD 3))) (OrD (OrD (VarD 21) 
(NotD (VarD 16))) (OrD (VarD 16) (VarD 20)))) (ImpD (EquivD (EquivD (VarD 17) (NotD (VarD 15))) (EquivD (VarD 24) 
(NotD (VarD 17)))) (ImpD (AndD (VarD 20) (VarD 19)) (EquivD (VarD 14) (VarD 1))))) (OrD (ImpD (AndD (ImpD (NotD (VarD 15)) 
(VarD 2)) (EquivD (VarD 24) (VarD 22))) (OrD (AndD (VarD 8) (VarD 7)) (EquivD (VarD 14) (NotD (VarD 14))))) (ImpD (EquivD 
(ImpD (NotD (VarD 28)) (VarD 25)) (EquivD (VarD 19) (VarD 10))) (AndD (AndD (VarD 16) (NotD (VarD 25))) (EquivD (VarD 21) 
(NotD (VarD 13))))))) (AndD (AndD (EquivD (EquivD (OrD (VarD 10) (VarD 23)) (OrD (NotD (VarD 3)) (VarD 22))) (EquivD (OrD
(VarD 12) (NotD (VarD 21))) (AndD (VarD 4) (VarD 2)))) (OrD (OrD (ImpD (VarD 23) (VarD 27)) (EquivD (VarD 26) (VarD 9))) 
(AndD (ImpD (VarD 18) (NotD (VarD 8))) (AndD (VarD 19) (VarD 23))))) (EquivD (OrD (ImpD (ImpD (VarD 28) (VarD 2)) (EquivD 
(NotD (VarD 6)) (VarD 6))) (ImpD (EquivD (VarD 26) (VarD 22)) (ImpD (NotD (VarD 25)) (VarD 30)))) (EquivD (EquivD (EquivD 
(VarD 28) (VarD 12)) (OrD (VarD 17) (NotD (VarD 29)))) (EquivD (AndD (NotD (VarD 28)) (NotD (VarD 8))) (OrD (VarD 17) 
(VarD 10))))))) (EquivD (OrD (ImpD (EquivD (OrD (EquivD (VarD 5) (VarD 6)) (ImpD (VarD 21) (VarD 16))) (EquivD (OrD 
(VarD 25) (VarD 12)) (ImpD (NotD (VarD 13)) (VarD 15)))) (ImpD (EquivD (AndD (VarD 25) (NotD (VarD 4))) (EquivD (NotD 
(VarD 26)) (VarD 26))) (ImpD (AndD (VarD 13) (NotD (VarD 11))) (ImpD (NotD (VarD 13)) (NotD (VarD 25)))))) (EquivD (AndD 
(EquivD (AndD (VarD 12) (VarD 18)) (ImpD (VarD 4) (VarD 14))) (ImpD (OrD (VarD 12) (NotD (VarD 14))) (ImpD (VarD 3) (VarD
20)))) (AndD (ImpD (EquivD (VarD 27) (VarD 7)) (EquivD (NotD (VarD 2)) (VarD 1))) (AndD (OrD (NotD (VarD 10)) (VarD 14)) 
(EquivD (NotD (VarD 11)) (NotD (VarD 9))))))) (ImpD (EquivD (AndD (EquivD (OrD (VarD 5) (VarD 7)) (EquivD (VarD 14) 
(VarD 10))) (OrD (EquivD (NotD (VarD 15)) (VarD 9)) (EquivD (VarD 11) (VarD 3)))) (EquivD (AndD (AndD (VarD 27) (NotD 
(VarD 30))) (ImpD (NotD (VarD 2)) (NotD (VarD 30)))) (ImpD (EquivD (NotD (VarD 4)) (VarD 13)) (OrD (VarD 24) (VarD 7))))) 
(EquivD (AndD (EquivD (OrD (VarD 2) (VarD 19)) (EquivD (VarD 24) (VarD 3))) (ImpD (OrD (VarD 3) (VarD 8)) (ImpD (VarD 6) 
(VarD 28)))) (AndD (AndD (OrD (NotD (VarD 30)) (VarD 8)) (EquivD (VarD 27) (VarD 27))) (ImpD (EquivD (VarD 14) (VarD 18)) 
(OrD (VarD 22) (NotD (VarD 26)))))))))))))))))))))))))))))))))))))))"
    unfolding DefD apply simp sledgehammer[z3,timeout=4]() oops \<comment>\<open>Proof by z3 in 4s\<close>
end


(*
abbreviation "QBFmediumD \<equiv> \<Turnstile>\<^sup>d
(AllD 30 (ExD 29 (AllD 28 (ExD 27 (AllD 26 (ExD 25 (AllD 24 (ExD 23 (AllD 22 (ExD 21 (AllD 20 (ExD 19 (AllD
18 (ExD 17 (AllD 16 (ExD 15 (AllD 14 (ExD 13 (AllD 12 (ExD 11 (AllD 10 (ExD 9 (AllD 8 (ExD 7 (AllD 6 (ExD 5
(AllD 4 (ExD 3 (AllD 2 (ExD 1 (OrD (EquivD (EquivD (EquivD (AndD (EquivD (EquivD (ImpD (VarD 13) (NotD (VarD
28))) (ImpD (VarD 13) (VarD 14))) (ImpD (OrD (VarD 23) (VarD 28)) (AndD (VarD 15) (VarD 21)))) (EquivD (OrD
(AndD (VarD 17) (VarD 30)) (OrD (VarD 21) (NotD (VarD 13)))) (EquivD (ImpD (NotD (VarD 20)) (NotD (VarD 12)))
(ImpD (VarD 15) (VarD 1))))) (AndD (AndD (OrD (ImpD (NotD (VarD 14)) (VarD 11)) (AndD (VarD 28) (VarD 10)))
(ImpD (AndD (VarD 27) (VarD 11)) (AndD (NotD (VarD 27)) (NotD (VarD 8))))) (OrD (OrD (OrD (VarD 5) (VarD 20))
(AndD (VarD 23) (NotD (VarD 22)))) (AndD (EquivD (VarD 16) (VarD 28)) (OrD (VarD 8) (NotD (VarD 6)))))))
(AndD (ImpD (ImpD (AndD (OrD (VarD 11) (VarD 3)) (ImpD (VarD 8) (NotD (VarD 12)))) (OrD (OrD (NotD (VarD 24))
(VarD 11)) (EquivD (VarD 23) (NotD (VarD 16))))) (ImpD (EquivD (ImpD (VarD 2) (NotD (VarD 17))) (AndD (NotD
(VarD 15)) (NotD (VarD 7)))) (OrD (AndD (VarD 6) (VarD 1)) (OrD (VarD 15) (NotD (VarD 16)))))) (ImpD (ImpD
(EquivD (OrD (VarD 27) (VarD 9)) (OrD (VarD 19) (VarD 22))) (EquivD (OrD (NotD (VarD 8)) (VarD 28)) (EquivD
(NotD (VarD 1)) (VarD 30)))) (EquivD (AndD (OrD (NotD (VarD 24)) (NotD (VarD 28))) (EquivD (VarD 12) (NotD
(VarD 22)))) (ImpD (OrD (NotD (VarD 19)) (VarD 1)) (OrD (VarD 4) (NotD (VarD 21)))))))) (EquivD (EquivD
(EquivD (AndD (OrD (EquivD (VarD 4) (NotD (VarD 16))) (ImpD (VarD 25) (VarD 20))) (EquivD (ImpD (VarD 2)
(NotD (VarD 4))) (ImpD (VarD 4) (VarD 8)))) (ImpD (ImpD (OrD (VarD 2) (NotD (VarD 12))) (AndD (VarD 1) (VarD
4))) (AndD (ImpD (VarD 6) (VarD 25)) (ImpD (VarD 10) (VarD 20))))) (EquivD (OrD (AndD (EquivD (NotD (VarD
18)) (VarD 26)) (AndD (VarD 3) (VarD 24))) (OrD (ImpD (NotD (VarD 29)) (VarD 16)) (AndD (VarD 30) (VarD
26)))) (EquivD (OrD (ImpD (NotD (VarD 2)) (VarD 17)) (ImpD (NotD (VarD 19)) (VarD 17))) (AndD (EquivD (VarD
8) (VarD 28)) (EquivD (VarD 2) (VarD 27)))))) (ImpD (ImpD (AndD (AndD (AndD (NotD (VarD 3)) (VarD 24)) (OrD
(VarD 13) (NotD (VarD 18)))) (ImpD (OrD (NotD (VarD 27)) (VarD 6)) (AndD (VarD 27) (NotD (VarD 17))))) (OrD
(EquivD (AndD (NotD (VarD 5)) (VarD 1)) (OrD (NotD (VarD 15)) (VarD 29))) (AndD (EquivD (VarD 24) (VarD 25))
(AndD (VarD 26) (VarD 9))))) (OrD (EquivD (ImpD (ImpD (NotD (VarD 27)) (VarD 19)) (ImpD (VarD 19) (VarD 21)))
(ImpD (EquivD (NotD (VarD 21)) (VarD 21)) (ImpD (VarD 14) (VarD 8)))) (AndD (AndD (OrD (NotD (VarD 2)) (VarD
17)) (ImpD (VarD 13) (NotD (VarD 26)))) (OrD (OrD (VarD 22) (NotD (VarD 5))) (AndD (VarD 15) (VarD 29))))))))
(ImpD (OrD (EquivD (EquivD (OrD (OrD (ImpD (NotD (VarD 10)) (VarD 5)) (AndD (NotD (VarD 22)) (VarD 13)))
(AndD (OrD (NotD (VarD 9)) (VarD 10)) (EquivD (NotD (VarD 23)) (NotD (VarD 28))))) (OrD (OrD (EquivD (NotD
(VarD 6)) (VarD 14)) (AndD (NotD (VarD 14)) (VarD 8))) (ImpD (ImpD (VarD 25) (NotD (VarD 1))) (EquivD (NotD
(VarD 5)) (VarD 30))))) (AndD (EquivD (OrD (ImpD (NotD (VarD 25)) (VarD 11)) (AndD (VarD 11) (VarD 1))) (ImpD
(AndD (VarD 20) (VarD 9)) (AndD (NotD (VarD 11)) (VarD 3)))) (ImpD (ImpD (OrD (VarD 6) (VarD 10)) (AndD (NotD
(VarD 27)) (VarD 26))) (ImpD (AndD (VarD 4) (VarD 11)) (ImpD (VarD 18) (VarD 12)))))) (EquivD (AndD (AndD
(OrD (EquivD (VarD 15) (VarD 10)) (AndD (VarD 27) (VarD 9))) (OrD (AndD (VarD 26) (VarD 16)) (OrD (VarD 3)
(NotD (VarD 11))))) (AndD (AndD (ImpD (VarD 7) (NotD (VarD 15))) (OrD (NotD (VarD 23)) (NotD (VarD 25))))
(AndD (EquivD (VarD 24) (VarD 1)) (AndD (VarD 25) (VarD 14))))) (OrD (OrD (EquivD (OrD (VarD 30) (VarD 15))
(OrD (VarD 16) (VarD 24))) (AndD (ImpD (VarD 1) (NotD (VarD 26))) (AndD (VarD 16) (VarD 14)))) (EquivD
(EquivD (OrD (VarD 26) (VarD 7)) (ImpD (VarD 5) (VarD 6))) (AndD (AndD (VarD 5) (NotD (VarD 7))) (ImpD (VarD
24) (VarD 7))))))) (EquivD (EquivD (EquivD (OrD (EquivD (OrD (VarD 15) (VarD 9)) (OrD (NotD (VarD 15)) (VarD
5))) (AndD (OrD (NotD (VarD 14)) (VarD 11)) (AndD (VarD 26) (VarD 6)))) (ImpD (EquivD (OrD (VarD 11) (NotD
(VarD 20))) (AndD (VarD 12) (VarD 13))) (ImpD (EquivD (VarD 12) (NotD (VarD 26))) (AndD (VarD 22) (VarD
8))))) (ImpD (ImpD (EquivD (OrD (VarD 14) (NotD (VarD 21))) (AndD (VarD 27) (VarD 15))) (EquivD (ImpD (NotD
(VarD 21)) (VarD 21)) (OrD (NotD (VarD 28)) (VarD 17)))) (AndD (OrD (EquivD (VarD 19) (NotD (VarD 29))) (AndD
(NotD (VarD 6)) (NotD (VarD 2)))) (EquivD (OrD (VarD 14) (NotD (VarD 7))) (OrD (VarD 27) (VarD 17)))))) (AndD
(EquivD (ImpD (AndD (ImpD (VarD 7) (VarD 28)) (ImpD (VarD 4) (VarD 25))) (OrD (ImpD (VarD 5) (VarD 2)) (AndD
(VarD 10) (VarD 10)))) (AndD (EquivD (EquivD (NotD (VarD 2)) (VarD 10)) (EquivD (NotD (VarD 30)) (VarD 9)))
(AndD (ImpD (VarD 15) (VarD 17)) (ImpD (NotD (VarD 24)) (VarD 27))))) (AndD (AndD (AndD (EquivD (NotD (VarD
19)) (NotD (VarD 1))) (EquivD (NotD (VarD 2)) (VarD 1))) (AndD (AndD (VarD 9) (VarD 8)) (AndD (VarD 15) (VarD
1)))) (EquivD (ImpD (OrD (VarD 15) (VarD 19)) (EquivD (NotD (VarD 8)) (NotD (VarD 10)))) (AndD (ImpD (VarD
20) (VarD 14)) (ImpD (VarD 25) (VarD 24)))))))))))))))))))))))))))))))))))))))"

lemma QBFmediumD unfolding DefD apply simp sledgehammer

abbreviation "EquivM \<phi> \<psi> \<equiv>  (AndM (ImpD \<phi> \<psi>) (ImpD \<psi> \<phi>))"

abbreviation "QBF \<equiv> \<Turnstile>\<^sup>d
(AllD 30 (ExD 29 (AllD 28 (ExD 27 (AllD 26 (ExD 25 (AllD 24 (ExD 23 (AllD 22 (ExD 21 (AllD 20 (ExD 19 (AllD
18 (ExD 17 (AllD 16 (ExD 15 (AllD 14 (ExD 13 (AllD 12 (ExD 11 (AllD 10 (ExD 9 (AllD 8 (ExD 7 (AllD 6 (ExD 5
(AllD 4 (ExD 3 (AllD 2 (ExD 1 (OrD (EquivD (EquivD (EquivD (AndD (EquivD (EquivD (ImpD (VarD 13) (NotD (VarD
28))) (ImpD (VarD 13) (VarD 14))) (ImpD (OrD (VarD 23) (VarD 28)) (AndD (VarD 15) (VarD 21)))) (EquivD (OrD
(AndD (VarD 17) (VarD 30)) (OrD (VarD 21) (NotD (VarD 13)))) (EquivD (ImpD (NotD (VarD 20)) (NotD (VarD 12)))
(ImpD (VarD 15) (VarD 1))))) (AndD (AndD (OrD (ImpD (NotD (VarD 14)) (VarD 11)) (AndD (VarD 28) (VarD 10)))
(ImpD (AndD (VarD 27) (VarD 11)) (AndD (NotD (VarD 27)) (NotD (VarD 8))))) (OrD (OrD (OrD (VarD 5) (VarD 20))
(AndD (VarD 23) (NotD (VarD 22)))) (AndD (EquivD (VarD 16) (VarD 28)) (OrD (VarD 8) (NotD (VarD 6)))))))
(AndD (ImpD (ImpD (AndD (OrD (VarD 11) (VarD 3)) (ImpD (VarD 8) (NotD (VarD 12)))) (OrD (OrD (NotD (VarD 24))
(VarD 11)) (EquivD (VarD 23) (NotD (VarD 16))))) (ImpD (EquivD (ImpD (VarD 2) (NotD (VarD 17))) (AndD (NotD
(VarD 15)) (NotD (VarD 7)))) (OrD (AndD (VarD 6) (VarD 1)) (OrD (VarD 15) (NotD (VarD 16)))))) (ImpD (ImpD
(EquivD (OrD (VarD 27) (VarD 9)) (OrD (VarD 19) (VarD 22))) (EquivD (OrD (NotD (VarD 8)) (VarD 28)) (EquivD
(NotD (VarD 1)) (VarD 30)))) (EquivD (AndD (OrD (NotD (VarD 24)) (NotD (VarD 28))) (EquivD (VarD 12) (NotD
(VarD 22)))) (ImpD (OrD (NotD (VarD 19)) (VarD 1)) (OrD (VarD 4) (NotD (VarD 21)))))))) (EquivD (EquivD
(EquivD (AndD (OrD (EquivD (VarD 4) (NotD (VarD 16))) (ImpD (VarD 25) (VarD 20))) (EquivD (ImpD (VarD 2)
(NotD (VarD 4))) (ImpD (VarD 4) (VarD 8)))) (ImpD (ImpD (OrD (VarD 2) (NotD (VarD 12))) (AndD (VarD 1) (VarD
4))) (AndD (ImpD (VarD 6) (VarD 25)) (ImpD (VarD 10) (VarD 20))))) (EquivD (OrD (AndD (EquivD (NotD (VarD
18)) (VarD 26)) (AndD (VarD 3) (VarD 24))) (OrD (ImpD (NotD (VarD 29)) (VarD 16)) (AndD (VarD 30) (VarD
26)))) (EquivD (OrD (ImpD (NotD (VarD 2)) (VarD 17)) (ImpD (NotD (VarD 19)) (VarD 17))) (AndD (EquivD (VarD
8) (VarD 28)) (EquivD (VarD 2) (VarD 27)))))) (ImpD (ImpD (AndD (AndD (AndD (NotD (VarD 3)) (VarD 24)) (OrD
(VarD 13) (NotD (VarD 18)))) (ImpD (OrD (NotD (VarD 27)) (VarD 6)) (AndD (VarD 27) (NotD (VarD 17))))) (OrD
(EquivD (AndD (NotD (VarD 5)) (VarD 1)) (OrD (NotD (VarD 15)) (VarD 29))) (AndD (EquivD (VarD 24) (VarD 25))
(AndD (VarD 26) (VarD 9))))) (OrD (EquivD (ImpD (ImpD (NotD (VarD 27)) (VarD 19)) (ImpD (VarD 19) (VarD 21)))
(ImpD (EquivD (NotD (VarD 21)) (VarD 21)) (ImpD (VarD 14) (VarD 8)))) (AndD (AndD (OrD (NotD (VarD 2)) (VarD
17)) (ImpD (VarD 13) (NotD (VarD 26)))) (OrD (OrD (VarD 22) (NotD (VarD 5))) (AndD (VarD 15) (VarD 29))))))))
(ImpD (OrD (EquivD (EquivD (OrD (OrD (ImpD (NotD (VarD 10)) (VarD 5)) (AndD (NotD (VarD 22)) (VarD 13)))
(AndD (OrD (NotD (VarD 9)) (VarD 10)) (EquivD (NotD (VarD 23)) (NotD (VarD 28))))) (OrD (OrD (EquivD (NotD
(VarD 6)) (VarD 14)) (AndD (NotD (VarD 14)) (VarD 8))) (ImpD (ImpD (VarD 25) (NotD (VarD 1))) (EquivD (NotD
(VarD 5)) (VarD 30))))) (AndD (EquivD (OrD (ImpD (NotD (VarD 25)) (VarD 11)) (AndD (VarD 11) (VarD 1))) (ImpD
(AndD (VarD 20) (VarD 9)) (AndD (NotD (VarD 11)) (VarD 3)))) (ImpD (ImpD (OrD (VarD 6) (VarD 10)) (AndD (NotD
(VarD 27)) (VarD 26))) (ImpD (AndD (VarD 4) (VarD 11)) (ImpD (VarD 18) (VarD 12)))))) (EquivD (AndD (AndD
(OrD (EquivD (VarD 15) (VarD 10)) (AndD (VarD 27) (VarD 9))) (OrD (AndD (VarD 26) (VarD 16)) (OrD (VarD 3)
(NotD (VarD 11))))) (AndD (AndD (ImpD (VarD 7) (NotD (VarD 15))) (OrD (NotD (VarD 23)) (NotD (VarD 25))))
(AndD (EquivD (VarD 24) (VarD 1)) (AndD (VarD 25) (VarD 14))))) (OrD (OrD (EquivD (OrD (VarD 30) (VarD 15))
(OrD (VarD 16) (VarD 24))) (AndD (ImpD (VarD 1) (NotD (VarD 26))) (AndD (VarD 16) (VarD 14)))) (EquivD
(EquivD (OrD (VarD 26) (VarD 7)) (ImpD (VarD 5) (VarD 6))) (AndD (AndD (VarD 5) (NotD (VarD 7))) (ImpD (VarD
24) (VarD 7))))))) (EquivD (EquivD (EquivD (OrD (EquivD (OrD (VarD 15) (VarD 9)) (OrD (NotD (VarD 15)) (VarD
5))) (AndD (OrD (NotD (VarD 14)) (VarD 11)) (AndD (VarD 26) (VarD 6)))) (ImpD (EquivD (OrD (VarD 11) (NotD
(VarD 20))) (AndD (VarD 12) (VarD 13))) (ImpD (EquivD (VarD 12) (NotD (VarD 26))) (AndD (VarD 22) (VarD
8))))) (ImpD (ImpD (EquivD (OrD (VarD 14) (NotD (VarD 21))) (AndD (VarD 27) (VarD 15))) (EquivD (ImpD (NotD
(VarD 21)) (VarD 21)) (OrD (NotD (VarD 28)) (VarD 17)))) (AndD (OrD (EquivD (VarD 19) (NotD (VarD 29))) (AndD
(NotD (VarD 6)) (NotD (VarD 2)))) (EquivD (OrD (VarD 14) (NotD (VarD 7))) (OrD (VarD 27) (VarD 17)))))) (AndD
(EquivD (ImpD (AndD (ImpD (VarD 7) (VarD 28)) (ImpD (VarD 4) (VarD 25))) (OrD (ImpD (VarD 5) (VarD 2)) (AndD
(VarD 10) (VarD 10)))) (AndD (EquivD (EquivD (NotD (VarD 2)) (VarD 10)) (EquivD (NotD (VarD 30)) (VarD 9)))
(AndD (ImpD (VarD 15) (VarD 17)) (ImpD (NotD (VarD 24)) (VarD 27))))) (AndD (AndD (AndD (EquivD (NotD (VarD
19)) (NotD (VarD 1))) (EquivD (NotD (VarD 2)) (VarD 1))) (AndD (AndD (VarD 9) (VarD 8)) (AndD (VarD 15) (VarD
1)))) (EquivD (ImpD (OrD (VarD 15) (VarD 19)) (EquivD (NotD (VarD 8)) (NotD (VarD 10)))) (AndD (ImpD (VarD
20) (VarD 14)) (ImpD (VarD 25) (VarD 24)))))))))))))))))))))))))))))))))))))))"


end
*)





