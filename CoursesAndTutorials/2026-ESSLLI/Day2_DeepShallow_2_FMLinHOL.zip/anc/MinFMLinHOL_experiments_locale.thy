theory MinFMLinHOL_experiments_locale imports MinFMLinHOL_faithfulness_locale
begin
\<comment>\<open>Demonstration: minimal-shallow proofs that hold in every interpretation of the
   MinS locale transfer directly to validity in the deep embedding.\<close>
\<comment>\<open>Derived rule: from validity in every minimal interpretation to deep validity.\<close>
  lemmas MinS_to_Deep = FaithfulMS_all[THEN iffD1, rule_format]
\<comment>\<open>Additional simplification rules for derived connectives under DpToShM.\<close>
  lemma (in MinS) OrM_simp[DefM]:  "\<lparr>\<phi> \<or>\<^sup>d \<psi>\<rparr> = \<lparr>\<phi>\<rparr> \<or>\<^sup>m \<lparr>\<psi>\<rparr>"  by (simp add: OrD_def OrM_def)
  lemma (in MinS) ImpM_simp[DefM]: "\<lparr>\<phi> \<supset>\<^sup>d \<psi>\<rparr> = \<lparr>\<phi>\<rparr> \<supset>\<^sup>m \<lparr>\<psi>\<rparr>" by (simp add: ImpD_def DefM)
  lemma (in MinS) BoxM_simp[DefM]: "\<lparr>\<box>\<^sup>d\<phi>\<rparr> = \<box>\<^sup>m\<lparr>\<phi>\<rparr>" by (simp add: BoxD_def DefM)
\<comment>\<open>Example: the K-axiom proved using only minimal-shallow infrastructure.\<close>
  lemma (in MinS) K_MinS: "\<Turnstile>\<^sup>m \<lparr>\<box>\<^sup>d(P\<^sup>d(x,y) \<supset>\<^sup>d P\<^sup>d(y,x)) \<supset>\<^sup>d (\<box>\<^sup>d P\<^sup>d(x,y) \<supset>\<^sup>d \<box>\<^sup>d P\<^sup>d(y,x))\<rparr>" by (auto simp: DefM)
\<comment>\<open>Transfer to the deep embedding requires no further work.\<close>
  lemma "\<Turnstile>\<^sup>d \<box>\<^sup>d(P\<^sup>d(x,y) \<supset>\<^sup>d P\<^sup>d(y,x)) \<supset>\<^sup>d (\<box>\<^sup>d P\<^sup>d(x,y) \<supset>\<^sup>d \<box>\<^sup>d P\<^sup>d(y,x))" using MinS_to_Deep[OF MinS.K_MinS].
end


