theory MinFMLinHOL_deep imports MinFMLinHOL_preliminaries
begin
\<comment>\<open>Deep embedding of (minimal) FML in HOL with constant-domain relational semantics.\<close>
  datatype \<F> =  AtmD R V V ("_\<^sup>d'(_,_')") | NegD \<F> ("\<not>\<^sup>d _" [58]59) | AndD \<F> \<F> (infixr "\<and>\<^sup>d" 56)
                            | ExD  V \<F> ("\<exists>\<^sup>d_. _") | DiaD \<F>  ("\<diamond>\<^sup>d _" [58]59)
\<comment>\<open>Further connectives as derived definitions.\<close>
  definition OrD   (infixr "\<or>\<^sup>d" 54)                where                  "\<phi> \<or>\<^sup>d \<psi> \<equiv> \<not>\<^sup>d(\<not>\<^sup>d\<phi> \<and>\<^sup>d \<not>\<^sup>d\<psi>)"
  definition ImpD (infixr "\<supset>\<^sup>d" 55)                where                  "\<phi> \<supset>\<^sup>d \<psi> \<equiv> \<not>\<^sup>d\<phi> \<or>\<^sup>d \<psi>"
  definition AllD   ("\<forall>\<^sup>d_. _")                           where                  "\<forall>\<^sup>dx. \<phi> \<equiv> \<not>\<^sup>d(\<exists>\<^sup>dx. \<not>\<^sup>d\<phi>)"
  definition BoxD  ("\<box>\<^sup>d _" [58]59)                 where                  "\<box>\<^sup>d\<phi>    \<equiv> \<not>\<^sup>d(\<diamond>\<^sup>d(\<not>\<^sup>d\<phi>))"
\<comment>\<open>Relative truth in a model.  Existential ranges over D; box ranges over R-successors in W.\<close>
  primrec RelativeTruthD::"\<W>\<Rightarrow>\<A>\<Rightarrow>\<I>\<Rightarrow>\<D>\<Rightarrow>\<E>\<Rightarrow>w\<Rightarrow>\<F>\<Rightarrow>bool" ("\<langle>_,_,_,_\<rangle>,_,_ \<Turnstile>\<^sup>d _" [10,10,10,10,10,10] 100) where
      "\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d (r\<^sup>d(x,y))   = I r w (g x) (g y)"
    | "\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d (\<not>\<^sup>d\<phi>)       = (\<not> \<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>)"
    | "\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d (\<phi> \<and>\<^sup>d \<psi>)   = (\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi> \<and> \<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<psi>)"
    | "\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d (\<exists>\<^sup>dx. \<phi>)    = (\<exists>d:D. \<langle>W,R,I,D\<rangle>,g[x\<leftarrow>d],w \<Turnstile>\<^sup>d \<phi>)"
    | "\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d (\<diamond>\<^sup>d\<phi>)       = (\<exists>v:W. R w v \<and> \<langle>W,R,I,D\<rangle>,g,v \<Turnstile>\<^sup>d \<phi>)"
\<comment>\<open>Validity: true in every model, every domain-respecting assignment, and every world of the universe.\<close>
  definition ValD ("\<Turnstile>\<^sup>d _" 9)       where                      "\<Turnstile>\<^sup>d \<phi> \<equiv> \<forall>W R I D g. g into D \<longrightarrow> (\<forall>w:W. \<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>)"
\<comment>\<open>Auxiliary "full-domain" notion of validity; restricts to assignments ranging over Univ of D\<close>
  definition ValD' ("\<Turnstile>\<^sup>d'' _" 9)     where                     "\<Turnstile>\<^sup>d' \<phi> \<equiv> \<forall> R I g. \<forall>w. \<langle>Univ,R,I,Univ\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>"
\<comment>\<open>General validity implies full-domain validity.\<close>
  lemma Val:             "\<Turnstile>\<^sup>d \<phi> \<Longrightarrow> \<Turnstile>\<^sup>d' \<phi>"                 using ValD'_def ValD_def by simp
\<comment>\<open>Adding a nonemptiness premise on the world universe leaves validity unchanged.\<close>
  lemma ValD_nonemptyW: "(\<Turnstile>\<^sup>d \<phi>) = (\<forall>W R I D g. (\<exists>w. W w) \<longrightarrow> g into D \<longrightarrow> (\<forall>w:W. \<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>))"
    by (smt (verit, ccfv_threshold) ValD_def)
\<comment>\<open>Bag of definitions for collective unfolding.\<close>
  named_theorems DefD lemmas [DefD] = OrD_def ImpD_def AllD_def BoxD_def ValD_def ValD'_def
end

