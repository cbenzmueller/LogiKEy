theory MinFMLinHOL_shallow_minimal imports MinFMLinHOL_faithfulness_locale
begin
\<comment>\<open>Global interpretation of the minimal shallow embedding.\<close>
  consts RR::\<A> II::\<I> gg::\<E> WW::\<W>
  global_interpretation MinS RR II gg WW.
\<comment>\<open>Re-introduce the locale-internal notation at the global level.\<close>
  notation AtmM ("_\<^sup>m'(_,_')") and NegM ("\<not>\<^sup>m _" [58]59) and AndM (infixr "\<and>\<^sup>m" 56) and ExM  (binder "\<exists>\<^sup>m" 53) 
    and BoxM ("\<box>\<^sup>m _" [58]59) and OrM (infixr "\<or>\<^sup>m" 54) and ImpM (infixr "\<supset>\<^sup>m" 55) and AllM (binder "\<forall>\<^sup>m" 53) 
    and DiaM ("\<diamond>\<^sup>m _" [58]59) and RelativeTruthM ("_ \<Turnstile>\<^sup>m _") and ValM ("\<Turnstile>\<^sup>m _" 9) and DpToShM ("\<lparr>_\<rparr>")
end


