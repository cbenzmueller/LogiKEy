theory MinFMLinHOL_preliminaries imports Main
begin
\<comment>\<open>Some global settings\<close> declare[[syntax_ambiguity_warning=false]] nitpick_params[user_axioms,expect=genuine]
\<comment>\<open>Declarations shared between the deep, maximal-shallow, and minimal-shallow embeddings of FML in HOL.\<close>
  typedecl D                                              \<comment>\<open>Domain of individuals (constant across worlds).\<close>
  typedecl w                                              \<comment>\<open>Type of possible worlds.\<close>
  type_synonym R  = nat                         \<comment>\<open>Binary relation symbols (encoded as naturals).\<close>
  type_synonym V  = nat                         \<comment>\<open>Individual variable symbols (encoded as naturals).\<close>
  type_synonym \<R> = "D\<Rightarrow>D\<Rightarrow>bool"         \<comment>\<open>Binary relations on individuals.\<close>
  type_synonym \<W> = "w\<Rightarrow>bool"              \<comment>\<open>Sets of possible worlds (the universe).\<close>
  type_synonym \<A> = "w\<Rightarrow>w\<Rightarrow>bool"        \<comment>\<open>Accessibility relations between worlds.\<close>
  type_synonym \<I>  = "R\<Rightarrow>w\<Rightarrow>\<R>"            \<comment>\<open>World-indexed interpretations of relation symbols.\<close>
  type_synonym \<E>  = "V\<Rightarrow>D"                  \<comment>\<open>Variable assignment functions.\<close>
  type_synonym \<D> = "D\<Rightarrow>bool"            \<comment>\<open>Domain restrictions (subsets of D as predicates).\<close>
\<comment>\<open>Pointwise update of variable assignments.\<close>
  definition EnvMod::"\<E>\<Rightarrow>V\<Rightarrow>D\<Rightarrow>\<E>" ("_[_ \<leftarrow> _]" [110,0,0] 110) where      "g[x\<leftarrow>d] \<equiv> \<lambda>z. if z = x then d else g z"
\<comment>\<open>Standard lemmas about variable-assignment update.\<close>
  lemma L1 [simp]:  "x \<noteq> y \<Longrightarrow> (g[y\<leftarrow>d]) x = g x"                               by (simp add: EnvMod_def)
  lemma L2:             "a \<noteq> c \<Longrightarrow> g[a\<leftarrow>d\<^sub>1][c\<leftarrow>d\<^sub>2] = g[c\<leftarrow>d\<^sub>2][a\<leftarrow>d\<^sub>1]"     by (auto simp: EnvMod_def)
  lemma L3 [simp]:  "(g[a\<leftarrow>d]) a = d"                                                  by (simp add: EnvMod_def)
  lemma L4 [simp]:  "g[a\<leftarrow>d\<^sub>1][a\<leftarrow>d\<^sub>2] = g[a\<leftarrow>d\<^sub>2]"                               by (auto simp: EnvMod_def)
\<comment>\<open>Standard predicates on accessibility relations (carried over from the PML preliminaries).\<close>
  abbreviation "reflexive      \<equiv> \<lambda>R::\<A>. \<forall>x. R x x"
  abbreviation "symmetric   \<equiv> \<lambda>R::\<A>. \<forall>x y. R x y \<longrightarrow> R y x"
  abbreviation "transitive     \<equiv> \<lambda>R::\<A>. \<forall>x y z. R x y \<and> R y z \<longrightarrow> R x z"
\<comment>\<open>Bounded quantifiers: \<open>\<forall>x:W. \<phi>\<close> stands for \<open>\<forall>x. W x \<longrightarrow> \<phi> x\<close> and \<open>\<exists>x:W. \<phi>\<close> stands for \<open>\<exists>x. W x \<and> \<phi> x\<close>.\<close>
  abbreviation (input) "BAll W \<phi> \<equiv> \<forall>x. W x \<longrightarrow> \<phi> x" 
  syntax "BAll"::"pttrn\<Rightarrow>logic\<Rightarrow>bool\<Rightarrow>bool" ("(3\<forall>(_/:_)./_)" [0,0,10]10)
  translations  "\<forall>x:W. \<phi>"  \<rightleftharpoons> "CONST BAll W (\<lambda>x. \<phi>)"
  abbreviation (input) "BEx W \<phi> \<equiv> \<exists>x. W x \<and> \<phi> x" 
  syntax "BEx"::"pttrn\<Rightarrow>logic\<Rightarrow>bool\<Rightarrow>bool" ("(3\<exists>(_/:_)./_)" [0,0,10]10)
  translations  "\<exists>x:W. \<phi>" \<rightleftharpoons> "CONST BEx W (\<lambda>x. \<phi>)"
\<comment>\<open>Set-as-predicate operations, range, and the universal domain.\<close>
  abbreviation (input) "Into"        (infix "into" 100)    where    " f into D \<equiv> \<forall>x. D (f x)"
  abbreviation (input) "Range"                                     where     "Range f \<equiv> \<lambda>x. \<exists>y. x = f y"
  abbreviation (input) "Onto"      (infix "onto" 100)    where        "f onto D \<equiv> D = Range f"
  abbreviation (input) "Subset"   (infix "\<^bold>\<subseteq>" 100)        where        "A \<^bold>\<subseteq> B \<equiv> \<forall>x. A x \<longrightarrow> B x"
  abbreviation (input) "Union"    (infixl "\<^bold>\<union>" 110)        where         "A \<^bold>\<union> B \<equiv> \<lambda>x. A x \<or> B x"
  abbreviation (input) "Univ"                                        where            "Univ \<equiv> \<lambda>x. True"
\<comment>\<open>Backward implication; useful for stating equivalences in two directions.\<close>
  abbreviation (input) Bimp (infixr "\<longleftarrow>" 50) where "\<phi> \<longleftarrow> \<psi> \<equiv> \<psi> \<longrightarrow> \<phi>"
end



