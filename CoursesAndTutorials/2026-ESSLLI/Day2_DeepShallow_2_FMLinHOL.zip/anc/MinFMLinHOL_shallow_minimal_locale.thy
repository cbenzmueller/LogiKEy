theory MinFMLinHOL_shallow_minimal_locale imports MinFMLinHOL_preliminaries
begin
\<comment>\<open>Minimal (lightweight) shallow embedding of FML in HOL, packaged as a locale.\<close>
  locale MinS = fixes RR :: \<A> and II :: \<I> and gg :: \<E> and WW::\<W>
  begin
\<comment>\<open>Formulas as HOL terms of type \<sigma> = \<w>\<Rightarrow>bool: only the dependency on the world is explicit.\<close>
    type_synonym \<sigma> = "w\<Rightarrow>bool"
\<comment>\<open>Five primitive cases.  ExM, AllM are HOL binders over V = nat; atoms consult II via gg.\<close>
    definition AtmM :: "R\<Rightarrow>V\<Rightarrow>V\<Rightarrow>\<sigma>"   ("_\<^sup>m'(_,_')")          where          "r\<^sup>m(x,y) \<equiv> \<lambda>w. II r w (gg x) (gg y)"
    definition NegM :: "\<sigma>\<Rightarrow>\<sigma>"              ("\<not>\<^sup>m _" [58]59)    where              "\<not>\<^sup>m\<phi> \<equiv> \<lambda>w. \<not>(\<phi> w)"
    definition AndM :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"         (infixr "\<and>\<^sup>m" 56)   where          "\<phi> \<and>\<^sup>m \<psi> \<equiv> \<lambda>w. \<phi> w \<and> \<psi> w"
    definition ExM   :: "(V\<Rightarrow>\<sigma>)\<Rightarrow>\<sigma>"      (binder "\<exists>\<^sup>m" 53)  where       "\<exists>\<^sup>md. \<Phi> d \<equiv> \<lambda>w. \<exists>d. \<Phi> d w"
    definition DiaM :: "\<sigma>\<Rightarrow>\<sigma>"              ("\<diamond>\<^sup>m _" [58]59)    where              "\<diamond>\<^sup>m\<phi> \<equiv> \<lambda>w. \<exists>v:WW. RR w v \<and> \<phi> v"
\<comment>\<open>Derived connectives.\<close>
    definition OrM   :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"         (infixr "\<or>\<^sup>m" 54)   where          "\<phi> \<or>\<^sup>m \<psi> \<equiv> \<not>\<^sup>m(\<not>\<^sup>m\<phi> \<and>\<^sup>m \<not>\<^sup>m\<psi>)"
    definition ImpM :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"         (infixr "\<supset>\<^sup>m" 55)   where         "\<phi> \<supset>\<^sup>m \<psi> \<equiv> \<not>\<^sup>m\<phi> \<or>\<^sup>m \<psi>"
    definition AllM   :: "(V\<Rightarrow>\<sigma>)\<Rightarrow>\<sigma>"      (binder "\<forall>\<^sup>m" 53)  where      "\<forall>\<^sup>md. \<Phi> d  \<equiv> \<lambda>w. \<forall>d. \<Phi> d w"
    definition BoxM  :: "\<sigma>\<Rightarrow>\<sigma>"             ("\<box>\<^sup>m _" [58]59)     where             "\<box>\<^sup>m\<phi> \<equiv> \<not>\<^sup>m(\<diamond>\<^sup>m(\<not>\<^sup>m\<phi>))"
\<comment>\<open>Relative truth and validity, with worlds restricted to the universe WW.\<close>
    definition RelativeTruthM :: "w\<Rightarrow>\<sigma>\<Rightarrow>bool" ("_ \<Turnstile>\<^sup>m _") where        "w \<Turnstile>\<^sup>m \<phi> \<equiv> \<phi> w"
    definition ValM  :: "\<sigma>\<Rightarrow>bool"         ("\<Turnstile>\<^sup>m _" 9)              where           "\<Turnstile>\<^sup>m \<phi> \<equiv> \<forall>w:WW. w \<Turnstile>\<^sup>m \<phi>"
\<comment>\<open>Bag of definitions.\<close>
    named_theorems DefM lemmas DefM_defs [DefM] = AtmM_def NegM_def AndM_def ExM_def BoxM_def OrM_def 
      ImpM_def AllM_def DiaM_def RelativeTruthM_def ValM_def
  end
end



