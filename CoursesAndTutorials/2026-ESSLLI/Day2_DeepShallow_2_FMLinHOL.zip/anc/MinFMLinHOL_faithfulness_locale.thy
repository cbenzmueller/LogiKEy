theory MinFMLinHOL_faithfulness_locale imports MinFMLinHOL_deep MinFMLinHOL_shallow 
  MinFMLinHOL_shallow_minimal_locale MinFMLinHOL_deep_subst_lemma MinFMLinHOL_ElementarySubstructure
begin
\<comment>\<open>Translation from deep to maximal shallow.\<close>
  fun DpToShS ("\<lbrakk>_\<rbrakk>") where
      "\<lbrakk>r\<^sup>d(x,y)\<rbrakk> = r\<^sup>s(x,y)" | "\<lbrakk>\<not>\<^sup>d\<phi>\<rbrakk> = \<not>\<^sup>s\<lbrakk>\<phi>\<rbrakk>" | "\<lbrakk>\<phi> \<and>\<^sup>d \<psi>\<rbrakk> = \<lbrakk>\<phi>\<rbrakk> \<and>\<^sup>s \<lbrakk>\<psi>\<rbrakk>" | "\<lbrakk>\<exists>\<^sup>dv. \<phi>\<rbrakk> = (\<exists>\<^sup>sv. \<lbrakk>\<phi>\<rbrakk>)" | "\<lbrakk>\<diamond>\<^sup>d\<phi>\<rbrakk> = \<diamond>\<^sup>s\<lbrakk>\<phi>\<rbrakk>"
\<comment>\<open>Translation from deep to minimal shallow (within the locale MinS.\<close>
  fun (in MinS) DpToShM ("\<lparr>_\<rparr>") where
      "\<lparr>r\<^sup>d(x,y)\<rparr> = r\<^sup>m(x,y)" | "\<lparr>\<not>\<^sup>d\<phi>\<rparr> = \<not>\<^sup>m\<lparr>\<phi>\<rparr>" | "\<lparr>\<phi> \<and>\<^sup>d \<psi>\<rparr> = \<lparr>\<phi>\<rparr> \<and>\<^sup>m \<lparr>\<psi>\<rparr>" | "\<lparr>\<exists>\<^sup>dv. \<phi>\<rparr> = (\<exists>\<^sup>md. \<lparr>[v\<leftarrow>\<^sub>r d](\<phi>)\<rparr>)" | "\<lparr>\<diamond>\<^sup>d\<phi>\<rparr> = \<diamond>\<^sup>m\<lparr>\<phi>\<rparr>"
\<comment>\<open>Faithfulness deep \<longleftrightarrow> maximal shallow.  Pointwise first; global by unfolding validity.\<close>
  theorem FaithfulSDlem: "(\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>) \<longleftrightarrow> (\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>)" 
    by (induct \<phi> arbitrary: g w; auto simp: DefS DefD)
  theorem FaithfulSD: "(\<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>) \<longleftrightarrow> (\<Turnstile>\<^sup>d \<phi>)" by (simp add: FaithfulSDlem ValD_def ValS_def)
\<comment>\<open>Faithfulness deep \<longleftrightarrow> minimal shallow, parametrised by the locale.\<close>
  context MinS 
    begin
      theorem FaithfulMDlem: "(w \<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<langle>WW,RR,II,Range gg\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi>)"
        by (induct \<phi> arbitrary: w rule: QInduct; simp add: DefD DefM) blast
      theorem FaithfulMD: "(\<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<forall>w:WW. \<langle>WW,RR,II,Range gg\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi>)"
        using FaithfulMDlem by (simp add: ValM_def)
      theorem FaithfulMSlem: "(w \<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<langle>WW,RR,II,Range gg\<rangle>,gg,w \<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>)"
        using FaithfulSDlem FaithfulMDlem by auto
      theorem FaithfulMS: "(\<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<forall>w:WW. \<langle>WW,RR,II,Range gg\<rangle>,gg,w \<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>)"
        using FaithfulMSlem by (simp add: ValM_def RelativeTruthM_def)
   end
\<comment>\<open>Stronger version for elementary substructures.\<close>
  context MinS_ES
  begin
    theorem FaithfulMDlem_ES: "WW w \<Longrightarrow> (w \<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<langle>WW',RR,II,DD\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi>)"
    by (simp add: FaithfulMDlem \<N>_valid_ES)
    theorem FaithfulMD_ES: "(\<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<forall>w:WW. \<langle>WW',RR,II,DD\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi>)"
      using FaithfulMDlem_ES ValM_def by auto
    theorem FaithfulMSlem_ES: "WW w \<Longrightarrow> (w \<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<langle>WW',RR,II,DD\<rangle>,gg,w \<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>)"
      by (simp add: FaithfulMDlem_ES FaithfulSDlem)
    theorem FaithfulMS_ES: "(\<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<forall>w:WW. \<langle>WW',RR,II,DD\<rangle>,gg,w \<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>)"
      using FaithfulMSlem_ES by (simp add: ValM_def RelativeTruthM_def)
  end
\<comment>\<open>Global faithfulness: quantifying over all locale interpretations of MinS recovers exactly deep validity.\<close>
  theorem FaithfulMS_all: "(\<forall>WW RR II gg. MinS.ValM WW (MinS.DpToShM RR II gg WW \<phi>)) = (\<Turnstile>\<^sup>d \<phi>)"
  proof(unfold ValD_def; safe)
    {
      fix W :: \<W> and R :: \<A> and I D and g::\<E> and x
      assume "g into D"
      moreover assume "W x"
      ultimately interpret MinS_specific R I W D g \<phi> x  using MinS_specific_def by simp
      assume "\<forall>WW RR II gg. MinS.ValM WW (MinS.DpToShM RR II gg WW \<phi>)"
      hence "\<langle>WW,RR,I,Range gg\<rangle>,gg,x \<Turnstile>\<^sup>d \<phi>" using FaithfulMD w_in_WW by blast
      thus "\<langle>W,R,I,D\<rangle>,g,x \<Turnstile>\<^sup>d \<phi>" using valid_specific by simp
    }
  qed(metis (mono_tags, lifting) MinS.FaithfulMD)
  theorem FaithfulMS_all_ES: "(\<forall>WW RR II gg. \<langle>WW,RR,II,Range gg\<rangle> \<subseteq>\<^sub>E \<langle>Univ,RR,II,Univ\<rangle> \<longrightarrow> 
    MinS.ValM WW (MinS.DpToShM RR II gg WW \<phi>)) = (\<Turnstile>\<^sup>d' \<phi>)" 
  proof(unfold ValD'_def; safe)
    {
      fix R :: \<A> and I and g::\<E> and x
      interpret MinS_specific R I Univ Univ g \<phi> x unfolding MinS_specific_def by simp
      assume "\<forall>WW RR II gg. \<langle>WW,RR,II,Range gg\<rangle> \<subseteq>\<^sub>E \<langle>Univ,RR,II,Univ\<rangle> \<longrightarrow> 
        MinS.ValM WW (MinS.DpToShM RR II gg WW \<phi>)"
      hence "ValM (DpToShM \<phi>)" using ES' by blast
      thus "\<langle>Univ,R,I,Univ\<rangle>,g,x \<Turnstile>\<^sup>d \<phi>" using FaithfulMD valid_specific w_in_WW by blast
    }
  qed(simp add: MinS_ES.FaithfulMD_ES MinS_ES_def)
\<comment>\<open>Global faithfulness': quantifying over all locale interpretations of MinS_ES_Univ recovers exactly deep validity in 
      the universal domains.\<close>
  theorem FaithfulMS_all': "(\<forall>WW RR II gg. MinS_ES_Univ RR II gg WW \<longrightarrow> 
    MinS.ValM WW (MinS.DpToShM RR II gg WW \<phi>)) = (\<Turnstile>\<^sup>d' \<phi>)"
      unfolding MinS_ES_Univ_def MinS_ES_def using FaithfulMS_all_ES by force
\<comment>\<open>Consistency check.\<close>
  lemma True nitpick[satisfy] oops
end



