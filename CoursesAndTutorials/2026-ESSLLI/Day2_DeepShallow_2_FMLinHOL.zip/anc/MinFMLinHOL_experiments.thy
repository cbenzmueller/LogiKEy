theory MinFMLinHOL_experiments
  imports MinFMLinHOL_deep MinFMLinHOL_shallow MinFMLinHOL_shallow_minimal
begin
  abbreviation "(x::V) \<equiv> 1" abbreviation "(y::V) \<equiv> 2" abbreviation "(z::V) \<equiv> 3"
  consts P::R
\<comment>\<open>--- Propositional tautologies, lifted to FML in all three embeddings ---\<close>
  lemma "\<Turnstile>\<^sup>d (P\<^sup>d(x,x) \<supset>\<^sup>d P\<^sup>d(x,x))" unfolding DefD by simp
  lemma "\<Turnstile>\<^sup>s (P\<^sup>s(x,x) \<supset>\<^sup>s P\<^sup>s(x,x))" unfolding DefS by simp
  lemma "\<Turnstile>\<^sup>m (P\<^sup>m(x,x) \<supset>\<^sup>m P\<^sup>m(x,x))" unfolding DefM by simp
  lemma "\<Turnstile>\<^sup>d (\<not>\<^sup>d\<not>\<^sup>d P\<^sup>d(x,y)) \<supset>\<^sup>d P\<^sup>d(x,y)" unfolding DefD by auto
  lemma "\<Turnstile>\<^sup>s (\<not>\<^sup>s\<not>\<^sup>s P\<^sup>s(x,y)) \<supset>\<^sup>s P\<^sup>s(x,y)" unfolding DefS by auto
  lemma "\<Turnstile>\<^sup>m (\<not>\<^sup>m\<not>\<^sup>m P\<^sup>m(x,y)) \<supset>\<^sup>m P\<^sup>m(x,y)" unfolding DefM by auto
\<comment>\<open>K (distribution): \<box>(\<phi> \<supset> \<psi>) \<supset> (\<box>\<phi> \<supset> \<box>\<psi>).\<close>
  lemma K_d: "\<Turnstile>\<^sup>d \<box>\<^sup>d(P\<^sup>d(x,y) \<supset>\<^sup>d P\<^sup>d(y,x)) \<supset>\<^sup>d (\<box>\<^sup>d P\<^sup>d(x,y) \<supset>\<^sup>d \<box>\<^sup>d P\<^sup>d(y,x))" unfolding DefD by auto
  lemma K_s: "\<Turnstile>\<^sup>s \<box>\<^sup>s(P\<^sup>s(x,y) \<supset>\<^sup>s P\<^sup>s(y,x)) \<supset>\<^sup>s (\<box>\<^sup>s P\<^sup>s(x,y) \<supset>\<^sup>s \<box>\<^sup>s P\<^sup>s(y,x))" unfolding DefS by auto
  lemma K_m: "\<Turnstile>\<^sup>m \<box>\<^sup>m(P\<^sup>m(x,y) \<supset>\<^sup>m P\<^sup>m(y,x)) \<supset>\<^sup>m (\<box>\<^sup>m P\<^sup>m(x,y) \<supset>\<^sup>m \<box>\<^sup>m P\<^sup>m(y,x))" unfolding DefM by auto
\<comment>\<open>Necessitation rule: if \<phi> is valid then so is \<box>\<phi>.\<close>
  lemma Nec_d: "\<Turnstile>\<^sup>d \<phi> \<Longrightarrow> \<Turnstile>\<^sup>d \<box>\<^sup>d\<phi>" unfolding DefD by auto
  lemma Nec_s: "\<Turnstile>\<^sup>s \<phi> \<Longrightarrow> \<Turnstile>\<^sup>s \<box>\<^sup>s\<phi>" unfolding DefS by auto
  lemma Nec_m: "\<Turnstile>\<^sup>m \<phi> \<Longrightarrow> \<Turnstile>\<^sup>m \<box>\<^sup>m\<phi>" unfolding DefM by auto
\<comment>\<open>First-order tautologies, lifted to FML.\<close>
  lemma "\<Turnstile>\<^sup>d (\<forall>\<^sup>dx. P\<^sup>d(x,x)) \<supset>\<^sup>d (\<exists>\<^sup>dx. P\<^sup>d(x,x))" unfolding DefD by auto
  lemma "\<Turnstile>\<^sup>s (\<forall>\<^sup>sx. P\<^sup>s(x,x)) \<supset>\<^sup>s (\<exists>\<^sup>sx. P\<^sup>s(x,x))" unfolding DefS by auto
  lemma "\<Turnstile>\<^sup>m (\<forall>\<^sup>mx. P\<^sup>m(x,x)) \<supset>\<^sup>m (\<exists>\<^sup>mx. P\<^sup>m(x,x))" unfolding DefM by auto
\<comment>\<open>Quantifier/modality interactions: Barcan and Converse Barcan.\<close>
  lemma BF_d:  "\<Turnstile>\<^sup>d (\<forall>\<^sup>dx. \<box>\<^sup>d P\<^sup>d(x,x)) \<supset>\<^sup>d \<box>\<^sup>d (\<forall>\<^sup>dx. P\<^sup>d(x,x))" unfolding DefD by auto
  lemma BF_s:  "\<Turnstile>\<^sup>s (\<forall>\<^sup>sx. \<box>\<^sup>s P\<^sup>s(x,x)) \<supset>\<^sup>s \<box>\<^sup>s (\<forall>\<^sup>sx. P\<^sup>s(x,x))" unfolding DefS by auto
  lemma BF_m:  "\<Turnstile>\<^sup>m (\<forall>\<^sup>mx. \<box>\<^sup>m P\<^sup>m(x,x)) \<supset>\<^sup>m \<box>\<^sup>m (\<forall>\<^sup>mx. P\<^sup>m(x,x))" unfolding DefM by auto
  lemma CBF_d: "\<Turnstile>\<^sup>d \<box>\<^sup>d (\<forall>\<^sup>dx. P\<^sup>d(x,x)) \<supset>\<^sup>d (\<forall>\<^sup>dx. \<box>\<^sup>d P\<^sup>d(x,x))" unfolding DefD by auto
  lemma CBF_s: "\<Turnstile>\<^sup>s \<box>\<^sup>s (\<forall>\<^sup>sx. P\<^sup>s(x,x)) \<supset>\<^sup>s (\<forall>\<^sup>sx. \<box>\<^sup>s P\<^sup>s(x,x))" unfolding DefS by auto
  lemma CBF_m: "\<Turnstile>\<^sup>m \<box>\<^sup>m (\<forall>\<^sup>mx. P\<^sup>m(x,x)) \<supset>\<^sup>m (\<forall>\<^sup>mx. \<box>\<^sup>m P\<^sup>m(x,x))" unfolding DefM by auto
\<comment>\<open>Existential variants of Barcan: under constant domain, \<diamond>\<exists> and \<exists>\<diamond> coincide.\<close>
  lemma Barcan_Dia_d:      "\<Turnstile>\<^sup>d (\<diamond>\<^sup>d (\<exists>\<^sup>dx. P\<^sup>d(x,x))) \<supset>\<^sup>d (\<exists>\<^sup>dx. \<diamond>\<^sup>d P\<^sup>d(x,x))" unfolding DefD by auto
  lemma Barcan_Dia_s:      "\<Turnstile>\<^sup>s (\<diamond>\<^sup>s (\<exists>\<^sup>sx. P\<^sup>s(x,x))) \<supset>\<^sup>s (\<exists>\<^sup>sx. \<diamond>\<^sup>s P\<^sup>s(x,x))" unfolding DefS by auto
  lemma Barcan_Dia_m:      "\<Turnstile>\<^sup>m (\<diamond>\<^sup>m (\<exists>\<^sup>mx. P\<^sup>m(x,x))) \<supset>\<^sup>m (\<exists>\<^sup>mx. \<diamond>\<^sup>m P\<^sup>m(x,x))" unfolding DefM by auto
  lemma Barcan_Dia_d_conv: "\<Turnstile>\<^sup>d (\<exists>\<^sup>dx. \<diamond>\<^sup>d P\<^sup>d(x,x)) \<supset>\<^sup>d \<diamond>\<^sup>d (\<exists>\<^sup>dx. P\<^sup>d(x,x))" unfolding DefD by auto
  lemma Barcan_Dia_s_conv: "\<Turnstile>\<^sup>s (\<exists>\<^sup>sx. \<diamond>\<^sup>s P\<^sup>s(x,x)) \<supset>\<^sup>s \<diamond>\<^sup>s (\<exists>\<^sup>sx. P\<^sup>s(x,x))" unfolding DefS by auto
  lemma Barcan_Dia_m_conv: "\<Turnstile>\<^sup>m (\<exists>\<^sup>mx. \<diamond>\<^sup>m P\<^sup>m(x,x)) \<supset>\<^sup>m \<diamond>\<^sup>m (\<exists>\<^sup>mx. P\<^sup>m(x,x))" unfolding DefM by auto
\<comment>\<open>Invalid schemata: nitpick reports finite countermodels.\<close>
\<comment>\<open>Symmetry of P is not implied: nitpick produces a 2-element countermodel. (Note: needs full domain D.)\<close>
  lemma "\<Turnstile>\<^sup>d' (\<forall>\<^sup>dx. \<forall>\<^sup>dy. (P\<^sup>d(x,y) \<supset>\<^sup>d P\<^sup>d(y,x)))" unfolding DefD apply simp nitpick oops
  lemma "\<Turnstile>\<^sup>m  (\<forall>\<^sup>mu. \<forall>\<^sup>mv. (P\<^sup>m(x,y) \<supset>\<^sup>m P\<^sup>m(y,x)))" unfolding DefM nitpick oops
\<comment>\<open>Modal collapse \<phi> \<supset> \<box>\<phi> fails. (Note: needs full domain D for \<Turnstile>d'.)\<close>
  lemma "\<Turnstile>\<^sup>d' P\<^sup>d(x,x) \<supset>\<^sup>d \<box>\<^sup>d P\<^sup>d(x,x)" unfolding DefD apply simp nitpick oops
  lemma "\<Turnstile>\<^sup>m  P\<^sup>m(x,x) \<supset>\<^sup>m \<box>\<^sup>m P\<^sup>m(x,x)" unfolding DefM nitpick oops
\<comment>\<open>T-axiom \<box>\<phi> \<supset> \<phi> fails without reflexivity. (Note: needs full domain D.)\<close>
  lemma "\<Turnstile>\<^sup>d' \<box>\<^sup>d P\<^sup>d(x,x) \<supset>\<^sup>d P\<^sup>d(x,x)" unfolding DefD apply simp nitpick oops
  lemma "\<Turnstile>\<^sup>m  \<box>\<^sup>m P\<^sup>m(x,x) \<supset>\<^sup>m P\<^sup>m(x,x)" unfolding DefM nitpick oops
\<comment>\<open>De-re/de-dicto distinction is collapsed under constant domain: \<diamond>\<exists> implies \<exists>\<diamond>.\<close>
  lemma "\<Turnstile>\<^sup>d \<diamond>\<^sup>d (\<exists>\<^sup>dx. P\<^sup>d(x,x)) \<supset>\<^sup>d (\<exists>\<^sup>dx. \<diamond>\<^sup>d P\<^sup>d(x,x))" unfolding DefD by auto
  lemma "\<Turnstile>\<^sup>s \<diamond>\<^sup>s (\<exists>\<^sup>sx. P\<^sup>s(x,x)) \<supset>\<^sup>s (\<exists>\<^sup>sx. \<diamond>\<^sup>s P\<^sup>s(x,x))" unfolding DefS by auto
  lemma "\<Turnstile>\<^sup>m \<diamond>\<^sup>m (\<exists>\<^sup>mx. P\<^sup>m(x,x)) \<supset>\<^sup>m (\<exists>\<^sup>mx. \<diamond>\<^sup>m P\<^sup>m(x,x))" unfolding DefM by auto
end


