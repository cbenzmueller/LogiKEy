theory MinFMLinHOL_shallow imports MinFMLinHOL_preliminaries
begin
\<comment>\<open>Maximal (heavyweight) shallow embedding of FML in HOL; FML formulas are HOL terms of the following type \<sigma>.\<close>
  type_synonym \<sigma> = "\<W>\<Rightarrow>\<A>\<Rightarrow>\<I>\<Rightarrow>\<D>\<Rightarrow>\<E>\<Rightarrow>w\<Rightarrow>bool"
\<comment>\<open>The five primitive cases.\<close>
  definition AtmS :: "R\<Rightarrow>V\<Rightarrow>V\<Rightarrow>\<sigma>"  ("_\<^sup>s'(_,_')")         where     "r\<^sup>s(x,y) \<equiv> \<lambda>W R I D g w. I r w (g x) (g y)"
  definition NegS :: "\<sigma>\<Rightarrow>\<sigma>"             ("\<not>\<^sup>s _" [58]59)   where     "\<not>\<^sup>s\<phi>    \<equiv> \<lambda>W R I D g w. \<not>(\<phi> W R I D g w)"
  definition AndS :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"        (infixr "\<and>\<^sup>s" 56)  where    "\<phi> \<and>\<^sup>s \<psi> \<equiv> \<lambda>W R I D g w. \<phi> W R I D g w \<and> \<psi> W R I D g w"
  definition ExS   :: "V\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"        ("\<exists>\<^sup>s_. _" 53)       where     "\<exists>\<^sup>sx. \<phi> \<equiv> \<lambda>W R I D g w. \<exists>d:D. \<phi> W R I D (g[x\<leftarrow>d]) w"
  definition DiaS :: "\<sigma>\<Rightarrow>\<sigma>"             ("\<diamond>\<^sup>s _" [58]59)   where     "\<diamond>\<^sup>s\<phi>    \<equiv> \<lambda>W R I D g w. \<exists>v:W. R w v \<and> \<phi> W R I D g v"
\<comment>\<open>Derived connectives.\<close>
  definition OrS   :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"        (infixr "\<or>\<^sup>s" 54)  where     "\<phi> \<or>\<^sup>s \<psi> \<equiv> \<not>\<^sup>s(\<not>\<^sup>s\<phi> \<and>\<^sup>s \<not>\<^sup>s\<psi>)"
  definition ImpS :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"        (infixr "\<supset>\<^sup>s" 55)  where    "\<phi> \<supset>\<^sup>s \<psi> \<equiv> \<not>\<^sup>s\<phi> \<or>\<^sup>s \<psi>"
  definition AllS   :: "V\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"        ("\<forall>\<^sup>s_. _" 53)        where    "\<forall>\<^sup>sx. \<phi>  \<equiv> \<not>\<^sup>s(\<exists>\<^sup>sx. \<not>\<^sup>s\<phi>)"
  definition BoxS :: "\<sigma>\<Rightarrow>\<sigma>"              ("\<box>\<^sup>s _" [58]59)   where     "\<box>\<^sup>s\<phi>    \<equiv> \<not>\<^sup>s(\<diamond>\<^sup>s(\<not>\<^sup>s\<phi>))"
\<comment>\<open>Relative truth and validity (mirroring the deep embedding).\<close>
  definition RelTruthS :: "\<W>\<Rightarrow>\<A>\<Rightarrow>\<I>\<Rightarrow>\<D>\<Rightarrow>\<E>\<Rightarrow>w\<Rightarrow>\<sigma>\<Rightarrow>bool" ("\<langle>_,_,_,_\<rangle>,_,_ \<Turnstile>\<^sup>s _" [100,0,0,0,0,100] 100) 
                                                           where "\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>s \<phi> \<equiv> \<phi> W R I D g w"
  definition ValS :: "\<sigma>\<Rightarrow>bool" ("\<Turnstile>\<^sup>s _" 9) where                 "\<Turnstile>\<^sup>s \<phi> \<equiv> \<forall>W R I D g. g into D \<longrightarrow> (\<forall>w:W. \<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>s \<phi>)"
\<comment>\<open>Bag of definitions.\<close>
  named_theorems DefS lemmas DefS_defs [DefS] = AtmS_def NegS_def AndS_def ExS_def BoxS_def OrS_def 
    ImpS_def AllS_def DiaS_def RelTruthS_def ValS_def
end

