theory MinFMLinHOL_faithfulness
  imports MinFMLinHOL_deep MinFMLinHOL_shallow MinFMLinHOL_shallow_minimal MinFMLinHOL_deep_subst_lemma
begin
\<comment>\<open>Deep \<longleftrightarrow> maximal shallow.\<close>
  theorem "(\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>) \<longleftrightarrow> (\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>)"                                     using FaithfulSDlem .
  theorem "(\<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>) \<longleftrightarrow> (\<Turnstile>\<^sup>d \<phi>)"                                                                                using FaithfulSD .
\<comment>\<open>Deep \<longleftrightarrow> minimal shallow, relative to the range of the chosen assignment gg.\<close>
  theorem "(w \<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<langle>WW,RR,II,Range gg\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi>)"                                  using FaithfulMDlem .
  theorem "(\<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<forall>w:WW. \<langle>WW,RR,II,Range gg\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi>)"                        using FaithfulMD .
  theorem "(w \<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<langle>WW,RR,II,Range gg\<rangle>,gg,w \<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>)"                                using FaithfulMSlem .
  theorem "(\<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<forall>w:WW. \<langle>WW,RR,II,Range gg\<rangle>,gg,w \<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>)"                      using FaithfulMS .
  consts DD\<^sub>0::\<D> 
  specification(DD\<^sub>0)
    DD\<^sub>0_nonempty: "\<exists> x . DD\<^sub>0 x"
    DD\<^sub>0_countable: "countable (Collect DD\<^sub>0)"
    using uncountable_infinite by fastforce
  consts  WW\<^sub>0::\<W>
  specification(WW\<^sub>0)
      WW\<^sub>0_countable: "countable (Collect WW\<^sub>0)"
      by (metis countable_empty countable_insert_eq singleton_conv2)
\<comment>\<open>Stronger result: choosing particular model parameters we obtain faithfulness relative to the full domain of
     individuals and the full domain on worlds for evaluating in a countable subset of worlds.\<close>
  consts DD::\<D>
  specification(DD WW gg)
    gg_surj_spec: "gg onto DD"
    DD\<^sub>0_in_DD_spec: "DD\<^sub>0 \<^bold>\<subseteq> DD"
    WW\<^sub>0_in_WW_spec: "WW\<^sub>0 \<^bold>\<subseteq> WW"
    elementary_substructure_spec: "WW w \<Longrightarrow> \<langle>WW,RR,II,DD\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi> = \<langle>Univ,RR,II,Univ\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi>"
  proof -
    have 0: "DD\<^sub>0 \<^bold>\<subseteq> Univ"    by simp
    have 1: "WW\<^sub>0 \<^bold>\<subseteq> Univ"   by simp
    obtain N W' where "DD\<^sub>0 \<^bold>\<subseteq> N" and "countable (Collect N)" and "WW\<^sub>0 \<^bold>\<subseteq> W'" and "countable (Collect W')" and
          "\<And>g \<phi> w. W' w \<Longrightarrow> g into N \<Longrightarrow> \<langle>Univ,RR,II,Univ\<rangle>,g,w \<Turnstile>\<^sup>d \<phi> = \<langle>W',RR,II,N\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>"
      using DownwardLowenheimSkolem[OF 0, OF 1, OF DD\<^sub>0_countable, OF WW\<^sub>0_countable] by metis
    moreover obtain gg :: \<E> where "gg onto N"
      using calculation gg_ex
      by (metis DD\<^sub>0_nonempty empty_Collect_eq from_nat_into from_nat_into_surj mem_Collect_eq)
    ultimately show ?thesis by (auto intro!: exI[where x=N] exI[where x=W'] exI[where x=gg]) blast+
  qed
\<comment>\<open>Faithfulness relative to the fixed model parameters and the full domain of D, even when D is uncountable.\<close>
  theorem "(\<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<forall>w:WW. \<langle>Univ,RR,II,Univ\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi>)"
    using FaithfulMDlem FaithfulMS FaithfulMSlem elementary_substructure_spec gg_surj_spec by simp
  theorem "WW w \<Longrightarrow> (w \<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<langle>Univ,RR,II,Univ\<rangle>,gg,w \<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>)"
    using FaithfulMDlem FaithfulSDlem elementary_substructure_spec gg_surj_spec by auto
  theorem "(\<Turnstile>\<^sup>m \<lparr>\<phi>\<rparr>) \<longleftrightarrow> (\<forall>w:WW. \<langle>Univ,RR,II,Univ\<rangle>,gg,w \<Turnstile>\<^sup>s \<lbrakk>\<phi>\<rbrakk>)"
    using FaithfulMS FaithfulSDlem elementary_substructure_spec gg_surj_spec by auto
\<comment>\<open>Consistency check.\<close>
  lemma True nitpick[satisfy] oops
end




