theory MinFMLinHOL_deep_subst_lemma imports MinFMLinHOL_deep
begin
\<comment>\<open>Free and bound variable occurrences.  The Box case is transparent.\<close>
  primrec is_free (infix "free'_in" 900) where
      "x free_in (r\<^sup>d(u,v)) = (x = u \<or> x = v)"
    | "x free_in (\<not>\<^sup>d\<phi>)     = (x free_in \<phi>)"
    | "x free_in (\<phi> \<and>\<^sup>d \<psi>) = (x free_in \<phi> \<or> x free_in \<psi>)"
    | "x free_in (\<exists>\<^sup>dy. \<phi>) = (x free_in \<phi> \<and> x \<noteq> y)"
    | "x free_in (\<diamond>\<^sup>d\<phi>)     = (x free_in \<phi>)"
  abbreviation is_not_free (infix "not'_free'_in" 900) where "x not_free_in \<phi> \<equiv> \<not>(x free_in \<phi>)"
  fun is_bound (infix "bound'_in" 900) where
      "x bound_in (r\<^sup>d(u,v)) = False"
    | "x bound_in (\<not>\<^sup>d\<phi>)     = (x bound_in \<phi>)"
    | "x bound_in (\<phi> \<and>\<^sup>d \<psi>) = (x bound_in \<phi> \<or> x bound_in \<psi>)"
    | "x bound_in (\<exists>\<^sup>dy. \<phi>) = (x = y \<or> x bound_in \<phi>)"
    | "x bound_in (\<diamond>\<^sup>d\<phi>)     = (x bound_in \<phi>)"
  abbreviation is_not_bound (infix "not'_bound'_in" 900) where "x not_bound_in \<phi> \<equiv> \<not>(x bound_in \<phi>)"
  abbreviation not_in        (infix "not'_in"       900) where "x not_in \<phi> \<equiv> x not_free_in \<phi> \<and> x not_bound_in \<phi>"
\<comment>\<open>A fresh variable: strictly larger than every variable occurring in \<phi>.\<close>
  primrec fresh ("fresh'(_')") where
      "fresh (r\<^sup>d(u,v)) = max (u+1) (v+1)"
    | "fresh (\<not>\<^sup>d\<phi>)     = fresh \<phi>"
    | "fresh (\<phi> \<and>\<^sup>d \<psi>) = max (fresh \<phi>) (fresh \<psi>)"
    | "fresh (\<exists>\<^sup>dx. \<phi>) = max (x+1) (fresh \<phi>)"
    | "fresh (\<diamond>\<^sup>d\<phi>)     = fresh \<phi>"
  lemma L5: "x bound_in \<phi> \<Longrightarrow> x < (fresh \<phi>)" by (induct \<phi>) auto
  lemma L6: "x free_in \<phi> \<Longrightarrow> x < (fresh \<phi>)"  by (induct \<phi>) auto
  lemma L7: "(fresh \<phi>) not_in \<phi>"              using L5 L6 by blast
  lemma L8:  "max (fresh \<phi>) (fresh \<psi>) not_free_in \<phi>"  by (metis L6 L7 max.absorb3 max_def)
  lemma L9:  "max (fresh \<phi>) (fresh \<psi>) not_bound_in \<phi>" by (metis L5 L7 max.absorb3 max_def)
\<comment>\<open>Irrelevance lemma: updating a non-free variable does not affect truth.\<close>
  lemma L12: "y not_free_in \<phi> \<Longrightarrow> (\<langle>W,R,I,D\<rangle>,g[y\<leftarrow>d],w \<Turnstile>\<^sup>d \<phi>) = (\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>)" 
    by (induct \<phi> arbitrary: g w; simp; metis L4 L2)
\<comment>\<open>Variable-for-variable substitution.  Box descends transparently.\<close>
  primrec Subst ("[_\<leftarrow>_]'(_')") where
      "[x\<leftarrow>z](r\<^sup>d(u,v)) = r\<^sup>d((if x = u then z else u), (if x = v then z else v))"
    | "[x\<leftarrow>z](\<not>\<^sup>d\<phi>)     = \<not>\<^sup>d([x\<leftarrow>z](\<phi>))"
    | "[x\<leftarrow>z](\<phi> \<and>\<^sup>d \<psi>) = ([x\<leftarrow>z](\<phi>) \<and>\<^sup>d [x\<leftarrow>z](\<psi>))"
    | "[x\<leftarrow>z](\<exists>\<^sup>dy. \<phi>) = (if x = y then (\<exists>\<^sup>dy. \<phi>) else (\<exists>\<^sup>dy. [x\<leftarrow>z](\<phi>)))"
    | "[x\<leftarrow>z](\<diamond>\<^sup>d\<phi>)     = \<diamond>\<^sup>d([x\<leftarrow>z](\<phi>))"
  lemma L13 [simp]: "size [x\<leftarrow>z](\<phi>) = size \<phi>" by (induct \<phi>; auto)
  lemma L14 [simp]: "[x\<leftarrow>x](\<phi>) = \<phi>"            by (induct \<phi>; auto)
  lemma L16 [simp]: assumes "a \<noteq> x" shows "a not_free_in ([a\<leftarrow>x](\<phi>))" using assms by (induct \<phi>) auto
\<comment>\<open>Size-based induction principle (analogous to QBF's SInduct, with a Box clause).\<close>
  lemma SInduct:
    assumes "\<And>r u v. P (r\<^sup>d(u,v))"
        and "\<And>\<phi>.    (\<And>\<psi>. size \<psi> \<le> size \<phi>             \<Longrightarrow> P \<psi>) \<Longrightarrow> P (\<not>\<^sup>d\<phi>)"
        and "\<And>\<phi> \<psi>. (\<And>\<chi>. size \<chi> \<le> size \<phi> + size \<psi> \<Longrightarrow> P \<chi>) \<Longrightarrow> P (\<phi> \<and>\<^sup>d \<psi>)"
        and "\<And>y \<phi>. (\<And>\<psi>. size \<psi> \<le> size \<phi>             \<Longrightarrow> P \<psi>) \<Longrightarrow> P (\<exists>\<^sup>dy. \<phi>)"
        and "\<And>\<phi>.    (\<And>\<psi>. size \<psi> \<le> size \<phi>             \<Longrightarrow> P \<psi>) \<Longrightarrow> P (\<diamond>\<^sup>d\<phi>)"
      shows "P \<phi>"
    using assms proof (induct "size \<phi>" arbitrary: \<phi> rule: less_induct) case less thus ?case by (induct \<phi>) auto qed
\<comment>\<open>Stronger induction principle: structural for the propositional and modal cases, size-based for the existential.\<close>
  lemma QInduct:
    assumes "\<And>r u v. P (r\<^sup>d(u,v))"
        and "\<And>\<phi>.    P \<phi>             \<Longrightarrow> P (\<not>\<^sup>d\<phi>)"
        and "\<And>\<phi> \<psi>. P \<phi> \<Longrightarrow> P \<psi> \<Longrightarrow> P (\<phi> \<and>\<^sup>d \<psi>)"
        and "\<And>y \<phi>. (\<And>\<psi>. size \<psi> \<le> size \<phi> \<Longrightarrow> P \<psi>) \<Longrightarrow> P (\<exists>\<^sup>dy. \<phi>)"
        and "\<And>\<phi>.    P \<phi>             \<Longrightarrow> P (\<diamond>\<^sup>d\<phi>)"
      shows "P \<phi>"
    using assms by (induct \<phi> rule: SInduct) auto
  primrec modal_depth :: "\<F>\<Rightarrow>nat" where
      "modal_depth (r\<^sup>d(u,v)) = 0"
    | "modal_depth (\<not>\<^sup>d\<phi>)     = modal_depth \<phi>"
    | "modal_depth (\<phi> \<and>\<^sup>d \<psi>) = max (modal_depth \<phi>) (modal_depth \<psi>)"
    | "modal_depth (\<exists>\<^sup>dy. \<phi>) = (modal_depth \<phi>)"
    | "modal_depth (\<diamond>\<^sup>d\<phi>)     = (Suc (modal_depth \<phi>))"
\<comment>\<open>Substitutability predicate: z may safely replace x in \<phi> without capture; Box is transparent because it binds nothing.\<close>
  primrec SubstitutableForIn ("_ is'_subst'_for _ in _" [999,1,999] 999) where
      "z is_subst_for x in (r\<^sup>d(u,v)) = True"
    | "z is_subst_for x in (\<not>\<^sup>d\<phi>)     = (z is_subst_for x in \<phi>)"
    | "z is_subst_for x in (\<phi> \<and>\<^sup>d \<psi>) = (z is_subst_for x in \<phi> \<and> z is_subst_for x in \<psi>)"
    | "z is_subst_for x in (\<exists>\<^sup>dy. \<phi>) = (y = x \<or> (x not_free_in \<phi> \<or> y \<noteq> z) \<and> z is_subst_for x in \<phi>)"
    | "z is_subst_for x in (\<diamond>\<^sup>d\<phi>)     = (z is_subst_for x in \<phi>)"
\<comment>\<open>Substitution lemma: a syntactic z-for-x substitution corresponds semantically to updating the variable assignment.\<close>
  lemma SubstitutionLemma [simp]:
    assumes "z is_subst_for x in \<phi>"
    shows "(\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d ([x\<leftarrow>z](\<phi>))) = (\<langle>W,R,I,D\<rangle>,g[x\<leftarrow>(g z)],w \<Turnstile>\<^sup>d \<phi>)"
    using assms by (induction \<phi> arbitrary: g w; auto simp: L12 L2)
\<comment>\<open>Alphabetic renaming preparing unrestricted (capture-avoiding) substitution.\<close>
  fun ren_for_subst where
      "ren_for_subst x z (r\<^sup>d(u,v)) = r\<^sup>d(u,v)"
    | "ren_for_subst x z (\<not>\<^sup>d\<phi>)     = \<not>\<^sup>d(ren_for_subst x z \<phi>)"
    | "ren_for_subst x z (\<phi> \<and>\<^sup>d \<psi>) = (ren_for_subst x z \<phi> \<and>\<^sup>d ren_for_subst x z \<psi>)"
    | "ren_for_subst x z (\<exists>\<^sup>dy. \<phi>) =
        (if y = z \<and> x free_in \<phi>
         then let f = max (fresh \<phi>) (z+1); \<phi>' = [y\<leftarrow>f](\<phi>) in (\<exists>\<^sup>df. ren_for_subst x z \<phi>')
         else \<exists>\<^sup>dy. ren_for_subst x z \<phi>)"
    | "ren_for_subst x z (\<diamond>\<^sup>d\<phi>)     = \<diamond>\<^sup>d(ren_for_subst x z \<phi>)"
  lemma L17 [simp]: "size (ren_for_subst x z \<phi>) = size \<phi>" by (induct \<phi> arbitrary: z x rule: QInduct; simp add: Let_def)
  lemma L18: "\<alpha> not_in \<phi> \<Longrightarrow> \<alpha> is_subst_for \<beta> in \<phi>" by (induct \<phi>) auto
  lemma L19: "x free_in \<psi> \<Longrightarrow> y \<noteq> x \<Longrightarrow> x free_in [y\<leftarrow>z](\<psi>)" by (induct \<psi>) auto
  lemma L20 [simp]: "x free_in ren_for_subst x z \<phi> = (x free_in \<phi>)"
    by (induct \<phi> rule: QInduct; simp add: Let_def) (metis L16 L6 L7 L19 max.absorb3 max_def_raw)
  lemma L21: "(\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>) = (\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d (ren_for_subst x z \<phi>))" by (induct \<phi> arbitrary: z g w 
    rule: QInduct; simp add: Let_def; smt (verit) L12 L18 L2 L3 L5 L6 SubstitutionLemma max.strict_order_iff max_def)
  lemma L22: "z is_subst_for x in (ren_for_subst x z \<phi>)"  by (induct \<phi> rule: QInduct; simp; 
    metis L13 SubstitutableForIn.simps(4) Suc_n_not_le_n dual_order.refl max.cobounded2)
  lemma L26 [simp]: "z bound_in [x\<leftarrow>y](\<phi>) = z bound_in \<phi>"     by (induct \<phi>) auto
\<comment>\<open>Safe (capture-avoiding) substitution: rename first, then substitute.\<close>
  definition ren_subst ("[_ \<leftarrow>\<^sub>r _]'(_')") where "[x \<leftarrow>\<^sub>r z](\<phi>) = [x\<leftarrow>z](ren_for_subst x z \<phi>)"
  lemma L27 [simp]: "(\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d [x \<leftarrow>\<^sub>r z](\<phi>)) = (\<langle>W,R,I,D\<rangle>,g[x\<leftarrow>g z],w \<Turnstile>\<^sup>d \<phi>)" 
    using L21 L22 ren_subst_def by auto
  lemma L28 [simp]: "size ([x \<leftarrow>\<^sub>r z](\<phi>)) = size \<phi>" by (induct \<phi> rule: QInduct) (auto simp: ren_subst_def Let_def)
end





























