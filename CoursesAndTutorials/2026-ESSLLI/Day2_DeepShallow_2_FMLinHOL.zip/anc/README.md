# MinFMLinHOL — Isabelle/HOL sources

Isabelle/HOL development accompanying the paper

> **First-Order Modal Logic in HOL: Deep and Shallow Embeddings with
> Automated Faithfulness**
> Christoph Benzmüller and Daniel Kirchner
> ARQNL'26: International Workshop on Automated Reasoning in Quantified
> Non-Classical Logics, 2026.

This archive is the machine-checked artifact for the paper. It formalises
first-order modal logic (FML) with binary relational atoms, propositional
connectives, existential quantification, and the box modality, under
constant-domain Kripke semantics, and provides three embeddings of FML into
classical higher-order logic (HOL) — a deep embedding, a maximal-shallow
embedding, and a locale-based minimal-shallow embedding — together with
mechanised faithfulness proofs and a mechanisation of the (countable)
downward Löwenheim–Skolem theorem.

## Contents

| File | Description |
|------|-------------|
| `ROOT` | Isabelle session definition (session `MinFML`). |
| `MinFMLinHOL_preliminaries.thy` | Shared syntax, types, and notation. |
| `MinFMLinHOL_deep.thy` | Deep embedding: FML formulae as an inductive datatype with Kripke semantics. |
| `MinFMLinHOL_deep_subst_lemma.thy` | Substitution machinery for the deep embedding: free/bound/fresh predicates, capture-avoiding substitution, alphabetic renaming, the substitution lemma, and size-based induction principles. |
| `MinFMLinHOL_shallow.thy` | Maximal (heavyweight) shallow embedding. |
| `MinFMLinHOL_shallow_minimal_locale.thy` | Minimal-shallow embedding as the locale `MinS`, parametrised by an accessibility relation, world-indexed interpretation, universe of worlds, and variable assignment. |
| `MinFMLinHOL_shallow_minimal.thy` | Global (non-locale) instance of the minimal-shallow embedding. |
| `MinFMLinHOL_faithfulness_locale.thy` | Faithfulness between the deep and minimal-shallow embeddings, at the locale level. |
| `MinFMLinHOL_faithfulness.thy` | Global faithfulness theorem (`FaithfulMS_all`). |
| `MinFMLinHOL_ElementarySubstructure.thy` | Mechanisation of the countable downward Löwenheim–Skolem theorem (Tarski–Vaught construction) resolving the surjectivity problem over uncountable domains. |
| `MinFMLinHOL_experiments.thy` | Worked examples (tautologies, K-axiom, necessitation, Barcan/converse-Barcan, `nitpick` countermodels) in all three embeddings. |
| `MinFMLinHOL_experiments_locale.thy` | Locale-based transfer experiments. |

Line numbers cited in the paper refer to positions in these theory files.

## Building

The development builds under recent releases of Isabelle/HOL
(<https://isabelle.in.tum.de>). It depends only on `Main`,
`HOL-Library`, and `HOL-Library.Countable_Set`, all shipped with Isabelle.

From the directory containing this README:

```sh
isabelle build -D .
```

To browse interactively, open any theory file in Isabelle/jEdit, e.g.:

```sh
isabelle jedit -d . MinFMLinHOL_faithfulness.thy
```

The session `MinFML` (see `ROOT`) checks all theory files.

## Citation

These files are distributed as *ancillary files* of the extended
version of the accompanying paper on arXiv. If you use this
development, please cite that paper (arXiv identifier and DOI are shown
on the arXiv abstract page).

## License

Released under the Creative Commons Attribution 4.0 International
(CC BY 4.0) license; see `LICENSE`.
