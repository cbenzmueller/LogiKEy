theory MinFMLinHOL_ElementarySubstructure
  imports MinFMLinHOL_deep_subst_lemma "HOL-Library.Countable_Set" MinFMLinHOL_shallow_minimal_locale
begin
  primrec \<A>equivn :: \<open>\<A> \<Rightarrow> \<A> \<Rightarrow> w \<Rightarrow> nat \<Rightarrow> bool\<close> where
    "\<A>equivn R R' w 0 = (\<forall>v . R w v = R' w v)"
  | "\<A>equivn R R' w (Suc n) = (\<A>equivn R R' w n \<and> (\<forall>v . (R w v \<or> R' w v) \<longrightarrow> \<A>equivn R R' v n))"
  lemma \<A>equivnI:
    assumes "\<And>m v v' . m \<le> n \<Longrightarrow> (R^^m) w v \<Longrightarrow> R v v' = R' v v'"
    shows "\<A>equivn R R' w n"
    using assms apply (induct n arbitrary: w)
     apply simp
    apply auto
    using le_SucI apply blast
    apply (metis not_less_eq_eq relpowp_Suc_I2)
    by (metis Suc_le_mono relpowp_0_I relpowp_Suc_I2 zero_le)
  lemma L4:
    assumes "\<A>equivn R R' w (modal_depth \<phi>)"
    shows "(\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>) = (\<langle>W,R',I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>)"
    using assms
    apply(induct \<phi> arbitrary: g w) apply simp apply simp
    apply (smt RelativeTruthD.simps \<A>equivn.simps inc_induct max.cobounded1 max.cobounded2 modal_depth.simps)
    apply simp
    by (smt (verit, del_insts) RelativeTruthD.simps \<A>equivn.simps modal_depth.simps zero_induct)
\<comment>\<open>The countable downward Loewenheim-Skolem theorem for FML, mechanised.\<close>
  instance \<F> :: countable by countable_datatype
\<comment>\<open>Coincidence-of-assignments lemma: relative truth depends only on the values of the assignment on free variables.\<close>
  lemma L1: assumes "\<forall>x. x free_in \<phi> \<longrightarrow> g x = g' x" shows "(\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>) = (\<langle>W,R,I,D\<rangle>,g',w \<Turnstile>\<^sup>d \<phi>)"
    using assms by (induct \<phi> arbitrary: g g' w; simp) (blast, smt (verit) EnvMod_def, blast)
\<comment>\<open>Restricted assignments: partial maps from variables to D,\<close>
  definition restricted_assigns :: "\<F> \<Rightarrow> \<D> \<Rightarrow> (V\<rightharpoonup>D) set" where
    "restricted_assigns \<equiv> \<lambda>\<phi> D. map_of ` (lists ({x. x free_in \<phi>} \<times> Collect D))"
  lemma finite_frees: "finite {x. x free_in \<phi>}" by (induct \<phi>) auto
  definition restrict_assign :: "\<F> \<Rightarrow> (V \<Rightarrow> D) \<Rightarrow> (V\<rightharpoonup>D)" where
    "restrict_assign \<equiv> \<lambda>\<phi> g x. if x free_in \<phi> then Some (g x) else None"
  lemma restrict_assign_in_assigns:
    assumes "g ` {x. x free_in \<phi>} \<subseteq> Collect D" shows "restrict_assign \<phi> g \<in> restricted_assigns \<phi> D"
    proof -
      let ?map = "map (\<lambda>x. (x,g x)) (sorted_list_of_set {x. x free_in \<phi>})"
      have "?map \<in> lists ({x. x free_in \<phi>} \<times> Collect D)"     using assms finite_frees by fastforce
      moreover have "restrict_assign \<phi> g = map_of ?map"
        unfolding map_of_map_restrict restrict_assign_def using finite_frees by fastforce
      ultimately show ?thesis unfolding restricted_assigns_def by auto
    qed
  lemma countable_restricted_assigns: "countable (Collect S) \<Longrightarrow> countable (restricted_assigns \<phi> S)"
    by (simp add: restricted_assigns_def)
  definition unrestrict :: "(V\<Rightarrow>D option)\<Rightarrow>(V\<Rightarrow>D)" where "unrestrict \<equiv> \<lambda>g x. case g x of Some y \<Rightarrow> y | _ \<Rightarrow> undefined"
  lemma unrestrict_restrict_assign[simp]: "unrestrict (restrict_assign \<phi> g) x = (if x free_in \<phi> then g x else undefined)"
    by (simp add: restrict_assign_def unrestrict_def)
\<comment>\<open>Generic Hilbert-choice witness for a satisfiable predicate; specialised to the existential and the modal case below.\<close>
  definition witness :: "('a \<Rightarrow> bool) \<Rightarrow> 'a option" where
    "witness P \<equiv> if Ex P then Some (SOME z. P z) else None"
  lemma witness_ex: "Ex P \<Longrightarrow> \<exists>x. Some x = witness P" by (simp add: witness_def)
  lemma witness_prop: "Some x = witness P \<Longrightarrow> P x"
    by (metis option.distinct(1) option.inject someI_ex witness_def)
  definition existential_witness :: "\<W> \<Rightarrow> \<A> \<Rightarrow> \<I> \<Rightarrow> \<D> \<Rightarrow> (V \<rightharpoonup> D) \<Rightarrow> w \<Rightarrow> V \<Rightarrow> \<F> \<rightharpoonup> D" where
    "existential_witness W R I D g w y \<phi> \<equiv> witness (\<lambda>x. D x \<and> \<langle>W,R,I,D\<rangle>,unrestrict g[y \<leftarrow> x],w \<Turnstile>\<^sup>d \<phi>)"
  definition modal_witness :: "\<W> \<Rightarrow> \<A> \<Rightarrow> \<I> \<Rightarrow> \<D> \<Rightarrow> (V \<rightharpoonup> D) \<Rightarrow> w \<Rightarrow> \<F> \<rightharpoonup> w" where
    "modal_witness W R I D g w \<phi> \<equiv> witness (\<lambda>v. W v \<and> R w v \<and> \<langle>W,R,I,D\<rangle>,unrestrict g,v \<Turnstile>\<^sup>d \<phi>)"
  lemma existential_witness_I:
    assumes "\<langle>W,R,I,D\<rangle>,unrestrict g,w \<Turnstile>\<^sup>d \<exists>\<^sup>dy. \<phi>"
    obtains x where "Some x = existential_witness W R I D g w y \<phi>"
    by (metis (no_types, lifting) RelativeTruthD.simps(4) assms existential_witness_def
        witness_ex)
  lemma existential_witness_E2:
    assumes "Some x = existential_witness W R I D g w y \<phi>"
    shows "D x \<and> \<langle>W,R,I,D\<rangle>,unrestrict g[y \<leftarrow> x],w \<Turnstile>\<^sup>d \<phi>"
    by (metis (no_types, lifting) assms existential_witness_def witness_prop)
  lemma modal_witness_I:
    assumes "\<langle>W,R,I,D\<rangle>,unrestrict g,w \<Turnstile>\<^sup>d \<diamond>\<^sup>d\<phi>"
    obtains x where "Some x = modal_witness W R I D g w \<phi>"
    by (metis (no_types, lifting) assms modal_witness_def witness_ex RelativeTruthD.simps(5))
  lemma modal_witness_E2:
    assumes "Some v = modal_witness W R I D g w \<phi>"
    shows "W v \<and> R w v \<and> \<langle>W,R,I,D\<rangle>,unrestrict g,v \<Turnstile>\<^sup>d \<phi>"
    by (metis (no_types, lifting) assms modal_witness_def witness_prop)
  definition existential_witnesses :: "\<D> \<Rightarrow> \<W> \<Rightarrow> \<W> \<Rightarrow> \<A> \<Rightarrow> \<I> \<Rightarrow> \<D> \<Rightarrow> \<D>" where
    "existential_witnesses D\<^sub>0 W\<^sub>0 W R I D x \<equiv> (\<exists> \<phi> y g w .
      W\<^sub>0 w \<and> g \<in> restricted_assigns \<phi> D\<^sub>0 \<and> Some x = existential_witness W R I D g w y \<phi>)"
  lemma existential_witnesses_countable:
    assumes "countable (Collect D\<^sub>0)" and "countable (Collect W\<^sub>0)"
    shows "countable (Collect (existential_witnesses D\<^sub>0 W\<^sub>0 W R I D))" (is "countable ?set")
  proof -
    have "?set \<subseteq> (\<lambda> ((\<phi>,g),y,w) . the (existential_witness W R I D g w y \<phi>)) `
        ((SIGMA \<phi>:UNIV. restricted_assigns \<phi> D\<^sub>0)\<times>UNIV\<times>Collect W\<^sub>0)"
      unfolding existential_witness_def witness_def existential_witnesses_def image_def
      by simp blast
    thus ?thesis
      using countable_subset countable_image
      by (auto simp add: assms(1,2) countable_restricted_assigns intro: countable_subset)
  qed
  lemma existential_witnesses_subset:
    "existential_witnesses D\<^sub>0 W\<^sub>0 W R I D \<^bold>\<subseteq> D"
    by (meson existential_witness_E2 existential_witnesses_def)
  definition modal_witnesses :: "\<D> \<Rightarrow> \<W> \<Rightarrow> \<W> \<Rightarrow> \<A> \<Rightarrow> \<I> \<Rightarrow> \<D> \<Rightarrow> \<W>" where
    "modal_witnesses D\<^sub>0 W\<^sub>0 W R I D v \<equiv> (\<exists> \<phi> g w .
      W\<^sub>0 w \<and> g \<in> restricted_assigns \<phi> D\<^sub>0 \<and> Some v = modal_witness W R I D g w \<phi>)"
  lemma modal_witnesses_countable:
    assumes "countable (Collect D\<^sub>0)" and "countable (Collect W\<^sub>0)"
    shows "countable (Collect (modal_witnesses D\<^sub>0 W\<^sub>0 W R I D))" (is "countable ?set")
  proof -
    have "?set \<subseteq> (\<lambda> ((\<phi>,g),w) . the (modal_witness W R I D g w \<phi>)) ` ((SIGMA \<phi>:UNIV. restricted_assigns \<phi> D\<^sub>0)\<times>Collect W\<^sub>0)"
      unfolding modal_witness_def witness_def modal_witnesses_def image_def
      by simp blast
    thus ?thesis
      using countable_subset countable_image
      by (auto simp add: assms(1,2) countable_restricted_assigns intro: countable_subset)
  qed
  lemma modal_witnesses_subset:
    "modal_witnesses D\<^sub>0 W\<^sub>0 W R I D \<^bold>\<subseteq> W"
    by (meson modal_witness_E2 modal_witnesses_def)
  fun \<N>\<^sub>i :: "\<D>\<Rightarrow>\<W>\<Rightarrow>\<W>\<Rightarrow>\<A>\<Rightarrow>\<I>\<Rightarrow>\<D>\<Rightarrow>nat\<Rightarrow>\<D>" and \<W>\<^sub>i :: "\<D>\<Rightarrow>\<W>\<Rightarrow>\<W>\<Rightarrow>\<A>\<Rightarrow>\<I>\<Rightarrow>\<D>\<Rightarrow>nat\<Rightarrow>\<W>" where
    "\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D 0 = D\<^sub>0"
  | "\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D (Suc n) = \<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n \<^bold>\<union> existential_witnesses (\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n) (\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n) W R I D"
  | "\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D 0 = W\<^sub>0"
  | "\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D (Suc n) = \<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n \<^bold>\<union> modal_witnesses (\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n) (\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n) W R I D"
  lemma
    assumes "countable (Collect D\<^sub>0)" and "countable (Collect W\<^sub>0)"
    shows countable_\<N>\<^sub>i: "countable (Collect (\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n))"
      and countable_\<W>\<^sub>i: "countable (Collect (\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n))"
    by (atomize (full))
       (insert assms; induct n; simp add: Collect_disj_eq existential_witnesses_countable modal_witnesses_countable)
  lemma D\<^sub>0_in_\<N>\<^sub>i: "D\<^sub>0 \<^bold>\<subseteq> \<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n"
    and W\<^sub>0_in_\<W>\<^sub>i: "W\<^sub>0 \<^bold>\<subseteq> \<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n"
    by (atomize (full)) (induct n; auto)
  lemma \<N>\<^sub>i_increasing: "\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n \<^bold>\<subseteq> \<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D (Suc n)"
    and \<W>\<^sub>i_increasing: "\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n \<^bold>\<subseteq> \<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D (Suc n)"
    by simp_all
  lemma \<N>\<^sub>i_monotone: "n \<le> m \<Longrightarrow> \<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n \<^bold>\<subseteq> \<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D m"
    by (induct "m - n" arbitrary: n m, simp)
       (metis Nat.le_imp_diff_is_add \<N>\<^sub>i_increasing add_Suc le_add2)
  lemma \<W>\<^sub>i_monotone: "n \<le> m \<Longrightarrow> \<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n \<^bold>\<subseteq> \<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D m"
    by (induct "m - n" arbitrary: n m, simp)
       (metis Nat.le_imp_diff_is_add \<W>\<^sub>i_increasing add_Suc le_add2)
  lemma \<N>\<^sub>i_subset: "\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n \<^bold>\<subseteq> D\<^sub>0 \<^bold>\<union> D"
    and \<W>\<^sub>i_subset: "\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n \<^bold>\<subseteq> W\<^sub>0 \<^bold>\<union> W"
    by (atomize (full))
       (induct n; simp; metis existential_witnesses_subset modal_witnesses_subset)
  definition \<N> :: "\<D>\<Rightarrow>\<W>\<Rightarrow>\<W>\<Rightarrow>\<A>\<Rightarrow>\<I>\<Rightarrow>\<D>\<Rightarrow>\<D>" where
    "\<N> D\<^sub>0 W\<^sub>0 W R I D x \<equiv> \<exists> n . \<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n x"
  definition \<W> :: "\<D>\<Rightarrow>\<W>\<Rightarrow>\<W>\<Rightarrow>\<A>\<Rightarrow>\<I>\<Rightarrow>\<D>\<Rightarrow>\<W>" where
    "\<W> D\<^sub>0 W\<^sub>0 W R I D w \<equiv> \<exists> n . \<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n w"
  lemma assumes "countable (Collect D\<^sub>0)" and "countable (Collect W\<^sub>0)"
    shows countable_\<N>: "countable (Collect (\<N> D\<^sub>0 W\<^sub>0 W R I D))"
      and countable_\<W>: "countable (Collect (\<W> D\<^sub>0 W\<^sub>0 W R I D))"
    unfolding \<N>_def \<W>_def
    by (auto simp: Collect_ex_eq assms(1,2) countable_\<N>\<^sub>i countable_\<W>\<^sub>i)
  lemma \<N>_subset: "\<N> D\<^sub>0 W\<^sub>0 W R I D \<^bold>\<subseteq> D\<^sub>0 \<^bold>\<union> D"
    by (metis \<N>\<^sub>i_subset \<N>_def)
  lemma W\<^sub>0_in_\<W>: "W\<^sub>0 \<^bold>\<subseteq> \<W> D\<^sub>0 W\<^sub>0 W R I D"
    by (metis \<W>_def W\<^sub>0_in_\<W>\<^sub>i)
  lemma \<W>_subset: "\<W> D\<^sub>0 W\<^sub>0 W R I D \<^bold>\<subseteq> W\<^sub>0 \<^bold>\<union> W"
    by (metis \<W>\<^sub>i_subset \<W>_def)
  lemma range_EnvMod: "g into D \<Longrightarrow> D v \<Longrightarrow> g[x\<leftarrow>v] into D" using EnvMod_def by auto
  lemma TarskiVaught:
    assumes "D' \<^bold>\<subseteq>  D" and "W' \<^bold>\<subseteq> W"
      and "g into D'"
      and "W' w"
      and "\<And>w g x \<phi>. W' w \<Longrightarrow> g into D' \<Longrightarrow> \<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d (\<exists>\<^sup>dx. \<phi>) \<Longrightarrow> \<exists>v:D'. \<langle>W,R,I,D\<rangle>,g[x\<leftarrow>v],w \<Turnstile>\<^sup>d \<phi>"
      and "\<And>w g \<phi>. W' w \<Longrightarrow> g into D' \<Longrightarrow> \<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d (\<diamond>\<^sup>d\<phi>) \<Longrightarrow> \<exists>v:W'. R w v \<and> \<langle>W,R,I,D\<rangle>,g,v \<Turnstile>\<^sup>d \<phi>"
    shows "\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi> = \<langle>W',R,I,D'\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>"
    using assms by ((induct \<phi> arbitrary: g w; simp), metis range_EnvMod, metis)
  definition ElementarySubstructure ("\<langle>_,_,_,_\<rangle> \<subseteq>\<^sub>E \<langle>_,_,_,_\<rangle>") where
    "\<langle>W',R',I',D'\<rangle> \<subseteq>\<^sub>E \<langle>W,R,I,D\<rangle> \<equiv> W' \<^bold>\<subseteq> W \<and> D' \<^bold>\<subseteq>  D \<and> (\<forall> w g \<phi> . W' w \<longrightarrow> g into D' \<longrightarrow>
        \<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi> = \<langle>W',R',I',D'\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>)"
  lemma all_free_in_\<N>\<^sub>i:
      assumes "g into \<N> D\<^sub>0 W\<^sub>0 W R I D"
      shows "\<exists>n. \<forall>y. y free_in \<phi> \<longrightarrow> \<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n (g y)" (is "\<exists>n.\<forall>y. _ \<longrightarrow> ?\<N> n (g y)")
    by (safe intro!: exI[where x="Max ((\<lambda>y. LEAST n. \<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n (g y)) ` {y. y free_in \<phi>})"])
       (metis (mono_tags) LeastI_ex Max_ge \<N>\<^sub>i_monotone \<N>_def assms finite_frees finite_imageI imageI mem_Collect_eq)
\<comment>\<open>Common setup shared by the two Tarski--Vaught cases: a stage index n at which the
   finite restriction of g lands and which already contains the world w.\<close>
  lemma stage_bound:
    assumes "\<W> D\<^sub>0 W\<^sub>0 W R I D w" and "g into \<N> D\<^sub>0 W\<^sub>0 W R I D"
    obtains n where "restrict_assign \<phi> g \<in> restricted_assigns \<phi> (\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n)"
                and "\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n w"
  proof -
    from assms(1) obtain n_w where n_w: "\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n_w w" using \<W>_def by blast
    from assms(2) obtain n_d where n_d: "\<And>y. y free_in \<phi> \<Longrightarrow> \<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n_d (g y)"
      using all_free_in_\<N>\<^sub>i by blast
    define n where "n = max n_w n_d"
    have "restrict_assign \<phi> g \<in> restricted_assigns \<phi> (\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n)"
      by (metis n_d n_def \<N>\<^sub>i_monotone image_Collect_subsetI max.cobounded2 mem_Collect_eq restrict_assign_in_assigns)
    moreover have "\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n w"
      by (simp add: \<W>\<^sub>i_monotone max_def n_def n_w)
    ultimately show thesis using that by blast
  qed
\<comment>\<open>Existential witnesses lie in the limit domain \<N> (Tarski--Vaught, existential case).\<close>
  lemma ex_witness_in_limit:
    assumes "\<W> D\<^sub>0 W\<^sub>0 W R I D w" and "g into \<N> D\<^sub>0 W\<^sub>0 W R I D"
      and "\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<exists>\<^sup>dx. \<phi>"
    shows "\<exists>d. \<N> D\<^sub>0 W\<^sub>0 W R I D d \<and> \<langle>W,R,I,D\<rangle>,g[x\<leftarrow>d],w \<Turnstile>\<^sup>d \<phi>"
  proof -
    obtain n where 0: "restrict_assign \<phi> g \<in> restricted_assigns \<phi> (\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n)"
      and Wn: "\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n w" using assms(1,2) by (rule stage_bound)
    from assms(3) have "\<langle>W,R,I,D\<rangle>,unrestrict (restrict_assign \<phi> g),w \<Turnstile>\<^sup>d \<exists>\<^sup>dx. \<phi>"
      by (metis L1 is_free.simps(4) unrestrict_restrict_assign)
    then obtain d where d: "Some d = existential_witness W R I D (restrict_assign \<phi> g) w x \<phi>"
      by (rule existential_witness_I)
    hence "\<langle>W,R,I,D\<rangle>,unrestrict (restrict_assign \<phi> g)[x\<leftarrow>d],w \<Turnstile>\<^sup>d \<phi>"
      using existential_witness_E2 by auto
    hence "\<langle>W,R,I,D\<rangle>,g[x\<leftarrow>d],w \<Turnstile>\<^sup>d \<phi>"
      by (smt (verit, ccfv_SIG) EnvMod_def L1 unrestrict_restrict_assign)
    moreover have "existential_witnesses (\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n) (\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n) W R I D d"
      unfolding existential_witnesses_def using 0 d Wn by blast
    hence "\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D (Suc n) d" by auto
    ultimately show ?thesis using \<N>_def by blast
  qed
\<comment>\<open>Modal witnesses lie in the limit world set \<W> (Tarski--Vaught, diamond case).\<close>
  lemma modal_witness_in_limit:
    assumes "\<W> D\<^sub>0 W\<^sub>0 W R I D w" and "g into \<N> D\<^sub>0 W\<^sub>0 W R I D"
      and "\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<diamond>\<^sup>d\<phi>"
    shows "\<exists>v. \<W> D\<^sub>0 W\<^sub>0 W R I D v \<and> R w v \<and> \<langle>W,R,I,D\<rangle>,g,v \<Turnstile>\<^sup>d \<phi>"
  proof -
    obtain n where 0: "restrict_assign \<phi> g \<in> restricted_assigns \<phi> (\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n)"
      and Wn: "\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n w" using assms(1,2) by (rule stage_bound)
    from assms(3) have "\<langle>W,R,I,D\<rangle>,unrestrict (restrict_assign \<phi> g),w \<Turnstile>\<^sup>d \<diamond>\<^sup>d\<phi>"
      by (metis L1 is_free.simps(5) unrestrict_restrict_assign)
    then obtain v where v: "Some v = modal_witness W R I D (restrict_assign \<phi> g) w \<phi>"
      by (rule modal_witness_I)
    hence "R w v \<and> \<langle>W,R,I,D\<rangle>,unrestrict (restrict_assign \<phi> g),v \<Turnstile>\<^sup>d \<phi>"
      using modal_witness_E2 by blast
    moreover have "\<langle>W,R,I,D\<rangle>,g,v \<Turnstile>\<^sup>d \<phi>"
      by (metis calculation L1 unrestrict_restrict_assign)
    moreover have "modal_witnesses (\<N>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n) (\<W>\<^sub>i D\<^sub>0 W\<^sub>0 W R I D n) W R I D v"
      unfolding modal_witnesses_def using 0 v Wn by blast
    ultimately show ?thesis by (meson \<W>\<^sub>i.simps(2) \<W>_def)
  qed
  theorem \<N>_valid: assumes "D\<^sub>0 \<^bold>\<subseteq> D" and "W\<^sub>0 \<^bold>\<subseteq> W" and "g into \<N> D\<^sub>0 W\<^sub>0 W R I D" and "\<W> D\<^sub>0 W\<^sub>0 W R I D w"
    shows "\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi> = \<langle>\<W> D\<^sub>0 W\<^sub>0 W R I D,R,I,\<N> D\<^sub>0 W\<^sub>0 W R I D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>"
  proof -
    have "\<N> D\<^sub>0 W\<^sub>0 W R I D \<^bold>\<subseteq> D"
      by (metis assms(1) \<N>_def \<N>\<^sub>i_subset)
    moreover have "\<W> D\<^sub>0 W\<^sub>0 W R I D \<^bold>\<subseteq> W"
      by (metis assms(2) \<W>_subset)
    ultimately show ?thesis using assms(3,4)
    proof (rule TarskiVaught)
      fix g :: \<E> and w x \<phi>
      assume a: "\<W> D\<^sub>0 W\<^sub>0 W R I D w" and b: "g into \<N> D\<^sub>0 W\<^sub>0 W R I D"
      assume "\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<exists>\<^sup>dx. \<phi>"
      thus "\<exists>y. \<N> D\<^sub>0 W\<^sub>0 W R I D y \<and> \<langle>W,R,I,D\<rangle>,g[x \<leftarrow> y],w \<Turnstile>\<^sup>d \<phi>"
        using ex_witness_in_limit[OF a b] by blast
    next
      fix g :: \<E> and w \<phi>
      assume a: "\<W> D\<^sub>0 W\<^sub>0 W R I D w" and b: "g into \<N> D\<^sub>0 W\<^sub>0 W R I D"
      assume "\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<diamond>\<^sup>d\<phi>"
      thus "\<exists>v. \<W> D\<^sub>0 W\<^sub>0 W R I D v \<and> R w v \<and> \<langle>W,R,I,D\<rangle>,g,v \<Turnstile>\<^sup>d \<phi>"
        using modal_witness_in_limit[OF a b] by blast
    qed
  qed
  lemma ElementarySubstructure\<W>\<D>:
    assumes "D\<^sub>0 \<^bold>\<subseteq> D" and "W\<^sub>0 \<^bold>\<subseteq> W"
    shows "\<langle>\<W> D\<^sub>0 W\<^sub>0 W R I D,R,I,\<N> D\<^sub>0 W\<^sub>0 W R I D\<rangle> \<subseteq>\<^sub>E \<langle>W,R,I,D\<rangle>"
    unfolding ElementarySubstructure_def
    by (metis assms(1) assms(2) \<N>_subset \<N>_valid \<W>_subset)
\<comment>\<open>The downward Loewenheim-Skolem theorem for FML.\<close>
  theorem DownwardLowenheimSkolem:
    assumes "D\<^sub>0 \<^bold>\<subseteq> D" and "W\<^sub>0 \<^bold>\<subseteq> W" and "countable (Collect D\<^sub>0)" and "countable (Collect W\<^sub>0)"
    shows "\<exists>N W'. D\<^sub>0 \<^bold>\<subseteq> N \<and> N \<^bold>\<subseteq> D \<and> countable (Collect N) \<and> W\<^sub>0 \<^bold>\<subseteq> W' \<and> W' \<^bold>\<subseteq> W \<and> countable (Collect W')
                  \<and> (\<forall>g \<phi> w. W' w \<longrightarrow> g into N \<longrightarrow> (\<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>) = (\<langle>W',R,I,N\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>))"
    apply (safe intro!: exI[where x="\<N> D\<^sub>0 W\<^sub>0 W R I D"] exI[where x="\<W> D\<^sub>0 W\<^sub>0 W R I D"])
    apply (metis \<N>_def D\<^sub>0_in_\<N>\<^sub>i)
    apply (metis assms(1) \<N>_subset)
    apply (metis assms(3) assms(4) countable_\<N>)
    apply (simp add: W\<^sub>0_in_\<W>)
    apply (metis assms(2) \<W>_subset)
    apply (metis assms(4) assms(3) countable_\<W>)
    using \<N>_valid assms(1,2) apply blast
    by (metis assms(2) assms(1) \<N>_valid)
  locale MinS_ES = MinS + fixes WW'::\<W> and DD::\<D>
    assumes ES: "\<langle>WW,RR,II,Range gg\<rangle> \<subseteq>\<^sub>E \<langle>WW',RR,II,DD\<rangle>"
  begin
    lemma \<N>_valid_ES: "WW w \<Longrightarrow> \<langle>WW',RR,II,DD\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi> = \<langle>WW,RR,II,Range gg\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi>"
      using ES ElementarySubstructure_def by fastforce
  end
  locale MinS_ES_Univ = MinS_ES RR II gg WW Univ Univ for RR II gg WW
  lemma gg_ex:
    assumes "\<exists>x. D\<^sub>0 x" and "countable (Collect D\<^sub>0)" and "countable (Collect W\<^sub>0)"
    shows "\<exists>gg::\<E>. gg onto \<N> D\<^sub>0 W\<^sub>0 W R I D"
    by (rule exI[where x="from_nat_into (Collect (\<N> D\<^sub>0 W\<^sub>0 W R I D))"])
       (metis D\<^sub>0_in_\<N>\<^sub>i \<N>_def assms(1,2,3) countable_\<N> empty_iff from_nat_into from_nat_into_surj
        mem_Collect_eq)
  lemma restrict_R: "W w \<Longrightarrow> \<langle>W,R,I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi> = \<langle>W,(\<lambda> v v' . W v \<and> W v' \<and> R v v'),I,D\<rangle>,g,w \<Turnstile>\<^sup>d \<phi>"
    by (induct \<phi> arbitrary: g w) auto
  locale MinS_specific =
    fixes R\<^sub>0::\<A> and I\<^sub>0::\<I> and W\<^sub>0::\<W> and D\<^sub>0::\<D> and g\<^sub>0::\<E> and \<phi>::\<F> and w::w
    assumes g\<^sub>0_in_D\<^sub>0: "g\<^sub>0 into D\<^sub>0" and w_in_W\<^sub>0: "W\<^sub>0 w"
  begin
    definition DD\<^sub>0 :: "\<D>" where "DD\<^sub>0 y \<equiv> (\<exists>x. x < fresh(\<phi>) \<and> y = g\<^sub>0 x) \<or> y = (SOME x. D\<^sub>0 x)"
    lemma DD\<^sub>0_in_DD: "DD\<^sub>0 \<^bold>\<subseteq> D\<^sub>0" by (metis DD\<^sub>0_def g\<^sub>0_in_D\<^sub>0 verit_sko_ex')
    lemma DD\<^sub>0_countable: "countable (Collect DD\<^sub>0)" by (unfold DD\<^sub>0_def; auto intro!: countable_finite)
    definition RR::\<A> where "RR x y \<equiv> (if \<exists>n\<le>modal_depth \<phi>. (R\<^sub>0^^n) w x then W\<^sub>0 y \<and> R\<^sub>0 x y else False)"
    definition WW\<^sub>0 where "WW\<^sub>0 \<equiv> (\<W> DD\<^sub>0 (((=) w)) W\<^sub>0 R\<^sub>0 I\<^sub>0 D\<^sub>0)"
    lemma WW\<^sub>0_in_W\<^sub>0: "WW\<^sub>0 \<^bold>\<subseteq> W\<^sub>0"
      unfolding WW\<^sub>0_def
      using \<W>_subset w_in_W\<^sub>0 by blast
    lemma WW\<^sub>0_countable: "countable (Collect WW\<^sub>0)"
      by (simp add: DD\<^sub>0_countable WW\<^sub>0_def countable_\<W>)
    definition WW where "WW \<equiv> \<W> DD\<^sub>0 WW\<^sub>0 W\<^sub>0 RR I\<^sub>0 D\<^sub>0"
    definition DD where "DD \<equiv> \<N> DD\<^sub>0 WW\<^sub>0 W\<^sub>0 RR I\<^sub>0 D\<^sub>0"
    lemma ES: "\<langle>WW,RR,I\<^sub>0,DD\<rangle> \<subseteq>\<^sub>E \<langle>W\<^sub>0,RR,I\<^sub>0,D\<^sub>0\<rangle>"
      by (simp add: DD_def DD\<^sub>0_in_DD ElementarySubstructure\<W>\<D> WW_def WW\<^sub>0_in_W\<^sub>0)
    definition gg where "gg \<equiv> SOME gg. (\<forall>x. x free_in \<phi> \<longrightarrow> gg x = g\<^sub>0 x) \<and> gg onto \<N> DD\<^sub>0 WW\<^sub>0 W\<^sub>0 RR I\<^sub>0 D\<^sub>0"
    lemma gg_g\<^sub>0: "(\<forall>x. x free_in \<phi> \<longrightarrow> gg x = g\<^sub>0 x)" and  gg_surj: "gg onto \<N> DD\<^sub>0 WW\<^sub>0 W\<^sub>0 RR I\<^sub>0 D\<^sub>0"
      proof -
        have DD\<^sub>0_nonempty: "\<exists>x. DD\<^sub>0 x" using DD\<^sub>0_def by fastforce
        then obtain gg\<^sub>0 ::\<E> where gg\<^sub>0: "gg\<^sub>0 onto \<N> DD\<^sub>0 WW\<^sub>0 W\<^sub>0 RR I\<^sub>0 D\<^sub>0" using gg_ex DD\<^sub>0_countable
          by (metis WW\<^sub>0_countable)
        define gg' where "gg' \<equiv> \<lambda>x. if x < fresh(\<phi>) then g\<^sub>0 x else gg\<^sub>0 (x - fresh(\<phi>))"
        have ex: "\<exists>gg::\<E>. (\<forall>x. x free_in \<phi> \<longrightarrow> gg x = g\<^sub>0 x) \<and> gg onto \<N> DD\<^sub>0 WW\<^sub>0 W\<^sub>0 RR I\<^sub>0 D\<^sub>0"
          apply (safe intro!: exI[where x=gg'])
           apply (metis gg'_def L6)
          by (metis DD\<^sub>0_def \<N>\<^sub>i.simps(1) \<N>_def add_diff_cancel_right' gg'_def gg\<^sub>0 not_add_less2)
        show "\<forall>x. x free_in \<phi> \<longrightarrow> gg x = g\<^sub>0 x" and "gg onto \<N> DD\<^sub>0 WW\<^sub>0 W\<^sub>0 RR I\<^sub>0 D\<^sub>0"
          using someI_ex[OF ex] unfolding gg_def by auto
      qed
    lemma ES': "\<langle>WW,RR,I\<^sub>0,Range gg\<rangle> \<subseteq>\<^sub>E \<langle>W\<^sub>0,RR,I\<^sub>0,D\<^sub>0\<rangle>"
      using DD_def ES gg_surj by simp
    sublocale MinS_ES RR I\<^sub>0 gg WW W\<^sub>0 D\<^sub>0
      apply standard using ES'.
    lemma w_in_WW: "WW w"
        using WW_def WW\<^sub>0_def W\<^sub>0_in_\<W> by simp
    lemma valid_specific: "\<langle>WW,RR,I\<^sub>0,Range gg\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi> \<equiv> \<langle>W\<^sub>0,R\<^sub>0,I\<^sub>0,D\<^sub>0\<rangle>,g\<^sub>0,w \<Turnstile>\<^sup>d \<phi>"
    proof -
      have "\<langle>WW,RR,I\<^sub>0,Range gg\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi> = \<langle>W\<^sub>0,RR,I\<^sub>0,D\<^sub>0\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi>"
        using w_in_WW DD_def gg_surj \<N>_valid_ES by simp
      also have "\<dots> = \<langle>W\<^sub>0,(\<lambda> x y . W\<^sub>0 y \<and> R\<^sub>0 x y),I\<^sub>0,D\<^sub>0\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi>"
        by (rule L4) (smt (verit, best) RR_def \<A>equivnI relpowp_mono)
      also have "\<dots> = \<langle>W\<^sub>0,R\<^sub>0,I\<^sub>0,D\<^sub>0\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi>"
        by (smt (verit, ccfv_SIG) MinFMLinHOL_ElementarySubstructure.L4 \<A>equivnI restrict_R w_in_W\<^sub>0)
      also have "\<dots> = \<langle>W\<^sub>0,R\<^sub>0,I\<^sub>0,D\<^sub>0\<rangle>,g\<^sub>0,w \<Turnstile>\<^sup>d \<phi>"
        using L1 gg_g\<^sub>0 by blast
      finally show "\<langle>WW,RR,I\<^sub>0,Range gg\<rangle>,gg,w \<Turnstile>\<^sup>d \<phi> \<equiv> \<langle>W\<^sub>0,R\<^sub>0,I\<^sub>0,D\<^sub>0\<rangle>,g\<^sub>0,w \<Turnstile>\<^sup>d \<phi>" by argo
    qed
  end
end






























