theory ModalS5_Example
  imports Main

begin

(* \<midarrow>\<midarrow> Types \<midarrow>\<midarrow> *)
typedecl i                          (* possible worlds *)
type_synonym \<sigma> = "i \<Rightarrow> bool"        (* propositions as world-lifted predicates *)

(* \<midarrow>\<midarrow> Accessibility relation: S5 = equivalence relation \<midarrow>\<midarrow> *)
consts r :: "i \<Rightarrow> i \<Rightarrow> bool"         (* accessibility relation *)

(* S5 axioms: reflexive, symmetric, transitive *)
axiomatization where
  refl:  "r w w"                   and
  sym:   "r w v \<Longrightarrow> r v w"          and
  trans: "r w v \<Longrightarrow> r v u \<Longrightarrow> r w u"

(* \<midarrow>\<midarrow> Modal operators (SSE) \<midarrow>\<midarrow> *)

(* Necessity: \<box>\<phi> holds at w iff \<phi> holds at all accessible worlds *)
definition mbox :: "\<sigma> \<Rightarrow> \<sigma>" ("\<box>_" [80] 80) where
  "\<box>\<phi> \<equiv> \<lambda>w. \<forall>v. r w v \<longrightarrow> \<phi> v"

(* Possibility: \<diamond>\<phi> holds at w iff \<phi> holds at some accessible world *)
definition mdia :: "\<sigma> \<Rightarrow> \<sigma>" ("\<diamond>_" [80] 80) where
  "\<diamond>\<phi> \<equiv> \<lambda>w. \<exists>v. r w v \<and> \<phi> v"

(* Propositional connectives lifted to \<sigma> *)
definition mImp :: "\<sigma> \<Rightarrow> \<sigma> \<Rightarrow> \<sigma>" (infixr "m\<rightarrow>" 70) where
  "\<phi> m\<rightarrow> \<psi> \<equiv> \<lambda>w. \<phi> w \<longrightarrow> \<psi> w"

(* Global validity: \<phi> is valid iff it holds at every world *)
definition valid :: "\<sigma> \<Rightarrow> bool" ("\<Turnstile>_" [80] 80) where
  "\<Turnstile>\<phi> \<equiv> \<forall>w. \<phi> w"

(* \<midarrow>\<midarrow> The target theorem \<midarrow>\<midarrow> *)
(* "If p is possible, then p is possibly possible": \<diamond>p \<rightarrow> \<diamond>\<diamond>p *)

theorem poss_implies_poss_poss:
  "\<Turnstile> (\<diamond>p m\<rightarrow> \<diamond>\<diamond>p)"
  unfolding valid_def mImp_def mdia_def
  (* From \<diamond>p at w: \<exists>v. r w v \<and> p v                *)
  (* Need \<diamond>\<diamond>p at w: \<exists>v. r w v \<and> (\<exists>u. r v u \<and> p u) *)
  (* By symmetry (r w v \<rightarrow> r v w) and reflexivity    *)
  (* (r v v), we can take u = v                     *)
  by (metis refl sym)

end