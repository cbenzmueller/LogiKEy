theory PMLinHOL_shallow_minimal_further_tests_1_nitpick imports PMLinHOL_shallow_minimal 
begin 
\<comment>\<open>What is the weakest modal logic in which the following test formulas F1-F10 are provable?\<close>
\<comment>\<open>Test with schematic axioms\<close>
abbreviation(input) "AxT \<equiv> \<forall>\<phi>. \<Turnstile>\<^sup>m (\<box>\<^sup>m\<phi>) \<supset>\<^sup>m \<phi>"
abbreviation(input) "AxB \<equiv> \<forall>\<phi>. \<Turnstile>\<^sup>m \<phi> \<supset>\<^sup>m \<box>\<^sup>m(\<diamond>\<^sup>m\<phi>)"
abbreviation(input) "Ax4 \<equiv> \<forall>\<phi>. \<Turnstile>\<^sup>m (\<box>\<^sup>m\<phi>) \<supset>\<^sup>m \<box>\<^sup>m(\<box>\<^sup>m\<phi>)"

consts \<phi>::\<sigma> \<psi>::\<sigma> 
abbreviation(input) "F1 \<equiv> (\<diamond>\<^sup>m(\<diamond>\<^sup>m\<phi>)) \<supset>\<^sup>m \<diamond>\<^sup>m\<phi>"\<comment>\<open>holds in K4\<close>
abbreviation(input) "F2 \<equiv> (\<diamond>\<^sup>m(\<box>\<^sup>m\<phi>)) \<supset>\<^sup>m \<box>\<^sup>m(\<diamond>\<^sup>m\<phi>)"\<comment>\<open>holds in KB\<close>
abbreviation(input) "F3 \<equiv> (\<diamond>\<^sup>m(\<box>\<^sup>m\<phi>)) \<supset>\<^sup>m \<box>\<^sup>m\<phi>"\<comment>\<open>holds in KB4\<close>
abbreviation(input) "F4 \<equiv> (\<box>\<^sup>m(\<diamond>\<^sup>m(\<box>\<^sup>m(\<diamond>\<^sup>m\<phi>)))) \<supset>\<^sup>m \<box>\<^sup>m(\<diamond>\<^sup>m\<phi>)"\<comment>\<open>holds in KB/K4\<close>
abbreviation(input) "F5 \<equiv> (\<diamond>\<^sup>m(\<phi> \<and>\<^sup>m (\<diamond>\<^sup>m\<psi>))) \<supset>\<^sup>m ((\<diamond>\<^sup>m\<phi>) \<and>\<^sup>m (\<diamond>\<^sup>m\<psi>))"\<comment>\<open>holds in K4\<close>
abbreviation(input) "F6 \<equiv> ((\<box>\<^sup>m(\<phi> \<supset>\<^sup>m \<psi>)) \<and>\<^sup>m (\<diamond>\<^sup>m(\<box>\<^sup>m(\<not>\<^sup>m\<psi>)))) \<supset>\<^sup>m \<not>\<^sup>m(\<diamond>\<^sup>m\<psi>)"\<comment>\<open>holds in KB4\<close>
abbreviation(input) "F7 \<equiv> (\<diamond>\<^sup>m\<phi>) \<supset>\<^sup>m (\<box>\<^sup>m(\<phi> \<or>\<^sup>m \<diamond>\<^sup>m\<phi>))"\<comment>\<open>holds in KB4\<close>
abbreviation(input) "F8 \<equiv> (\<diamond>\<^sup>m(\<box>\<^sup>m\<phi>)) \<supset>\<^sup>m (\<phi> \<or>\<^sup>m \<diamond>\<^sup>m\<phi>)"\<comment>\<open>holds in KT/KB\<close>
abbreviation(input) "F9 \<equiv> ((\<box>\<^sup>m(\<diamond>\<^sup>m\<phi>)) \<and>\<^sup>m (\<box>\<^sup>m(\<diamond>\<^sup>m(\<not>\<^sup>m \<phi>)))) \<supset>\<^sup>m \<diamond>\<^sup>m(\<diamond>\<^sup>m\<phi>)"\<comment>\<open>holds in KT\<close>
abbreviation(input) "F10 \<equiv> ((\<box>\<^sup>m(\<phi> \<supset>\<^sup>m \<box>\<^sup>m\<psi>)) \<and>\<^sup>m (\<box>\<^sup>m(\<diamond>\<^sup>m(\<not>\<^sup>m\<psi>)))) \<supset>\<^sup>m \<not>\<^sup>m(\<box>\<^sup>m\<psi>)"\<comment>\<open>holds in KT\<close>

declare imp_cong[cong del]

nitpick_params[expect=genuine,timeout=1]


experiment
begin
lemma KTB: "AxT \<and> AxB \<longrightarrow> \<Turnstile>\<^sup>m F1" nitpick apply simp nitpick sorry 
lemma KT: "AxT \<longrightarrow> \<Turnstile>\<^sup>m F1" nitpick apply simp nitpick sorry 
lemma KB: "AxB \<longrightarrow> \<Turnstile>\<^sup>m F1" nitpick apply simp nitpick sorry 
lemma K: "\<Turnstile>\<^sup>m F1" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma S4: "AxT \<and> Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F2" nitpick apply simp nitpick sorry 
lemma KT: "AxT \<longrightarrow> \<Turnstile>\<^sup>m F2" nitpick apply simp nitpick sorry 
lemma K4: "Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F2" nitpick apply simp nitpick sorry 
lemma K: "\<Turnstile>\<^sup>m F2" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma S4: "AxT \<and> Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F3" nitpick apply simp nitpick sorry  
lemma KTB: "AxT \<and> AxB \<longrightarrow> \<Turnstile>\<^sup>m F3" nitpick apply simp nitpick sorry 
lemma KT: "AxT \<longrightarrow> \<Turnstile>\<^sup>m F3" nitpick apply simp nitpick sorry 
lemma KB: "AxB \<longrightarrow> \<Turnstile>\<^sup>m F3" nitpick apply simp nitpick sorry 
lemma K4: "Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F3" nitpick apply simp nitpick sorry 
lemma K: "\<Turnstile>\<^sup>m F3" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma KT: "AxT \<longrightarrow> \<Turnstile>\<^sup>m F4" nitpick apply simp nitpick sorry 
lemma K: "\<Turnstile>\<^sup>m F4" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma KTB: "AxT \<and> AxB \<longrightarrow> \<Turnstile>\<^sup>m F5" nitpick apply simp nitpick sorry 
lemma KT: "AxT \<longrightarrow> \<Turnstile>\<^sup>m F5" nitpick apply simp nitpick sorry 
lemma KB: "AxB \<longrightarrow> \<Turnstile>\<^sup>m F5" nitpick apply simp nitpick sorry 
lemma K: "\<Turnstile>\<^sup>m F5" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma S4: "AxT \<and> Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F6" nitpick apply simp nitpick sorry 
lemma KTB: "AxT \<and> AxB \<longrightarrow> \<Turnstile>\<^sup>m F6" nitpick apply simp nitpick sorry 
lemma KT: "AxT \<longrightarrow> \<Turnstile>\<^sup>m F6" nitpick apply simp nitpick sorry 
lemma KB: "AxB \<longrightarrow> \<Turnstile>\<^sup>m F6" nitpick apply simp nitpick sorry 
lemma K4: "Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F6" nitpick apply simp nitpick sorry 
lemma K: "\<Turnstile>\<^sup>m F6" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma S4: "AxT \<and> Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F7" nitpick apply simp nitpick sorry 
lemma KTB: "AxT \<and> AxB \<longrightarrow> \<Turnstile>\<^sup>m F7" nitpick apply simp nitpick sorry 
lemma KT: "AxT \<longrightarrow> \<Turnstile>\<^sup>m F7" nitpick apply simp nitpick sorry 
lemma KB: "AxB \<longrightarrow> \<Turnstile>\<^sup>m F7" nitpick apply simp nitpick sorry 
lemma K4: "Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F7" nitpick apply simp nitpick sorry 
lemma K: "\<Turnstile>\<^sup>m F7" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma K4: "Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F8" nitpick apply simp nitpick sorry 
lemma K: "\<Turnstile>\<^sup>m F8" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma KB4: "AxB \<and> Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F9" nitpick apply simp nitpick sorry 
lemma KB: "AxB \<longrightarrow> \<Turnstile>\<^sup>m F9" nitpick apply simp nitpick sorry 
lemma K4: "Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F9" nitpick apply simp nitpick sorry 
lemma K: "\<Turnstile>\<^sup>m F9" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma KB4: "AxB \<and> Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F10" nitpick apply simp nitpick sorry 
lemma KB: "AxB \<longrightarrow> \<Turnstile>\<^sup>m F10" nitpick apply simp nitpick sorry 
lemma K4: "Ax4 \<longrightarrow> \<Turnstile>\<^sup>m F10" nitpick apply simp nitpick sorry 
lemma K: "\<Turnstile>\<^sup>m F10" nitpick apply simp nitpick sorry 
end

\<comment>\<open>Summary of experiments 40s: Nitpick: ctex=42 (with simp 42, without simp 42)\<close>
\<comment>\<open>Summary of experiments 10s: Nitpick: ctex=42 (with simp 42, without simp 42)\<close>
\<comment>\<open>Summary of experiments 2s: Nitpick: ctex=42 (with simp 42, without simp 42)\<close>
end