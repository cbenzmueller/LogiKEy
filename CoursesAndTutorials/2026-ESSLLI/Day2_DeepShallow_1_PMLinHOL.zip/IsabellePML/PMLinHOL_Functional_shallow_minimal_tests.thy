theory PMLinHOL_Functional_shallow_minimal_tests imports PMLinHOL_Functional_shallow_minimal       
begin                 
\<comment>\<open>Hilbert calculus: proving that the schematic axioms and rules are implied by the embedding\<close>
  lemma H1: "\<Turnstile>\<^sup>f \<phi> \<supset>\<^sup>f (\<psi> \<supset>\<^sup>f \<phi>)" by auto
  lemma H2: "\<Turnstile>\<^sup>f (\<phi> \<supset>\<^sup>f (\<psi> \<supset>\<^sup>f \<gamma>)) \<supset>\<^sup>f ((\<phi> \<supset>\<^sup>f \<psi>) \<supset>\<^sup>f (\<phi> \<supset>\<^sup>f \<gamma>)) " by auto
  lemma H3: "\<Turnstile>\<^sup>f (\<not>\<^sup>f\<phi>  \<supset>\<^sup>f \<not>\<^sup>f\<psi>) \<supset>\<^sup>f (\<psi> \<supset>\<^sup>f \<phi>)" by auto
  lemma MP: "\<Turnstile>\<^sup>f \<phi> \<Longrightarrow> \<Turnstile>\<^sup>f (\<phi>  \<supset>\<^sup>f \<psi>) \<Longrightarrow> \<Turnstile>\<^sup>f \<psi>" by auto
\<comment>\<open>Reasoning with the Hilbert calculus: interactive and fully automated\<close>
  lemma HCderived1: "\<Turnstile>\<^sup>f (\<phi> \<supset>\<^sup>f \<phi>)" \<comment>\<open>sledgehammer(H1 H2 H3 MP) returns: by (metis H1 H2 MP)\<close>  
    proof -  have 1: "\<Turnstile>\<^sup>f \<phi> \<supset>\<^sup>f ((\<psi> \<supset>\<^sup>f \<phi>) \<supset>\<^sup>f \<phi>)" using H1 by auto 
                 have 2: "\<Turnstile>\<^sup>f (\<phi> \<supset>\<^sup>f ((\<psi> \<supset>\<^sup>f \<phi>) \<supset>\<^sup>f \<phi>)) \<supset>\<^sup>f ((\<phi> \<supset>\<^sup>f (\<psi> \<supset>\<^sup>f \<phi>)) \<supset>\<^sup>f (\<phi> \<supset>\<^sup>f \<phi>))" using H2 by auto 
                 have 3: "\<Turnstile>\<^sup>f (\<phi> \<supset>\<^sup>f (\<psi> \<supset>\<^sup>f \<phi>)) \<supset>\<^sup>f (\<phi> \<supset>\<^sup>f \<phi>)" using 1 2 MP by meson
                 have 4: "\<Turnstile>\<^sup>f \<phi> \<supset>\<^sup>f (\<psi>  \<supset>\<^sup>f \<phi>)" using H1 by auto   
                 thus ?thesis using 3 4 MP by meson qed
  lemma HCderived2: "\<Turnstile>\<^sup>f \<phi> \<supset>\<^sup>f (\<not>\<^sup>f\<phi>  \<supset>\<^sup>f \<psi>) " by (metis H1 H2 H3 MP) 
  lemma HCderived3: "\<Turnstile>\<^sup>f (\<not>\<^sup>f\<phi>  \<supset>\<^sup>f \<phi>) \<supset>\<^sup>f \<phi>" by (metis H1 H2 H3 MP) 
  lemma HCderived4: "\<Turnstile>\<^sup>f (\<phi> \<supset>\<^sup>f \<psi>) \<supset>\<^sup>f (\<not>\<^sup>f\<psi> \<supset>\<^sup>f \<not>\<^sup>f\<phi>) " by auto
\<comment>\<open>Modal logic: the schematic necessitation rule and distribution axiom are implied\<close>
lemma Nec: "\<Turnstile>\<^sup>f \<phi> \<Longrightarrow> \<Turnstile>\<^sup>f \<box>\<^sup>f\<phi>" by (smt DefF)
  lemma Dist:  "\<Turnstile>\<^sup>f \<box>\<^sup>f(\<phi> \<supset>\<^sup>f \<psi>) \<supset>\<^sup>f (\<box>\<^sup>f\<phi> \<supset>\<^sup>f \<box>\<^sup>f\<psi>) " by auto
\<comment>\<open>Correspondence theory: correct statements\<close> declare [[show_types]]
  lemma cM:  "(\<exists>f::\<w>\<Rightarrow>\<w>. \<forall>w::\<w>.  (f w) = w) \<longleftrightarrow> (\<forall>\<phi>. \<Turnstile>\<^sup>f \<box>\<^sup>f\<phi> \<supset>\<^sup>f \<phi>)" by auto
  lemma cB: "(\<forall>f::\<w>\<Rightarrow>\<w>. \<forall>w::\<w>. \<exists>g::\<w>\<Rightarrow>\<w>. (g (f w)) = w)  \<longleftrightarrow> (\<forall>\<phi>. \<Turnstile>\<^sup>f \<phi> \<supset>\<^sup>f \<box>\<^sup>f\<diamond>\<^sup>f\<phi>)" by auto
  lemma c4: "(\<forall>f::\<w>\<Rightarrow>\<w>. \<forall>g::\<w>\<Rightarrow>\<w>. \<exists>h::\<w>\<Rightarrow>\<w>. \<forall>w::\<w>. (g (f w)) = (h w))  \<longleftrightarrow> (\<forall>\<phi>. \<Turnstile>\<^sup>f \<box>\<^sup>f\<phi> \<supset>\<^sup>f \<box>\<^sup>f(\<box>\<^sup>f\<phi>))" by auto
\<comment>\<open>Correspondence theory: incorrect statements\<close> 
  lemma "reflexive R \<longrightarrow> (\<forall>\<phi>. \<Turnstile>\<^sup>f \<box>\<^sup>f\<phi> \<supset>\<^sup>f \<box>\<^sup>f(\<box>\<^sup>f\<phi>))" nitpick[card \<w>=3,show_all] oops \<comment>\<open>nitpick: Counterexample\<close>
\<comment>\<open>Simple, incorrect validity statements\<close>
  lemma "\<Turnstile>\<^sup>f  \<box>\<^sup>f\<phi>" nitpick[card \<w>=2, card \<S>= 1] oops \<comment>\<open>nitpick: Counterexample: modal collapse not implied\<close>
  lemma "\<Turnstile>\<^sup>f  \<box>\<^sup>f\<phi>" nitpick[card \<w>=2, card \<S>= 1] oops \<comment>\<open>nitpick: Counterexample: modal collapse not implied\<close>
  lemma "\<Turnstile>\<^sup>f  \<phi> \<supset>\<^sup>f \<diamond>\<^sup>f\<phi>" sledgehammer nitpick[card \<w>=2, card \<S>= 1] oops \<comment>\<open>nitpick: Counterexample: modal collapse not implied\<close>
  lemma "\<Turnstile>\<^sup>f \<phi> \<supset>\<^sup>f \<box>\<^sup>f\<phi>" nitpick[card \<w>=2, card \<S>= 1] oops \<comment>\<open>nitpick: Counterexample: modal collapse not implied\<close>
  lemma "\<Turnstile>\<^sup>f \<box>\<^sup>f\<phi> \<supset>\<^sup>f \<phi>" sledgehammer nitpick[card \<w>=2, card \<S>= 1] oops \<comment>\<open>nitpick: Counterexample: modal collapse not implied\<close>
  lemma "\<Turnstile>\<^sup>f \<box>\<^sup>f( \<box>\<^sup>f\<phi> \<supset>\<^sup>f  \<box>\<^sup>f\<psi>) \<or>\<^sup>f \<box>\<^sup>f( \<box>\<^sup>f\<psi> \<supset>\<^sup>f  \<box>\<^sup>f\<phi>)" nitpick[card \<w>=3] oops \<comment>\<open>nitpick: Counterexample\<close> 
  lemma "\<Turnstile>\<^sup>f (\<diamond>\<^sup>f(\<box>\<^sup>f \<phi>)) \<supset>\<^sup>f  \<box>\<^sup>f(\<diamond>\<^sup>f \<phi>)" sledgehammer nitpick[card \<w>=2] oops \<comment>\<open>nitpick: Counterexample\<close> 
\<comment>\<open>Implied axiom schemata in S5\<close>
  lemma KB: "symmetric R \<longrightarrow> (\<forall>\<phi> \<psi>.  \<Turnstile>\<^sup>f (\<diamond>\<^sup>f(\<box>\<^sup>f\<phi>)) \<supset>\<^sup>f  \<box>\<^sup>f(\<diamond>\<^sup>f\<phi>))" by auto
  lemma K4B: "symmetric R \<and> transitive R \<longrightarrow> (\<forall>\<phi> \<psi>. \<Turnstile>\<^sup>f \<box>\<^sup>f( \<box>\<^sup>f\<phi> \<supset>\<^sup>f  \<box>\<^sup>f\<psi>) \<or>\<^sup>f \<box>\<^sup>f( \<box>\<^sup>f\<psi> \<supset>\<^sup>f  \<box>\<^sup>f\<phi>))" by (smt DefM)
end


(** 22 proofs by sledgehammer; 4 counterexamples by nitpick **)

