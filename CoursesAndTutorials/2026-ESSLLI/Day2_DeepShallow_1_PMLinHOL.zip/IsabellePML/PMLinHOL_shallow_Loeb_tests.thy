theory PMLinHOL_shallow_Loeb_tests  imports PMLinHOL_shallow 
begin  
\<comment>\<open>Löb axiom: with the maximal shallow embedding automated reasoning tools are very weakly responsive\<close>
  lemma Loeb1S:   "\<forall>\<phi>. \<Turnstile>\<^sup>s \<box>\<^sup>s( \<box>\<^sup>s\<phi> \<supset>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s\<phi>" nitpick[card \<w>=1,card \<S>=1] oops \<comment>\<open>nitpick: Counterexample.\<close>
  lemma Loeb2S:   "(conversewf R \<and> transitive R) \<longrightarrow> (\<forall>\<phi> W V. \<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi> \<supset>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s\<phi>)" 
    \<comment>\<open>sledgehammer: proof found, but reconstruction fails\<close> oops
  lemma Loeb3aS: "conversewf R \<longleftarrow> (\<forall>\<phi> W V. \<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi> \<supset>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s\<phi>)" 
    \<comment>\<open>sledgehammer: no proof\<close> oops
  lemma Loeb3aS: "transitive R \<longleftarrow> (\<forall>\<phi> W V. \<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi> \<supset>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s\<phi>)" \<comment>\<open>sledgehammer: no proof\<close> 
    proof fix R assume 1: "\<forall>\<phi> W V. \<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi> \<supset>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s\<phi>"
        have 2: "\<forall>\<phi> W V. \<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<box>\<^sup>s\<phi> \<supset>\<^sup>s \<box>\<^sup>s((\<box>\<^sup>s(\<box>\<^sup>s\<phi> \<and>\<^sup>s \<phi>)) \<supset>\<^sup>s ((\<box>\<^sup>s\<phi>) \<and>\<^sup>s \<phi>))" by simp
        show "transitive R"  \<comment>\<open>sledgehammer: no proof\<close> oops
end

(**  2 proofs by sledgehammer (lines 6 11) with 1 reconstruction failure (line 6) , 3 timeout; 1 counterexamples by nitpick **)
