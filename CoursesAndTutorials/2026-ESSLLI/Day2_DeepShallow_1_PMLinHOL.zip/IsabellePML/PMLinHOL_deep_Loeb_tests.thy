theory PMLinHOL_deep_Loeb_tests imports PMLinHOL_deep
begin  
\<comment>\<open>Löb axiom: with the maximal shallow embedding automated reasoning tools are very weakly responsive\<close>
  lemma Loeb1D:   "\<forall>\<phi>. \<Turnstile>\<^sup>d \<box>\<^sup>d( \<box>\<^sup>d\<phi> \<supset>\<^sup>d\<phi>) \<supset>\<^sup>d \<box>\<^sup>d\<phi>" nitpick[card \<w>=1,card \<S>=1] oops \<comment>\<open>nitpick: Counterexample.\<close>
  lemma Loeb2D:   "(conversewf R \<and> transitive R) \<longrightarrow> (\<forall>\<phi> W V. \<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>d \<box>\<^sup>d(\<box>\<^sup>d\<phi> \<supset>\<^sup>d\<phi>) \<supset>\<^sup>d \<box>\<^sup>d\<phi>)" 
    unfolding DefD by (smt (z3) PML.simps(23,24))
  lemma Loeb3aD: "conversewf R \<longleftarrow> (\<forall>\<phi> W V. \<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>d \<box>\<^sup>d(\<box>\<^sup>d\<phi> \<supset>\<^sup>d\<phi>) \<supset>\<^sup>d \<box>\<^sup>d\<phi>)" 
    \<comment>\<open>sledgehammer: no proof\<close> oops
  lemma Loeb3bD: "transitive R \<longleftarrow> (\<forall>\<phi> W V. \<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>d \<box>\<^sup>d(\<box>\<^sup>d\<phi> \<supset>\<^sup>d\<phi>) \<supset>\<^sup>d \<box>\<^sup>d\<phi>)" \<comment>\<open>sledgehammer: no proof\<close> 
    proof fix R assume 1: "\<forall>\<phi> W V. \<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>d \<box>\<^sup>d(\<box>\<^sup>d\<phi> \<supset>\<^sup>d\<phi>) \<supset>\<^sup>d \<box>\<^sup>d\<phi>"
        have 2: "\<forall>\<phi> W V. \<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>d \<box>\<^sup>d\<phi> \<supset>\<^sup>d \<box>\<^sup>d((\<box>\<^sup>d(\<box>\<^sup>d\<phi> \<and>\<^sup>d \<phi>)) \<supset>\<^sup>d ((\<box>\<^sup>d\<phi>) \<and>\<^sup>d \<phi>))" using AndD_def by force
        show "transitive R"  \<comment>\<open>sledgehammer: no proof\<close> oops
end


(** 2 proofs by sledgehammer (lines 6 11), 3 timeouts (lines 8 9 12); 1 counterexamples by nitpick **)
