theory ModalS5_PossNec
  imports Main

begin
typedecl i                           
type_synonym \<sigma> = "i \<Rightarrow> bool"         
consts r :: "i \<Rightarrow> i \<Rightarrow> bool"          

axiomatization where
  refl  : "r w w"                    and   
  sym   : "r w v \<Longrightarrow> r v w"           and   
  trans : "r w v \<Longrightarrow> r v u \<Longrightarrow> r w u"       

definition mbox :: "\<sigma> \<Rightarrow> \<sigma>" ("\<box>_" [80] 80) where
  "\<box>\<phi> \<equiv> \<lambda>w. \<forall>v. r w v \<longrightarrow> \<phi> v"

definition mdia :: "\<sigma> \<Rightarrow> \<sigma>" ("\<diamond>_" [80] 80) where
  "\<diamond>\<phi> \<equiv> \<lambda>w. \<exists>v. r w v \<and> \<phi> v"

definition mImp :: "\<sigma> \<Rightarrow> \<sigma> \<Rightarrow> \<sigma>" (infixr "m\<rightarrow>" 70) where
  "\<phi> m\<rightarrow> \<psi> \<equiv> \<lambda>w. \<phi> w \<longrightarrow> \<psi> w"


definition valid :: "\<sigma> \<Rightarrow> bool" ("\<Turnstile>_" [80] 80) where
  "\<Turnstile>\<phi> \<equiv> \<forall>w. \<phi> w"

theorem poss_nec_implies_nec_poss:
  "\<Turnstile> (\<diamond>(\<box>p) m\<rightarrow> \<box>(\<diamond>p))" sledgehammer[overlord]
  unfolding valid_def mImp_def mdia_def mbox_def
  by (metis refl sym trans)

end