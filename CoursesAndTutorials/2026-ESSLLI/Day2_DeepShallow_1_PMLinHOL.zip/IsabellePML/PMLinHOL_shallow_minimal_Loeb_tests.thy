theory PMLinHOL_shallow_minimal_Loeb_tests  imports PMLinHOL_shallow_minimal  
begin  
  \<comment>\<open>Löb axiom: with the minimal shallow embedding automated reasoning tools are still partly responsive\<close>
  lemma Loeb1M:  "\<forall>\<phi>. \<Turnstile>\<^sup>m \<box>\<^sup>m( \<box>\<^sup>m\<phi> \<supset>\<^sup>m\<phi>) \<supset>\<^sup>m \<box>\<^sup>m\<phi>" nitpick[card \<w>=1,card \<S>=1] oops \<comment>\<open>nitpick: Counterexample.\<close>
  lemma Loeb2M:  "(conversewf R \<and> transitive R) \<longrightarrow> (\<forall>\<phi>. \<Turnstile>\<^sup>m \<box>\<^sup>m(\<box>\<^sup>m\<phi> \<supset>\<^sup>m\<phi>) \<supset>\<^sup>m \<box>\<^sup>m\<phi>)" 
    using DefM(10,11,3,4) by (smt (verit, del_insts))
  lemma Loeb3aM: "conversewf R \<longleftarrow> (\<forall>\<phi>. \<Turnstile>\<^sup>m \<box>\<^sup>m(\<box>\<^sup>m\<phi> \<supset>\<^sup>m\<phi>) \<supset>\<^sup>m \<box>\<^sup>m\<phi>)" unfolding DefM by blast  
  lemma Loeb3bM: "transitive R \<longleftarrow> (\<forall>\<phi>. \<Turnstile>\<^sup>m \<box>\<^sup>m(\<box>\<^sup>m\<phi> \<supset>\<^sup>m\<phi>) \<supset>\<^sup>m \<box>\<^sup>m\<phi>)"  \<comment>\<open>sledgehammer: no proof\<close> 
    proof assume 1: "\<forall>\<phi>. \<Turnstile>\<^sup>m \<box>\<^sup>m (\<box>\<^sup>m \<phi> \<supset>\<^sup>m \<phi>) \<supset>\<^sup>m \<box>\<^sup>m \<phi>"
            have 2: "\<forall>\<phi>. \<Turnstile>\<^sup>m \<box>\<^sup>m\<phi> \<supset>\<^sup>m \<box>\<^sup>m((\<box>\<^sup>m(\<box>\<^sup>m\<phi> \<and>\<^sup>m \<phi>)) \<supset>\<^sup>m ((\<box>\<^sup>m\<phi>) \<and>\<^sup>m \<phi>))" by auto
            show "transitive R" by (smt (z3) 1 2 DefM(10,11,2,3,4,6)) qed
  lemma Loeb3M: "(conversewf R \<and> transitive R) \<longleftarrow> (\<forall>\<phi>. \<Turnstile>\<^sup>m \<box>\<^sup>m(\<box>\<^sup>m\<phi> \<supset>\<^sup>m\<phi>) \<supset>\<^sup>m \<box>\<^sup>m\<phi>)" using Loeb3aM Loeb3bM by force
end

(** 3 proofs by sledgehammer (lines 6 7 10 11), 1 timeout (line 8); 1 counterexamples by nitpick **)
