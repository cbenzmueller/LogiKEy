theory PMLinHOL_shallow_minimal_alt  imports PMLinHOL_preliminaries                     
begin            
\<comment>\<open>The acessibility relation R and the valuation function V are introduced as constants at the meta-level HOL\<close>
  type_synonym \<sigma> = "\<w>\<Rightarrow>bool"   
  consts R::\<R> V::\<V>  at::"\<S>\<Rightarrow>\<sigma>"
  axiomatization where at_injective: "\<forall>x y. at x = at y \<longrightarrow> x = y"
  axiomatization where at_surjective: "\<forall>y. \<exists>x. at x = y"
  axiomatization where at_V [simp]: "\<forall>s w. V s w = (at s) w"  
\<comment>\<open>Shallow embedding (of propositional modal logic in HOL)\<close>
  definition AtmX :: "\<S>\<Rightarrow>\<sigma>"          ("_\<^sup>x")                              where              "a\<^sup>x \<equiv> at a"
  definition NegX :: "\<sigma>\<Rightarrow>\<sigma>"           ("\<not>\<^sup>x")                             where          "\<not>\<^sup>x \<phi> \<equiv> \<lambda>w.  \<not>\<phi> w"
  definition ImpX :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"      (infixr "\<supset>\<^sup>x" 93)             where      "\<phi> \<supset>\<^sup>x \<psi> \<equiv> \<lambda>w. \<phi> w \<longrightarrow> \<psi> w"
  definition BoxX :: "\<sigma>\<Rightarrow>\<sigma>"           ("\<box>\<^sup>x")                             where         "\<box>\<^sup>x \<phi> \<equiv> \<lambda>w. \<forall>v. R w v \<longrightarrow> \<phi> v" 
\<comment>\<open>Further logical connectives as definitions\<close>
  definition OrX   :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"      (infixr "\<or>\<^sup>x" 92)             where       "\<phi> \<or>\<^sup>x \<psi> \<equiv> \<not>\<^sup>x\<phi> \<supset>\<^sup>x \<psi>"
  definition AndX :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"      (infixr "\<and>\<^sup>x" 95)             where       "\<phi> \<and>\<^sup>x \<psi> \<equiv> \<not>\<^sup>x(\<phi> \<supset>\<^sup>x \<not>\<^sup>x\<psi>)"
  definition DiaX  :: "\<sigma>\<Rightarrow>\<sigma>"           ("\<diamond>\<^sup>x_")                           where           "\<diamond>\<^sup>x\<phi> \<equiv> \<not>\<^sup>x (\<box>\<^sup>x (\<not>\<^sup>x\<phi>)) "
  definition TopX :: "\<sigma>"                 ("\<top>\<^sup>x")                             where             "\<top>\<^sup>x \<equiv> p\<^sup>x \<supset>\<^sup>x p\<^sup>x"
  definition BotX  :: "\<sigma>"                 ("\<bottom>\<^sup>x")                            where             "\<bottom>\<^sup>x \<equiv> \<not>\<^sup>x \<top>\<^sup>x"
\<comment>\<open>Definition of truth of a formula relative to a model \<open>\<langle>W,R,V\<rangle>\<close> and a possible world w\<close>
  definition RelativeTruthX :: "\<w>\<Rightarrow>\<sigma>\<Rightarrow>bool" ("_  \<Turnstile>\<^sup>x _")      where             "w \<Turnstile>\<^sup>x \<phi> \<equiv> \<phi> w"
\<comment>\<open>Definition of validity\<close>
  definition  ValX :: "\<sigma>\<Rightarrow>bool" ("\<Turnstile>\<^sup>x _")                               where                 "\<Turnstile>\<^sup>x \<phi> \<equiv>  \<forall>w::\<w>. w \<Turnstile>\<^sup>x \<phi>"
\<comment>\<open>Collection of definitions in a bag called DefX\<close>
  named_theorems DefX declare AtmX_def[DefX,simp] NegX_def[DefX,simp] ImpX_def[DefX,simp] 
    BoxX_def[DefX,simp] OrX_def[DefX,simp] AndX_def[DefX,simp] DiaX_def[DefX,simp] TopX_def[DefX,simp] 
    BotX_def[DefX,simp] RelativeTruthX_def[DefX,simp] ValX_def[DefX,simp]
end




