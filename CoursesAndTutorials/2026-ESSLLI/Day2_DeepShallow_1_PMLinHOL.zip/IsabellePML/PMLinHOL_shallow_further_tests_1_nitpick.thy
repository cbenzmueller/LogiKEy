theory PMLinHOL_shallow_further_tests_1_nitpick imports PMLinHOL_shallow 
begin 
\<comment>\<open>What is the weakest modal logic in which the following test formulas F1-F10 are provable?\<close>
\<comment>\<open>Test with schematic axioms\<close>

consts \<phi>::\<sigma> \<psi>::\<sigma>
abbreviation(input) "F1 \<equiv> (\<diamond>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<supset>\<^sup>s \<diamond>\<^sup>s\<phi>" \<comment>\<open>holds in K4\<close>
abbreviation(input) "F2 \<equiv> (\<diamond>\<^sup>s(\<box>\<^sup>s\<phi>)) \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)" \<comment>\<open>holds in KB\<close>
abbreviation(input) "F3 \<equiv> (\<diamond>\<^sup>s(\<box>\<^sup>s\<phi>)) \<supset>\<^sup>s \<box>\<^sup>s\<phi>" \<comment>\<open>holds in KB4\<close>
abbreviation(input) "F4 \<equiv> (\<box>\<^sup>s(\<diamond>\<^sup>s(\<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)))) \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)" \<comment>\<open>holds in KB/K4\<close>
abbreviation(input) "F5 \<equiv> (\<diamond>\<^sup>s(\<phi> \<and>\<^sup>s (\<diamond>\<^sup>s\<psi>))) \<supset>\<^sup>s ((\<diamond>\<^sup>s\<phi>) \<and>\<^sup>s (\<diamond>\<^sup>s\<psi>))" \<comment>\<open>holds in K4\<close>
abbreviation(input) "F6 \<equiv> ((\<box>\<^sup>s(\<phi> \<supset>\<^sup>s \<psi>)) \<and>\<^sup>s (\<diamond>\<^sup>s(\<box>\<^sup>s(\<not>\<^sup>s\<psi>)))) \<supset>\<^sup>s \<not>\<^sup>s(\<diamond>\<^sup>s\<psi>)" \<comment>\<open>holds in KB4\<close>
abbreviation(input) "F7 \<equiv> (\<diamond>\<^sup>s\<phi>) \<supset>\<^sup>s (\<box>\<^sup>s(\<phi> \<or>\<^sup>s \<diamond>\<^sup>s\<phi>))" \<comment>\<open>holds in KB4\<close>
abbreviation(input) "F8 \<equiv> (\<diamond>\<^sup>s(\<box>\<^sup>s\<phi>)) \<supset>\<^sup>s (\<phi> \<or>\<^sup>s \<diamond>\<^sup>s\<phi>)" \<comment>\<open>holds in KT/KB\<close>
abbreviation(input) "F9 \<equiv> ((\<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<and>\<^sup>s (\<box>\<^sup>s(\<diamond>\<^sup>s(\<not>\<^sup>s \<phi>)))) \<supset>\<^sup>s \<diamond>\<^sup>s(\<diamond>\<^sup>s\<phi>)" \<comment>\<open>holds in KT\<close>
abbreviation(input) "F10 \<equiv> ((\<box>\<^sup>s(\<phi> \<supset>\<^sup>s \<box>\<^sup>s\<psi>)) \<and>\<^sup>s (\<box>\<^sup>s(\<diamond>\<^sup>s(\<not>\<^sup>s\<psi>)))) \<supset>\<^sup>s \<not>\<^sup>s(\<box>\<^sup>s\<psi>)" \<comment>\<open>holds in KT\<close>

declare imp_cong[cong del]

nitpick_params[expect=genuine,timeout=40]

experiment 
begin
lemma KTB: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<and> (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F1" nitpick apply simp nitpick sorry 
lemma KT: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F1" nitpick apply simp nitpick sorry 
lemma KB: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F1" nitpick apply simp nitpick sorry 
lemma K: "\<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F1" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma S4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<and> (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F2" nitpick apply simp nitpick sorry 
lemma KT: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F2" nitpick apply simp nitpick sorry 
lemma K4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F2" nitpick apply simp nitpick sorry 
lemma K: "\<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F2" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma S4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<and> (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F3" nitpick apply simp nitpick sorry 
lemma KTB: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<and> (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F3" nitpick apply simp nitpick sorry 
lemma KT: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F3" nitpick apply simp nitpick sorry 
lemma KB: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F3" nitpick apply simp nitpick sorry 
lemma K4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F3" nitpick apply simp nitpick sorry 
lemma K: "\<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F3" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma KT: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F4" nitpick apply simp nitpick sorry 
lemma K: "\<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F4" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma KTB: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<and> (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F5" nitpick apply simp nitpick sorry 
lemma KT: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F5" nitpick apply simp nitpick sorry 
lemma KB: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F5" nitpick apply simp nitpick sorry 
lemma K: "\<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F5" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma S4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<and> (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F6" nitpick apply simp nitpick sorry 
lemma KTB: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<and> (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F6" nitpick apply simp nitpick sorry 
lemma KT: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F6" nitpick apply simp nitpick sorry 
lemma KB: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F6" nitpick apply simp nitpick sorry 
lemma K4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F6" nitpick apply simp nitpick sorry 
lemma K: "\<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F6" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma S4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<and> (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F7" nitpick apply simp nitpick sorry 
lemma KTB: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<and> (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F7" nitpick apply simp nitpick sorry 
lemma KT: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<phi>) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F7" nitpick apply simp nitpick sorry 
lemma KB: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F7" nitpick apply simp nitpick sorry 
lemma K4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F7" nitpick apply simp nitpick sorry 
lemma K: "\<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F7" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma K4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F8" nitpick apply simp nitpick sorry 
lemma K: "\<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F8" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma KB4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<and> (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F9" nitpick apply simp nitpick sorry 
lemma KB: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F9" nitpick apply simp nitpick sorry 
lemma K4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F9" nitpick apply simp nitpick sorry 
lemma K: "\<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F9" nitpick apply simp nitpick sorry 
end

experiment
begin
lemma KB4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<and> (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F10" nitpick apply simp nitpick sorry 
lemma KB: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s \<phi> \<supset>\<^sup>s \<box>\<^sup>s(\<diamond>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F10" nitpick apply simp nitpick sorry 
lemma K4: "\<forall>w:W. (\<forall>\<phi>. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s (\<box>\<^sup>s\<phi>) \<supset>\<^sup>s \<box>\<^sup>s(\<box>\<^sup>s\<phi>)) \<longrightarrow> \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F10" nitpick apply simp nitpick sorry 
lemma K: "\<forall>w:W. \<langle>W,R,V\<rangle>,w \<Turnstile>\<^sup>s F10" nitpick apply simp nitpick sorry 
end

\<comment>\<open>Summary of experiments 10s: Nitpick: ctex=16 (with simp 16, without simp 16)\<close>
\<comment>\<open>Summary of experiments 10s: Nitpick: ctex=16 (with simp 16, without simp 16)\<close>
\<comment>\<open>Summary of experiments 2s: Nitpick: ctex=16 (with simp 16, without simp 16)\<close>
end
