theory PMLinHOL_Functional_shallow_minimal  imports PMLinHOL_preliminaries                        
begin            
\<comment>\<open>The acessibility relation R and the valuation function V are introduced as constants at the meta-level HOL\<close>
  consts V::\<V>  path::"\<w>\<Rightarrow>(\<w>\<Rightarrow>\<w>)\<Rightarrow>\<w>"
\<comment>\<open>Shallow embedding (of propositional modal logic in HOL)\<close>
  type_synonym \<sigma> = "\<w>\<Rightarrow>bool"   
  definition AtmF :: "\<S>\<Rightarrow>\<sigma>"          ("_\<^sup>f")                              where              "a\<^sup>f \<equiv> \<lambda>w. V a w"
  definition NegF :: "\<sigma>\<Rightarrow>\<sigma>"           ("\<not>\<^sup>f")                             where          "\<not>\<^sup>f \<phi> \<equiv> \<lambda>w.  \<not>\<phi> w"
  definition ImpF :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"      (infixr "\<supset>\<^sup>f" 93)             where      "\<phi> \<supset>\<^sup>f \<psi> \<equiv> \<lambda>w. \<phi> w \<longrightarrow> \<psi> w"
  definition BoxF :: "\<sigma>\<Rightarrow>\<sigma>"           ("\<box>\<^sup>f")                             where         "\<box>\<^sup>f \<phi> \<equiv> \<lambda>w.  (\<forall>f. \<phi> (path w f))" 
\<comment>\<open>Further logical connectives as definitions\<close>
  definition OrF   :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"      (infixr "\<or>\<^sup>f" 92)             where       "\<phi> \<or>\<^sup>f \<psi> \<equiv> \<not>\<^sup>f\<phi> \<supset>\<^sup>f \<psi>"
  definition AndF :: "\<sigma>\<Rightarrow>\<sigma>\<Rightarrow>\<sigma>"      (infixr "\<and>\<^sup>f" 95)             where       "\<phi> \<and>\<^sup>f \<psi> \<equiv> \<not>\<^sup>f(\<phi> \<supset>\<^sup>f \<not>\<^sup>f\<psi>)"
  definition DiaF  :: "\<sigma>\<Rightarrow>\<sigma>"           ("\<diamond>\<^sup>f_")                           where           "\<diamond>\<^sup>f\<phi> \<equiv> \<not>\<^sup>f (\<box>\<^sup>f (\<not>\<^sup>f\<phi>)) "
  definition TopF :: "\<sigma>"                 ("\<top>\<^sup>f")                             where             "\<top>\<^sup>f \<equiv> p\<^sup>f \<supset>\<^sup>f p\<^sup>f"
  definition BotF  :: "\<sigma>"                 ("\<bottom>\<^sup>f")                            where             "\<bottom>\<^sup>f \<equiv> \<not>\<^sup>f \<top>\<^sup>f"
\<comment>\<open>Definition of truth of a formula relative to a model \<open>\<langle>W,R,V\<rangle>\<close> and a possible world w\<close>
  definition RelativeTruthF :: "\<w>\<Rightarrow>\<sigma>\<Rightarrow>bool" ("_  \<Turnstile>\<^sup>f _")      where             "w \<Turnstile>\<^sup>f \<phi> \<equiv> \<phi> w"
\<comment>\<open>Definition of validity\<close>
  definition  ValF :: "\<sigma>\<Rightarrow>bool" ("\<Turnstile>\<^sup>f _")                               where                 "\<Turnstile>\<^sup>f \<phi> \<equiv>  \<forall>w::\<w>. w \<Turnstile>\<^sup>f \<phi>"
\<comment>\<open>Collection of definitions in a bag called DefF\<close>
  named_theorems DefF declare AtmF_def[DefF,simp] NegF_def[DefF,simp] ImpF_def[DefF,simp] 
    BoxF_def[DefF,simp] OrF_def[DefF,simp] AndF_def[DefF,simp] DiaF_def[DefF,simp] TopF_def[DefF,simp] 
    BotF_def[DefF,simp] RelativeTruthF_def[DefF,simp] ValF_def[DefF,simp]
end




